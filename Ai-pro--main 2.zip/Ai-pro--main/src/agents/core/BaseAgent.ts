import type { AgentConfig, AgentDecision, AgentMessage } from './AgentTypes';

export abstract class BaseAgent {
  protected config: AgentConfig;
  protected initialized: boolean = false;

  constructor(config: AgentConfig) {
    this.config = config;
  }

  async initialize(): Promise<void> {
    if (!this.initialized) {
      await this.onInitialize();
      this.initialized = true;
    }
  }

  async processMessage(message: AgentMessage): Promise<AgentDecision | null> {
    if (!this.initialized) {
      await this.initialize();
    }
    return this.onProcessMessage(message);
  }

  protected abstract onInitialize(): Promise<void>;
  protected abstract onProcessMessage(message: AgentMessage): Promise<AgentDecision | null>;

  getId(): string {
    return this.config.id;
  }

  getRole(): string {
    return this.config.role || 'unknown';
  }

  getCapabilities(): string[] {
    return this.config.capabilities || [];
  }
}
