// Browser-compatible EventEmitter implementation
class EventEmitter {
  protected events: Map<string, Array<(data?: any) => void>> = new Map();

  on(event: string, listener: (data?: any) => void): void {
    if (!this.events.has(event)) {
      this.events.set(event, []);
    }
    this.events.get(event)!.push(listener);
  }

  emit(event: string, data?: any): void {
    const listeners = this.events.get(event);
    if (listeners) {
      listeners.forEach(listener => listener(data));
    }
  }

  off(event: string, listener: (data?: any) => void): void {
    const listeners = this.events.get(event);
    if (listeners) {
      const index = listeners.indexOf(listener);
      if (index > -1) listeners.splice(index, 1);
    }
  }
  
  cleanup(): void {
    this.events.clear();
  }
}

// Simple UUID generator for browser
function generateUUID(): string {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    const r = Math.random() * 16 | 0;
    const v = c === 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
}

// Mobile detection
const isMobile = () => /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);

// ==================== AGENT TYPES & INTERFACES ====================

export type AgentRole =
  | 'STRATEGIST'
  | 'ANALYST'
  | 'RISK_MANAGER'
  | 'EXECUTOR'
  | 'LEARNER'
  | 'ORACLE'
  | 'ADAPTER'
  | 'CRISIS_MANAGER';

export type AgentStatus = 'IDLE' | 'THINKING' | 'ACTING' | 'LEARNING' | 'ERROR';

export interface AgentGoal {
  id: string;
  priority: number;
  target: string;
  constraints: Record<string, any>;
  deadline?: number;
  subgoals?: string[];
}

export interface AgentMemory {
  shortTerm: any[];
  longTerm: Record<string, any>;
  episodic: Array<{context: string; outcome: string; reward: number}>;
}

export interface AgentMessage {
  from: string;
  to: string;
  type: 'REQUEST' | 'RESPONSE' | 'BROADCAST' | 'COMMAND' | 'LEARN';
  payload: any;
  timestamp: number;
  correlationId?: string;
}

export interface AgentConfig {
  role: AgentRole;
  name: string;
  autonomyLevel: number;
  learningRate: number;
  riskTolerance: number;
  maxConcurrentTasks: number;
  specialization?: string[];
}

export interface AgentDecision {
  action: string;
  params: Record<string, any>;
  confidence: number;
  reasoning: string;
  alternatives?: Array<{action: string; confidence: number}>;
}

// ==================== PERFORMANCE METRICS ====================

export class AgentPerformanceMetrics {
  private trades: Array<{pnl: number; timestamp: number; strategy: string}> = [];
  private decisions: Array<{correct: boolean; confidence: number; timestamp: number}> = [];
  private learningProgress: number[] = [];

  recordTrade(pnl: number, strategy: string): void {
    this.trades.push({ pnl, timestamp: Date.now(), strategy });
    const maxTrades = isMobile() ? 100 : 1000;
    if (this.trades.length > maxTrades) this.trades.shift();
  }

  recordDecision(correct: boolean, confidence: number): void {
    this.decisions.push({ correct, confidence, timestamp: Date.now() });
    const maxDecisions = isMobile() ? 50 : 1000;
    if (this.decisions.length > maxDecisions) this.decisions.shift();
  }

  recordLearningProgress(score: number): void {
    this.learningProgress.push(score);
    const maxProgress = isMobile() ? 20 : 100;
    if (this.learningProgress.length > maxProgress) this.learningProgress.shift();
  }

  recordSuccess(): void {
    this.recordDecision(true, 0.8);
  }

  recordFailure(): void {
    this.recordDecision(false, 0.2);
  }

  calculateCompositeScore(): number {
    if (isMobile()) {
      const winRate = this.trades.filter(t => t.pnl > 0).length / (this.trades.length || 1);
      return winRate;
    }

    const winRate = this.trades.filter(t => t.pnl > 0).length / (this.trades.length || 1);
    const avgPnl = this.trades.reduce((a, b) => a + b.pnl, 0) / (this.trades.length || 1);
    const decisionAccuracy = this.decisions.filter(d => d.correct).length / (this.decisions.length || 1);
    const learningVelocity = this.learningProgress.length > 1
      ? (this.learningProgress[this.learningProgress.length - 1] - this.learningProgress[0]) / this.learningProgress.length
      : 0;

    return (winRate * 0.3 + Math.min(avgPnl / 100, 1) * 0.3 + decisionAccuracy * 0.2 + Math.max(learningVelocity, 0) * 0.2);
  }

  getBestStrategies(): string[] {
    if (isMobile()) return ['default'];

    const strategyPerformance: Record<string, number[]> = {};
    this.trades.forEach(t => {
      if (!strategyPerformance[t.strategy]) strategyPerformance[t.strategy] = [];
      strategyPerformance[t.strategy].push(t.pnl);
    });

    return Object.entries(strategyPerformance)
      .map(([strategy, pnls]) => ({
        strategy,
        avgPnl: pnls.reduce((a, b) => a + b, 0) / pnls.length
      }))
      .sort((a, b) => b.avgPnl - a.avgPnl)
      .slice(0, 3)
      .map(s => s.strategy);
  }

  serialize(): string {
    if (isMobile()) return '{}';
    return JSON.stringify({ trades: this.trades, decisions: this.decisions, learningProgress: this.learningProgress });
  }

  deserialize(data: string): void {
    if (isMobile()) return;
    try {
      const parsed = JSON.parse(data);
      this.trades = parsed.trades || [];
      this.decisions = parsed.decisions || [];
      this.learningProgress = parsed.learningProgress || [];
    } catch (e) {
      console.warn('Failed to deserialize metrics:', e);
    }
  }
}

// ==================== BASE AGENT CLASS ====================

export abstract class BaseAgent extends EventEmitter {
  public readonly id: string;
  public readonly role: AgentRole;
  public readonly name: string;
  public status: AgentStatus = 'IDLE';
  public memory: AgentMemory;
  public goals: Map<string, AgentGoal> = new Map();
  public performance: AgentPerformanceMetrics;

  protected orchestrator: AgentOrchestrator;
  public config: AgentConfig;
  protected taskQueue: Array<() => Promise<void>> = [];
  protected isProcessing: boolean = false;
  private processingTimeout: number | null = null;

  constructor(config: AgentConfig, orchestrator: AgentOrchestrator) {
    super();
    this.id = generateUUID();
    this.role = config.role;
    this.name = config.name;
    this.config = config;
    this.orchestrator = orchestrator;
    
    this.memory = {
      shortTerm: [],
      longTerm: {},
      episodic: []
    };
    this.performance = new AgentPerformanceMetrics();
  }

  abstract perceive(): Promise<any>;
  abstract think(data: any): Promise<AgentDecision>;
  abstract act(decision: AgentDecision): Promise<void>;
  abstract learn(outcome: any): Promise<void>;

  public async selfEvaluate(): Promise<number> {
    if (isMobile()) return 0.5;
    
    const score = this.performance.calculateCompositeScore();
    if (score < 0.3) {
      this.emit('performance:critical', { agentId: this.id, score });
      await this.requestAssistance();
    }
    return score;
  }

  public async requestAssistance(): Promise<void> {
    if (isMobile()) return;
    
    const helpRequest: AgentMessage = {
      from: this.id,
      to: 'ORCHESTRATOR',
      type: 'REQUEST',
      payload: { action: 'ASSISTANCE_NEEDED', context: this.memory.shortTerm.slice(-5) },
      timestamp: Date.now()
    };
    await this.orchestrator.routeMessage(helpRequest);
  }

  public async receiveMessage(message: AgentMessage): Promise<void> {
    if (isMobile()) return;
    
    this.memory.shortTerm.push(message);
    const maxMemory = isMobile() ? 10 : 100;
    if (this.memory.shortTerm.length > maxMemory) this.memory.shortTerm.shift();

    switch (message.type) {
      case 'COMMAND':
        await this.executeCommand(message.payload);
        break;
      case 'REQUEST':
        const response = await this.handleRequest(message.payload);
        await this.sendResponse(message.from, response, message.correlationId);
        break;
      case 'LEARN':
        await this.learn(message.payload);
        break;
      case 'BROADCAST':
        await this.handleBroadcast(message.payload);
        break;
    }
  }

  protected async sendResponse(to: string, payload: any, correlationId?: string): Promise<void> {
    if (isMobile()) return;
    
    const response: AgentMessage = {
      from: this.id,
      to,
      type: 'RESPONSE',
      payload,
      timestamp: Date.now(),
      correlationId
    };
    await this.orchestrator.routeMessage(response);
  }

  protected async executeCommand(command: any): Promise<void> {
    this.status = 'ACTING';
    try {
      await this.act({ 
        action: command.action, 
        params: command.params, 
        confidence: 0.9, 
        reasoning: 'Command execution' 
      });
      this.emit('command:completed', { commandId: command.id });
    } catch (error) {
      this.emit('command:failed', { commandId: command.id, error });
      throw error;
    } finally {
      this.status = 'IDLE';
    }
  }

  protected abstract handleRequest(payload: any): Promise<any>;
  protected abstract handleBroadcast(payload: any): Promise<void>;

  public scheduleTask(task: () => Promise<void>, priority: number = 5): void {
    if (isMobile()) return;
    
    const wrappedTask = async () => {
      this.status = 'THINKING';
      try {
        await task();
        this.performance.recordSuccess();
      } catch (error) {
        this.performance.recordFailure();
        throw error;
      } finally {
        this.status = 'IDLE';
        this.processingTimeout = window.setTimeout(() => this.processNextTask(), 10);
      }
    };

    const insertIndex = this.taskQueue.findIndex((t: any) => t.priority < priority);
    if (insertIndex === -1) {
      this.taskQueue.push(wrappedTask as any);
    } else {
      this.taskQueue.splice(insertIndex, 0, wrappedTask as any);
    }

    if (!this.isProcessing) this.processNextTask();
  }

  private async processNextTask(): Promise<void> {
    if (this.taskQueue.length === 0 || this.isProcessing) return;
    
    this.isProcessing = true;
    const task = this.taskQueue.shift();
    
    try {
      if (task) await task();
    } catch (e) {
      console.error('Task error:', e);
    }
    
    this.isProcessing = false;
    
    if (this.taskQueue.length > 0) {
      this.processingTimeout = window.setTimeout(() => this.processNextTask(), 0);
    }
  }

  public serialize(): string {
    if (isMobile()) return '{}';
    return JSON.stringify({
      id: this.id,
      role: this.role,
      memory: this.memory,
      performance: this.performance.serialize(),
      config: this.config
    });
  }

  public deserialize(state: string): void {
    if (isMobile()) return;
    try {
      const parsed = JSON.parse(state);
      this.memory = parsed.memory;
      this.performance.deserialize(parsed.performance);
    } catch (e) {
      console.warn('Failed to deserialize agent:', e);
    }
  }

  public cleanup(): void {
    if (this.processingTimeout) {
      clearTimeout(this.processingTimeout);
    }
    this.taskQueue = [];
    this.memory.shortTerm = [];
    super.cleanup();
  }
}

// ==================== AGENT ORCHESTRATOR ====================

export class AgentOrchestrator extends EventEmitter {
  private agents: Map<string, BaseAgent> = new Map();
  private messageBus: AgentMessage[] = [];
  private isRunning: boolean = false;
  private cycleInterval: number | null = null;
  private messageProcessingInterval: number | null = null;

  constructor() {
    super();
  }

  public async initialize(): Promise<void> {
    if (isMobile()) {
      console.log('Agent system disabled on mobile');
      this.emit('orchestrator:initialized', { agentCount: 0, mobile: true });
      return;
    }
    
    this.emit('orchestrator:initialized', { agentCount: this.agents.size });
  }

  public async start(): Promise<void> {
    if (isMobile()) {
      this.isRunning = false;
      return;
    }
    
    this.isRunning = true;
    this.emit('orchestrator:started');
  }

  public async stop(): Promise<void> {
    this.isRunning = false;
    
    if (this.cycleInterval) {
      clearInterval(this.cycleInterval);
      this.cycleInterval = null;
    }
    
    if (this.messageProcessingInterval) {
      clearInterval(this.messageProcessingInterval);
      this.messageProcessingInterval = null;
    }

    if (!isMobile()) {
      for (const [id, agent] of this.agents) {
        try {
          const state = agent.serialize();
          localStorage.setItem(`agent_state_${id}`, state);
        } catch (e) {
          console.warn('Failed to save agent state:', e);
        }
      }
    }

    for (const agent of this.agents.values()) {
      agent.cleanup();
    }

    this.emit('orchestrator:stopped');
  }

  public registerAgent(agent: BaseAgent): void {
    if (isMobile()) return;
    
    this.agents.set(agent.id, agent);
    
    agent.on('performance:critical', (data: any) => this.handleCriticalPerformance(data));
    agent.on('risk:emergency', (data: any) => this.handleRiskEmergency(data));
    agent.on('command:completed', (data: any) => this.handleCommandComplete(data));
    agent.on('command:failed', (data: any) => this.handleCommandFailed(data));

    this.emit('agent:spawned', { id: agent.id, role: agent.role, name: agent.name });
  }

  public async routeMessage(message: AgentMessage): Promise<void> {
    if (isMobile()) return;
    
    this.messageBus.push(message);
    setTimeout(() => this.processMessage(message), 0);
  }

  private async processMessage(message: AgentMessage): Promise<void> {
    try {
      if (message.to === 'BROADCAST') {
        const agentList = Array.from(this.agents.entries());
        for (let i = 0; i < agentList.length; i++) {
          const [id, agent] = agentList[i];
          if (id !== message.from && this.shouldReceive(agent, message)) {
            await agent.receiveMessage({ ...message, to: id });
            if (i % 5 === 0) await new Promise(r => setTimeout(r, 0));
          }
        }
      } else if (message.to === 'ORCHESTRATOR') {
        await this.handleOrchestratorMessage(message);
      } else {
        const target = this.agents.get(message.to);
        if (target) {
          await target.receiveMessage(message);
        }
      }
    } catch (e) {
      console.error('Message processing error:', e);
    }

    const maxMessages = isMobile() ? 50 : 1000;
    if (this.messageBus.length > maxMessages) {
      this.messageBus = this.messageBus.slice(-maxMessages / 2);
    }
  }

  private shouldReceive(agent: BaseAgent, message: AgentMessage): boolean {
    if (message.payload?.type === 'RISK_UPDATE' && agent.role !== 'RISK_MANAGER') return false;
    if (message.payload?.type === 'STRATEGY_UPDATE' && agent.role === 'RISK_MANAGER') return true;
    return true;
  }

  private async handleOrchestratorMessage(message: AgentMessage): Promise<void> {
    const { action, context } = message.payload || {};

    switch (action) {
      case 'ASSISTANCE_NEEDED':
        await this.provideAssistance(message.from, context);
        break;
    }
  }

  private async provideAssistance(agentId: string, _context: any): Promise<void> {
    if (isMobile()) return;
    
    const helper = this.findBestHelper(agentId);
    if (helper) {
      await this.routeMessage({
        from: 'ORCHESTRATOR',
        to: helper,
        type: 'COMMAND',
        payload: { action: 'ASSIST', target: agentId },
        timestamp: Date.now()
      });
    }
  }

  private findBestHelper(requesterId: string): string | null {
    if (isMobile()) return null;
    
    const requester = this.agents.get(requesterId);
    if (!requester) return null;

    const candidates = Array.from(this.agents.entries())
      .filter(([id, agent]) => id !== requesterId && agent.status === 'IDLE')
      .map(([id, agent]) => ({
        id,
        score: this.calculateHelperScore(agent, requester)
      }))
      .sort((a, b) => b.score - a.score);

    return candidates[0]?.id || null;
  }

  private calculateHelperScore(helper: BaseAgent, requester: BaseAgent): number {
    let score = 0;
    const complementaryPairs: Record<string, string[]> = {
      'STRATEGIST': ['RISK_MANAGER', 'ANALYST'],
      'RISK_MANAGER': ['STRATEGIST', 'EXECUTOR'],
      'LEARNER': ['STRATEGIST', 'ANALYST']
    };

    if (complementaryPairs[requester.role]?.includes(helper.role)) score += 0.4;
    const recentSuccess = helper.performance.calculateCompositeScore();
    score += recentSuccess * 0.3;
    if (helper.status === 'IDLE') score += 0.3;

    return score;
  }

  private handleCriticalPerformance(data: any): void {
    console.warn('Critical performance detected:', data);
  }

  private handleRiskEmergency(data: any): void {
    console.error('Risk emergency:', data);
  }

  private handleCommandComplete(data: any): void {
    console.log('Command completed:', data);
  }

  private handleCommandFailed(data: any): void {
    console.error('Command failed:', data);
  }

  public getSystemStatus(): any {
    if (isMobile()) {
      return { status: 'disabled', reason: 'mobile_mode', agents: [] };
    }
    
    return {
      active: this.isRunning,
      agents: Array.from(this.agents.entries()).map(([id, agent]) => ({
        id,
        role: agent.role,
        name: agent.name,
        status: agent.status,
        performance: agent.performance.calculateCompositeScore(),
        autonomy: agent.config.autonomyLevel
      })),
      messageQueue: this.messageBus.length
    };
  }
}
