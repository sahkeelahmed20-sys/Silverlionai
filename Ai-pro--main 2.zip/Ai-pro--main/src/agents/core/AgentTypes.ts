export interface AgentConfig {
  id: string;
  name: string;
  role?: string;
  capabilities?: string[];
  [key: string]: any;
}

export interface AgentDecision {
  action: 'BUY' | 'SELL' | 'HOLD' | 'STRONG_BUY' | 'STRONG_SELL';
  confidence: number;
  reason: string;
  metadata?: Record<string, any>;
}

export interface AgentMessage {
  type: string;
  payload: any;
  timestamp?: number;
  sender?: string;
}
