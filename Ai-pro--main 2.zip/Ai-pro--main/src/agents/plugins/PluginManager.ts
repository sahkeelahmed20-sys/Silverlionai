export interface AgentPlugin {
  name: string;
  version: string;
  capabilities: string[];
  hooks: {
    onPerception?: (data: any) => Promise<any>;
    onDecision?: (decision: any) => Promise<any>;
    onAction?: (action: any) => Promise<any>;
    onLearn?: (outcome: any) => Promise<any>;
  };
  config: Record<string, any>;
}

export class PluginManager {
  private plugins: Map<string, AgentPlugin> = new Map();
  private hooks: Map<string, Array<(data: any) => Promise<any>>> = new Map();

  public registerPlugin(plugin: AgentPlugin): void {
    this.plugins.set(plugin.name, plugin);
    
    Object.entries(plugin.hooks).forEach(([hookName, handler]) => {
      if (!handler) return;
      if (!this.hooks.has(hookName)) this.hooks.set(hookName, []);
      this.hooks.get(hookName)!.push(handler);
    });
    
    console.log(`🔌 Plugin registered: ${plugin.name} v${plugin.version}`);
  }

  public async executeHook(hookName: string, data: any): Promise<any> {
    const handlers = this.hooks.get(hookName) || [];
    let result = data;
    
    for (const handler of handlers) {
      try {
        result = await handler(result) || result;
      } catch (error) {
        console.error(`Plugin hook error in ${hookName}:`, error);
      }
    }
    
    return result;
  }

  public getPluginCapabilities(): string[] {
    return Array.from(this.plugins.values()).flatMap(p => p.capabilities);
  }
}

export const SentimentPlugin: AgentPlugin = {
  name: 'sentiment-analyzer',
  version: '1.0.0',
  capabilities: ['social-sentiment', 'news-analysis', 'fear-greed-index'],
  hooks: {
    onPerception: async (data: any) => {
      const sentiment = await fetchSentimentData(data?.symbol || 'BTC');
      return { ...data, sentiment };
    }
  },
  config: { sources: ['twitter', 'reddit', 'newsapi'] }
};

async function fetchSentimentData(_symbol: string): Promise<any> {
  return { score: Math.random() * 2 - 1, volume: Math.floor(Math.random() * 1000) };
}
