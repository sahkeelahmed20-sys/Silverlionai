export interface StrategyGene {
  id: string;
  parameters: {
    entryThreshold: number;
    exitThreshold: number;
    stopLoss: number;
    takeProfit: number;
    positionSizing: number;
    timeframe: string;
    indicators: string[];
  };
  preferredRegimes: string[];
  backtestResults?: {
    sharpeRatio: number;
    maxDrawdown: number;
    winRate: number;
    profitFactor: number;
  };
  parentIds?: string[];
  generation: number;
  createdAt: number;
  lastOptimized?: number;
}

export class StrategyEvolutionEngine {
  private population: StrategyGene[] = [];
  private generation: number = 0;
  private mutationRate: number = 0.1;

  constructor(initialPopulation: StrategyGene[] = []) {
    this.population = initialPopulation;
  }


  public evolve(marketData: any[], _regime: string): StrategyGene { // FIXED: Added underscore
    this.generation++;
    const parents = this.tournamentSelection(3);
    const offspring = this.blendCrossover(parents[0], parents[1]);
    const mutated = this.adaptiveMutation(offspring);
    mutated.backtestResults = this.backtest(mutated, marketData);
    mutated.generation = this.generation;
    this.replaceWorst(mutated);
    return mutated;
  }

  private tournamentSelection(tournamentSize: number): StrategyGene[] {
    const selected: StrategyGene[] = [];
    for (let i = 0; i < 2; i++) {
      const tournament: StrategyGene[] = [];
      for (let j = 0; j < tournamentSize; j++) {
        tournament.push(this.population[Math.floor(Math.random() * this.population.length)]);
      }
      tournament.sort((a, b) => (b.backtestResults?.sharpeRatio || 0) - (a.backtestResults?.sharpeRatio || 0));
      selected.push(tournament[0]);
    }
    return selected;
  }

  private blendCrossover(parent1: StrategyGene, parent2: StrategyGene): StrategyGene {
    const alpha = Math.random();
    return {
      id: `strategy_${Date.now()}`,
      parameters: {
        entryThreshold: alpha * parent1.parameters.entryThreshold + (1-alpha) * parent2.parameters.entryThreshold,
        exitThreshold: alpha * parent1.parameters.exitThreshold + (1-alpha) * parent2.parameters.exitThreshold,
        stopLoss: alpha * parent1.parameters.stopLoss + (1-alpha) * parent2.parameters.stopLoss,
        takeProfit: alpha * parent1.parameters.takeProfit + (1-alpha) * parent2.parameters.takeProfit,
        positionSizing: alpha * parent1.parameters.positionSizing + (1-alpha) * parent2.parameters.positionSizing,
        timeframe: Math.random() > 0.5 ? parent1.parameters.timeframe : parent2.parameters.timeframe,
        indicators: [...new Set([...parent1.parameters.indicators, ...parent2.parameters.indicators])].slice(0, 3)
      },
      preferredRegimes: [...new Set([...parent1.preferredRegimes, ...parent2.preferredRegimes])],
      parentIds: [parent1.id, parent2.id],
      generation: 0,
      createdAt: Date.now()
    };
  }

  private adaptiveMutation(strategy: StrategyGene): StrategyGene {
    const diversity = this.calculatePopulationDiversity();
    const adaptiveRate = this.mutationRate * (1 + (1 - diversity));
    const mutated = { ...strategy };

    if (Math.random() < adaptiveRate) {
      mutated.parameters.entryThreshold *= (1 + (Math.random() - 0.5) * 0.2);
    }
    if (Math.random() < adaptiveRate) {
      mutated.parameters.stopLoss *= (1 + (Math.random() - 0.5) * 0.3);
    }
    return mutated;
  }

  private backtest(strategy: StrategyGene, data: any[]): any {
    let equity = 10000;
    let maxDrawdown = 0;
    let peak = equity;
    let wins = 0;
    let losses = 0;
    let totalTrades = 0;

    for (let i = 50; i < data.length; i++) {
      const signal = this.generateSignal(strategy, data.slice(i-50, i));
      if (signal === 'BUY' && equity > 0) {
        const size = equity * strategy.parameters.positionSizing;
        const entry = data[i].close;
        const exit = data[i+1]?.close || entry;
        const pnl = (exit - entry) / entry * size;
        equity += pnl;
        totalTrades++;
        if (pnl > 0) wins++; else losses++;
        if (equity > peak) peak = equity;
        const drawdown = (peak - equity) / peak;
        if (drawdown > maxDrawdown) maxDrawdown = drawdown;
      }
    }

    const returns = (equity - 10000) / 10000;
    const winRate = wins / (totalTrades || 1);
    return {
      sharpeRatio: returns / (maxDrawdown || 1),
      maxDrawdown,
      winRate,
      profitFactor: wins / (losses || 1)
    };
  }

  private generateSignal(strategy: StrategyGene, data: any[]): 'BUY' | 'SELL' | 'HOLD' {
    const lastPrice = data[data.length - 1].close;
    const avgPrice = data.reduce((a: number, b: any) => a + b.close, 0) / data.length;
    const deviation = (lastPrice - avgPrice) / avgPrice;
    if (deviation < -strategy.parameters.entryThreshold) return 'BUY';
    if (deviation > strategy.parameters.exitThreshold) return 'SELL';
    return 'HOLD';
  }

  private calculatePopulationDiversity(): number {
    if (this.population.length < 2) return 1;
    let totalDistance = 0;
    let pairs = 0;
    for (let i = 0; i < this.population.length; i++) {
      for (let j = i + 1; j < this.population.length; j++) {
        totalDistance += this.strategyDistance(this.population[i], this.population[j]);
        pairs++;
      }
    }
    return totalDistance / (pairs || 1);
  }

  private strategyDistance(a: StrategyGene, b: StrategyGene): number {
    const keys = Object.keys(a.parameters) as Array<keyof typeof a.parameters>;
    const paramDiff = keys.reduce((sum, key) => {
      const valA = a.parameters[key];
      const valB = b.parameters[key];
      if (typeof valA === 'number' && typeof valB === 'number') {
        return sum + Math.abs(valA - valB);
      }
      return sum;
    }, 0);
    return paramDiff / keys.length;
  }

  private replaceWorst(offspring: StrategyGene): void {
    if (this.population.length < 20) {
      this.population.push(offspring);
    } else {
      const worst = this.population.reduce((min, curr) =>
        (curr.backtestResults?.sharpeRatio || -999) < (min.backtestResults?.sharpeRatio || -999) ? curr : min
      );
      const idx = this.population.indexOf(worst);
      if (offspring.backtestResults!.sharpeRatio > (worst.backtestResults?.sharpeRatio || 0)) {
        this.population[idx] = offspring;
      }
    }
  }

  public getBestStrategy(): StrategyGene | null {
    return this.population.sort((a, b) =>
      (b.backtestResults?.sharpeRatio || 0) - (a.backtestResults?.sharpeRatio || 0)
    )[0] || null;
  }
}

export function generateStrategy(regime: any, _symbol: string): StrategyGene {
  return {
    id: `strategy_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    parameters: {
      entryThreshold: 0.02,
      exitThreshold: 0.03,
      stopLoss: 0.015,
      takeProfit: 0.045,
      positionSizing: 0.1,
      timeframe: '1h',
      indicators: ['RSI', 'MACD']
    },
    preferredRegimes: [regime?.primary || 'NORMAL', regime?.secondary || 'MIXED'],
    generation: 0,
    createdAt: Date.now()
  };
}

export function evolveStrategy(parents: StrategyGene[], data: any[], regime: any, _learningRate: number): StrategyGene {
  const engine = new StrategyEvolutionEngine(parents);
  return engine.evolve(data, regime?.primary || 'NORMAL');
}
