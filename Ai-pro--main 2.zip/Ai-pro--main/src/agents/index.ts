// Core exports
export { BaseAgent, AgentOrchestrator, AgentPerformanceMetrics } from './core/AgentOrchestrator';
export type { AgentConfig, AgentDecision, AgentMessage, AgentRole, AgentStatus, AgentGoal, AgentMemory } from './core/AgentOrchestrator';

// Specialized agents
export { StrategistAgent } from './specialized/StrategistAgent';
export { RiskManagerAgent } from './specialized/RiskManagerAgent';
export { LearnerAgent } from './specialized/LearnerAgent';

// Integration
export { AgentPlatformAdapter, agentAdapter } from './integration/PlatformAdapter';

// Evolution
export { StrategyEvolutionEngine, generateStrategy, evolveStrategy } from './evolution/StrategyEvolution';

// Plugins
export { PluginManager, SentimentPlugin } from './plugins/PluginManager';
 