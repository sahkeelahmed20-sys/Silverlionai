import type { AgentConfig, AgentDecision } from '../core/AgentOrchestrator'; // FIXED: type-only imports
import { BaseAgent, AgentOrchestrator } from '../core/AgentOrchestrator';

interface Position {
  id: string;
  symbol: string;
  size: number;
  entryPrice: number;
  leverage: number;
  side: 'LONG' | 'SHORT';
}

type MarketRegime = 'LOW_VOLATILITY' | 'NORMAL' | 'HIGH_VOLATILITY' | 'CRISIS';

interface RiskLimits {
  maxPortfolioHeat: number;
  maxSinglePositionSize: number;
  maxCorrelationExposure: number;
  dailyLossLimit: number;
  varLimit: number;
}

export class RiskManagerAgent extends BaseAgent {
  private riskLimits: RiskLimits;

  constructor(orchestrator: AgentOrchestrator) {
    const config: AgentConfig = {
      role: 'RISK_MANAGER',
      name: 'SentinelRisk',
      autonomyLevel: 0.9,
      learningRate: 0.1,
      riskTolerance: 0.2,
      maxConcurrentTasks: 5,
      specialization: ['portfolio-risk', 'tail-risk', 'liquidity-risk', 'correlation-analysis']
    };
    super(config, orchestrator);

    this.riskLimits = {
      maxPortfolioHeat: 0.15,
      maxSinglePositionSize: 0.1,
      maxCorrelationExposure: 0.7,
      dailyLossLimit: 0.05,
      varLimit: 0.03
    };
  }

  async perceive(): Promise<any> {
    return {
      positions: [],
      marketStress: { level: 0.5 },
      volatilityRegime: 'NORMAL' as MarketRegime
    };
  }

  async think(data: any): Promise<AgentDecision> {
    const { positions, volatilityRegime } = data;
    const portfolioHeat = this.calculatePortfolioHeat(positions || []);
    const adjustedLimits = this.adaptLimitsToRegime(volatilityRegime || 'NORMAL');

    if (portfolioHeat > adjustedLimits.maxPortfolioHeat) {
      return {
        action: 'EMERGENCY_HEDGE',
        params: { portfolioHeat, targetHeat: adjustedLimits.maxPortfolioHeat * 0.6 },
        confidence: 0.95,
        reasoning: `Risk breach: Portfolio heat ${portfolioHeat.toFixed(2)} exceeds limit`
      };
    }

    if (portfolioHeat > adjustedLimits.maxPortfolioHeat * 0.8) {
      return {
        action: 'OPTIMIZE_EXPOSURE',
        params: { targetHeat: adjustedLimits.maxPortfolioHeat * 0.6, method: 'GRADUAL_REDUCTION' },
        confidence: 0.8,
        reasoning: 'Portfolio heat approaching limits'
      };
    }

    return {
      action: 'MONITOR',
      params: { currentMetrics: { portfolioHeat } },
      confidence: 0.9,
      reasoning: 'All risk metrics within acceptable bounds'
    };
  }

  async act(decision: AgentDecision): Promise<void> {
    switch (decision.action) {
      case 'EMERGENCY_HEDGE':
        this.emit('risk:emergency', decision.params);
        break;
      case 'OPTIMIZE_EXPOSURE':
        console.log('Optimizing exposure:', decision.params);
        break;
      case 'UPDATE_LIMITS':
        this.riskLimits = { ...this.riskLimits, ...decision.params };
        break;
    }
  }

  async learn(outcome: any): Promise<void> {
    if (outcome.riskEvent) {
      this.memory.episodic.push({
        context: JSON.stringify(outcome.riskEvent.context || {}),
        outcome: outcome.riskEvent.mitigationEffective ? 'SUCCESS' : 'PARTIAL',
        reward: outcome.riskEvent.mitigationEffective ? 1 : -0.5
      });
    }
  }

  private calculatePortfolioHeat(positions: Position[]): number {
    if (!positions || positions.length === 0) return 0;
    const totalValue = positions.reduce((sum, p) => sum + (p.size * p.entryPrice), 0);
    const weightedRisk = positions.reduce((sum, p) => {
      const volatility = 0.5;
      const size = (p.size * p.entryPrice) / (totalValue || 1);
      return sum + (size * volatility * p.leverage);
    }, 0);
    return weightedRisk;
  }

  private adaptLimitsToRegime(regime: MarketRegime): RiskLimits {
    const multipliers: Record<MarketRegime, { heat: number; position: number; var: number }> = {
      'LOW_VOLATILITY': { heat: 1.2, position: 1.1, var: 1.2 },
      'NORMAL': { heat: 1.0, position: 1.0, var: 1.0 },
      'HIGH_VOLATILITY': { heat: 0.6, position: 0.7, var: 0.6 },
      'CRISIS': { heat: 0.3, position: 0.4, var: 0.3 }
    };

    const m = multipliers[regime] || multipliers['NORMAL'];
    return {
      maxPortfolioHeat: this.riskLimits.maxPortfolioHeat * m.heat,
      maxSinglePositionSize: this.riskLimits.maxSinglePositionSize * m.position,
      maxCorrelationExposure: this.riskLimits.maxCorrelationExposure,
      dailyLossLimit: this.riskLimits.dailyLossLimit * m.heat,
      varLimit: this.riskLimits.varLimit * m.var
    };
  }

  protected async handleRequest(payload: any): Promise<any> {
    if (payload.action === 'GET_RISK_METRICS') {
      return {
        portfolioHeat: 0.1,
        limits: this.riskLimits,
        stressTestHistory: []
      };
    }
    if (payload.action === 'VALIDATE_TRADE') {
      return { valid: true };
    }
    return null;
  }

  protected async handleBroadcast(payload: any): Promise<void> {
    if (payload?.type === 'MARKET_CRASH_DETECTED') {
      await this.act({
        action: 'EMERGENCY_HEDGE',
        params: { urgency: 'IMMEDIATE', reason: 'System-wide market crash detected' },
        confidence: 1,
        reasoning: 'Autonomous crash protection activated'
      });
    }
  }
}
