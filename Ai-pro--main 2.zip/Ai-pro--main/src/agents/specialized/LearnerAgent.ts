import type { AgentConfig, AgentDecision } from '../core/AgentOrchestrator';
import { BaseAgent, AgentOrchestrator } from '../core/AgentOrchestrator';

// REMOVED: Unused LearningTask interface
// If you need it later, add underscore prefix: _LearningTask

class KnowledgeGraph {
  private nodes: Map<string, any> = new Map();
  private edges: Array<{from: string; to: string; weight: number; type: string}> = [];

  addCausalLink(factors: any): void {
    this.edges.push({
      from: factors.cause,
      to: factors.effect,
      weight: factors.strength,
      type: 'CAUSAL'
    });
  }

  serialize(): string {
    return JSON.stringify({ nodes: Array.from(this.nodes), edges: this.edges });
  }
}

class StrategyMemory {
  private embeddings: Map<string, number[]> = new Map();

  embedStrategy(strategy: any): void {
    const embedding = this.createEmbedding(strategy);
    this.embeddings.set(strategy.id, embedding);
  }

  findSimilar(target: any): any[] {
    const targetEmbedding = this.createEmbedding(target);
    const similarities = Array.from(this.embeddings.entries()).map(([id, emb]) => ({
      id,
      similarity: this.cosineSimilarity(targetEmbedding, emb)
    }));
    return similarities.sort((a, b) => b.similarity - a.similarity).slice(0, 5);
  }

  private createEmbedding(strategy: any): number[] {
    return [
      strategy.parameters?.complexity || 0.5,
      strategy.riskProfile || 0.5,
      strategy.performance?.avgReturn || 0,
      strategy.performance?.winRate || 0.5,
      strategy.marketRegimes?.length || 3
    ];
  }

  private cosineSimilarity(a: number[], b: number[]): number {
    const dot = a.reduce((sum, val, i) => sum + val * b[i], 0);
    const magA = Math.sqrt(a.reduce((sum, val) => sum + val * val, 0));
    const magB = Math.sqrt(b.reduce((sum, val) => sum + val * val, 0));
    return dot / (magA * magB || 1);
  }
}

class MetaCognitionEngine {
  private learningHistory: Array<{strategy: string; result: number; timestamp: number}> = [];

  evaluate(_performanceData: any[]): number { // FIXED: Added underscore prefix
    if (this.learningHistory.length < 10) return 0.5;
    const recent = this.learningHistory.slice(-10);
    const velocities = recent.slice(1).map((h, i) => h.result - recent[i].result);
    const avgVelocity = velocities.reduce((a, b) => a + b, 0) / velocities.length;
    const consistency = 1 - (Math.max(...velocities) - Math.min(...velocities));
    return (avgVelocity + 1) / 2 * consistency;
  }

  update(outcome: any): void {
    this.learningHistory.push({
      strategy: outcome.strategy,
      result: outcome.improvement,
      timestamp: Date.now()
    });
  }

  applyCorrection(bias: string): void {
    console.log(`Applying correction for ${bias}`);
  }
}

export class LearnerAgent extends BaseAgent {
  private knowledgeGraph: KnowledgeGraph;
  private strategyMemory: StrategyMemory;
  private metaCognition: MetaCognitionEngine;

  constructor(orchestrator: AgentOrchestrator) {
    const config: AgentConfig = {
      role: 'LEARNER',
      name: 'MetaLearner',
      autonomyLevel: 0.85,
      learningRate: 0.15,
      riskTolerance: 0.5,
      maxConcurrentTasks: 4,
      specialization: ['meta-learning', 'strategy-transfer', 'pattern-recognition', 'causal-inference']
    };
    super(config, orchestrator);

    this.knowledgeGraph = new KnowledgeGraph();
    this.strategyMemory = new StrategyMemory();
    this.metaCognition = new MetaCognitionEngine();
  }

  async perceive(): Promise<any> {
    return { performanceData: [], marketPatterns: [], failedStrategies: [] };
  }

  async think(data: any): Promise<AgentDecision> {
    const effectiveness = this.metaCognition.evaluate(data.performanceData || []);

    if (effectiveness < 0.4) {
      return {
        action: 'META_LEARN',
        params: { adjustment: 'INCREASE_EXPLORATION' },
        confidence: 0.8,
        reasoning: 'Learning stagnation detected'
      };
    }

    return {
      action: 'CONSOLIDATE',
      params: {},
      confidence: 0.9,
      reasoning: 'No critical learning gaps'
    };
  }

  async act(decision: AgentDecision): Promise<void> {
    switch (decision.action) {
      case 'META_LEARN':
        console.log('Adjusting learning strategy');
        break;
      case 'CONSOLIDATE':
        console.log('Consolidating memory');
        break;
    }
  }

  async learn(outcome: any): Promise<void> {
    if (outcome.newStrategy) {
      this.strategyMemory.embedStrategy(outcome.newStrategy);
    }
    if (outcome.causalFactors) {
      this.knowledgeGraph.addCausalLink(outcome.causalFactors);
    }
    this.metaCognition.update(outcome);
  }

  protected async handleRequest(payload: any): Promise<any> {
    if (payload.action === 'GET_KNOWLEDGE_GRAPH') {
      return this.knowledgeGraph.serialize();
    }
    return null;
  }

  protected async handleBroadcast(payload: any): Promise<void> {
    if (payload?.type === 'NEW_MARKET_REGIME') {
      console.log('Learning regime specifics:', payload.regime);
    }
  }
}
