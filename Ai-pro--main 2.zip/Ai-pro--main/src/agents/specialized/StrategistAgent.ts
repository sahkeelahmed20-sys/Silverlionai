import type { AgentConfig, AgentDecision, AgentMessage } from '../core/AgentTypes';
import { BaseAgent } from '../core/BaseAgent';
import type { MarketRegime } from '@/types';

type Timeframe = '1m' | '5m' | '15m' | '1h' | '4h' | '1d' | '1w';

interface Strategy {
  name: string;
  timeframe: Timeframe;
  indicators: string[];
  entryRules: ((data: any) => boolean)[];
  exitRules: ((data: any, position: any) => boolean)[];
  riskReward: number;
  winRate: number;
  avgReturn: number;
  lastUsed: number;
}

interface MarketContext {
  regime: MarketRegime;
  volatility: number;
  trendStrength: number;
  volumeProfile: 'high' | 'normal' | 'low';
  supportResistance: number[];
}

export class StrategistAgent extends BaseAgent {
  private strategies: Map<string, Strategy> = new Map();
  private activeStrategies: string[] = [];
  private marketContext: MarketContext | null = null;
  private performanceHistory: Map<string, number[]> = new Map();

  constructor(config: AgentConfig) {
    super({
      ...config,
      role: 'strategist',
      capabilities: ['strategy_optimization', 'regime_detection', 'multi_timeframe_analysis']
    });
    this.initializeStrategies();
  }

  private initializeStrategies(): void {
    // Trend Following Strategy
    this.strategies.set('trend_following', {
      name: 'Trend Following',
      timeframe: '1h',
      indicators: ['ema_20', 'ema_50', 'adx'],
      entryRules: [
        (data) => data.ema20 > data.ema50 && data.adx > 25,
        (data) => data.price > data.ema20 && data.volume > data.avgVolume * 1.5
      ],
      exitRules: [
        (data) => data.ema20 < data.ema50,
        (data) => data.adx < 20
      ],
      riskReward: 2.5,
      winRate: 0,
      avgReturn: 0,
      lastUsed: 0
    });

    // Mean Reversion Strategy
    this.strategies.set('mean_reversion', {
      name: 'Mean Reversion',
      timeframe: '15m',
      indicators: ['rsi', 'bollinger_bands', 'volume'],
      entryRules: [
        (data) => data.rsi < 30 && data.price < data.bbLower,
        (data) => data.volume > data.avgVolume * 2
      ],
      exitRules: [
        (data) => data.rsi > 50 || data.price > data.bbMiddle,
        (_data, pos) => pos.pnl > pos.entryPrice * 0.02
      ],
      riskReward: 1.8,
      winRate: 0,
      avgReturn: 0,
      lastUsed: 0
    });

    // Breakout Strategy
    this.strategies.set('breakout', {
      name: 'Breakout',
      timeframe: '4h',
      indicators: ['atr', 'volume', 'support_resistance'],
      entryRules: [
        (data) => data.price > data.resistance * 1.02 && data.volume > data.avgVolume * 2,
        (data) => data.atr > data.avgAtr * 1.5
      ],
      exitRules: [
        (data) => data.price < data.resistance * 0.98,
        (_data, pos) => pos.pnl < -pos.entryPrice * 0.015
      ],
      riskReward: 3.0,
      winRate: 0,
      avgReturn: 0,
      lastUsed: 0
    });

    // Scalping Strategy
    this.strategies.set('scalping', {
      name: 'Scalping',
      timeframe: '5m',
      indicators: ['rsi', 'macd', 'order_book_imbalance'],
      entryRules: [
        (data) => Math.abs(data.macdHistogram) > 0.001 && data.obImbalance > 0.6,
        (data) => data.rsi > 40 && data.rsi < 60
      ],
      exitRules: [
        (_data, pos) => pos.pnl > pos.entryPrice * 0.005,
        (_data, pos) => Date.now() - pos.openTime > 300000
      ],
      riskReward: 1.2,
      winRate: 0,
      avgReturn: 0,
      lastUsed: 0
    });
  }

  protected async onInitialize(): Promise<void> {
    console.log('Strategist Agent initialized with ' + this.strategies.size + ' strategies');
  }

  protected async onProcessMessage(message: AgentMessage): Promise<AgentDecision | null> {
    switch (message.type) {
      case 'market_update':
        return this.analyzeMarket(message.payload);
      case 'regime_change':
        return this.adaptToRegime(message.payload);
      case 'performance_report':
        this.updateStrategyPerformance(message.payload);
        return null;
      case 'optimize_request':
        return this.optimizeStrategies();
      default:
        return null;
    }
  }

  private async analyzeMarket(data: any): Promise<AgentDecision | null> {
    if (!this.marketContext) {
      this.detectMarketRegime(data);
    }

    const candidates: Array<{ strategy: Strategy; score: number }> = [];

    for (const [, strategy] of this.strategies) {
      const score = this.evaluateStrategy(strategy, data);
      if (score > 0.6) {
        candidates.push({ strategy, score });
      }
    }

    if (candidates.length === 0) return null;

    candidates.sort((a, b) => b.score - a.score);
    const selected = candidates[0];

    // Check entry rules
    const entrySignals = selected.strategy.entryRules.map(rule => rule(data));
    const confidence = entrySignals.filter(Boolean).length / entrySignals.length;

    if (confidence >= 0.5) {
      return {
        action: confidence > 0.75 ? 'STRONG_BUY' : 'BUY',
        confidence: confidence * selected.score,
        reason: `Strategy: ${selected.strategy.name} - ${entrySignals.filter(Boolean).length}/${entrySignals.length} entry conditions met`,
        metadata: {
          strategy: selected.strategy.name,
          timeframe: selected.strategy.timeframe,
          riskReward: selected.strategy.riskReward,
          expectedReturn: selected.strategy.avgReturn * confidence
        }
      };
    }

    return null;
  }

  private evaluateStrategy(strategy: Strategy, _data: any): number {
    let score = 0;
    const weights = {
      regimeFit: 0.3,
      winRate: 0.2,
      recency: 0.15,
      volatilityFit: 0.35
    };

    // Regime fit
    if (this.marketContext) {
      const regimeFit = this.calculateRegimeFit(strategy, this.marketContext.regime);
      score += regimeFit * weights.regimeFit;
    }

    // Historical win rate
    const history = this.performanceHistory.get(strategy.name) || [];
    const recentWinRate = history.length > 0 
      ? history.slice(-20).filter(r => r > 0).length / Math.min(history.length, 20)
      : 0.5;
    score += recentWinRate * weights.winRate;

    // Recency bonus (avoid overusing same strategy)
    const hoursSinceUse = (Date.now() - strategy.lastUsed) / 3600000;
    const recencyScore = Math.min(hoursSinceUse / 24, 1);
    score += recencyScore * weights.recency;

    // Volatility fit
    if (this.marketContext) {
      const volFit = this.calculateVolatilityFit(strategy, this.marketContext.volatility);
      score += volFit * weights.volatilityFit;
    }

    return score;
  }

  private calculateRegimeFit(strategy: Strategy, regime: MarketRegime): number {
    const fits: Record<string, Record<MarketRegime, number>> = {
      'Trend Following': { TREND: 0.9, CHOP: 0.3, RANGE: 0.4, PANIC: 0.2, BREAKOUT: 0.5 },
      'Mean Reversion': { TREND: 0.3, CHOP: 0.8, RANGE: 0.9, PANIC: 0.3, BREAKOUT: 0.4 },
      'Breakout': { TREND: 0.8, CHOP: 0.5, RANGE: 0.7, PANIC: 0.4, BREAKOUT: 0.95 },
      'Scalping': { TREND: 0.6, CHOP: 0.7, RANGE: 0.5, PANIC: 0.3, BREAKOUT: 0.6 }
    };

    return fits[strategy.name]?.[regime] || 0.5;
  }

  private calculateVolatilityFit(strategy: Strategy, volatility: number): number {
    const optimalVols: Record<string, number> = {
      'Trend Following': 0.25,
      'Mean Reversion': 0.4,
      'Breakout': 0.5,
      'Scalping': 0.3
    };

    const optimal = optimalVols[strategy.name] || 0.3;
    const diff = Math.abs(volatility - optimal);
    return Math.max(0, 1 - diff * 2);
  }

  private detectMarketRegime(data: any): void {
    // Calculate trend strength
    const ema20 = data.ema20 || data.price;
    const ema50 = data.ema50 || data.price;
    const trendStrength = Math.abs((ema20 - ema50) / ema50);

    // Calculate volatility
    const atr = data.atr || data.price * 0.02;
    const volatility = atr / data.price;

    // Volume profile
    const volumeRatio = data.volume / (data.avgVolume || data.volume);
    const volumeProfile = volumeRatio > 1.5 ? 'high' : volumeRatio < 0.7 ? 'low' : 'normal';

    // Determine regime - only use valid MarketRegime values
    let regime: MarketRegime = 'RANGE';
    if (trendStrength > 0.05 && volatility > 0.03) regime = 'TREND';
    else if (trendStrength < 0.01 && volatility < 0.02) regime = 'CHOP';
    else if (data.price < (data.ema200 || data.price) * 0.95) regime = 'PANIC';

    this.marketContext = {
      regime,
      volatility,
      trendStrength,
      volumeProfile,
      supportResistance: data.levels || []
    };
  }

  private adaptToRegime(regime: MarketRegime): AgentDecision {
    this.marketContext = { 
      ...this.marketContext!, 
      regime 
    };

    // Select best strategies for new regime
    const ranked = Array.from(this.strategies.entries())
      .map(([, strategy]) => ({
        strategy,
        fit: this.calculateRegimeFit(strategy, regime)
      }))
      .sort((a, b) => b.fit - a.fit);

    this.activeStrategies = ranked.slice(0, 2).map(s => this.getStrategyId(s.strategy));

    return {
      action: 'HOLD',
      confidence: 0.7,
      reason: `Adapted to ${regime} regime. Active strategies: ${this.activeStrategies.map(id => this.strategies.get(id)?.name).join(', ')}`,
      metadata: {
        regime,
        activeStrategies: this.activeStrategies,
        strategyFitness: ranked.slice(0, 3).map(s => ({ name: s.strategy.name, fit: s.fit }))
      }
    };
  }

  private getStrategyId(strategy: Strategy): string {
    for (const [id, s] of this.strategies) {
      if (s.name === strategy.name) return id;
    }
    return '';
  }

  private updateStrategyPerformance(report: { strategy: string; return: number }): void {
    const history = this.performanceHistory.get(report.strategy) || [];
    history.push(report.return);
    
    // Keep last 100 trades
    if (history.length > 100) history.shift();
    
    this.performanceHistory.set(report.strategy, history);

    // Update strategy stats
    const strategyId = report.strategy.toLowerCase().replace(' ', '_');
    const strategy = this.strategies.get(strategyId);
    if (strategy) {
      strategy.winRate = history.filter(r => r > 0).length / history.length;
      strategy.avgReturn = history.reduce((a, b) => a + b, 0) / history.length;
      strategy.lastUsed = Date.now();
    }
  }

  private optimizeStrategies(): AgentDecision {
    const optimizations: Array<{ strategy: string; improvement: number }> = [];

    for (const [, strategy] of this.strategies) {
      const history = this.performanceHistory.get(strategy.name) || [];
      if (history.length < 10) continue;

      const currentWinRate = history.filter(r => r > 0).length / history.length;
      const currentAvgReturn = history.reduce((a, b) => a + b, 0) / history.length;

      // Simulate parameter adjustments
      const improvedRR = strategy.riskReward * (currentWinRate > 0.5 ? 1.1 : 0.9);
      const expectedImprovement = (improvedRR - strategy.riskReward) * currentAvgReturn;

      optimizations.push({
        strategy: strategy.name,
        improvement: expectedImprovement
      });

      // Apply optimization
      if (expectedImprovement > 0) {
        strategy.riskReward = improvedRR;
      }
    }

    return {
      action: 'HOLD',
      confidence: 0.6,
      reason: `Optimized ${optimizations.length} strategies`,
      metadata: {
        optimizations: optimizations.sort((a, b) => b.improvement - a.improvement).slice(0, 3)
      }
    };
  }

  public getActiveStrategies(): string[] {
    return this.activeStrategies;
  }

  public getMarketContext(): MarketContext | null {
    return this.marketContext;
  }

  public getStrategyPerformance(): Record<string, { winRate: number; avgReturn: number; trades: number }> {
    const result: Record<string, { winRate: number; avgReturn: number; trades: number }> = {};
    
    for (const [, strategy] of this.strategies) {
      const history = this.performanceHistory.get(strategy.name) || [];
      result[strategy.name] = {
        winRate: strategy.winRate,
        avgReturn: strategy.avgReturn,
        trades: history.length
      };
    }
    
    return result;
  }
}
