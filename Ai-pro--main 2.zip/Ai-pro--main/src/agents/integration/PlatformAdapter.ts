import { AgentOrchestrator } from '../core/AgentOrchestrator';

// Mobile detection
const isMobile = () => /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);

// Stub implementations for missing imports
const useTradingStore = {
  subscribe: (_callback: (state: any) => void) => () => {},
  getState: () => ({
    positions: [] as any[],
    balance: 0,
    addPosition: async (_position: any) => {},
    closePosition: async (_id: string, _reason: string) => {}
  }),
  setState: (_updater: any) => {}
};

const binanceWS = {
  onMessage: null as ((data: any) => void) | null
};

export class AgentPlatformAdapter {
  private orchestrator: AgentOrchestrator;
  private unsubscribeFunctions: Array<() => void> = [];
  private isInitialized: boolean = false;
  private messageQueue: Array<any> = [];
  private isProcessing: boolean = false;

  constructor() {
    this.orchestrator = new AgentOrchestrator();
    // Don't setup listeners yet - wait for initialize
  }

  public async initialize(): Promise<void> {
    if (this.isInitialized) return;
    
    try {
      // Mobile: Skip heavy agent initialization
      if (isMobile()) {
        console.log('📱 Mobile detected - running lightweight agent mode');
        this.isInitialized = true;
        return;
      }

      await this.orchestrator.initialize();
      this.setupEventListeners();
      
      // Delay store connections to prevent blocking render
      setTimeout(() => {
        this.connectToTradingStore();
        this.connectToMarketData();
        this.connectToDemoTrading();
      }, 1000);
      
      await this.orchestrator.start();
      
      this.isInitialized = true;
      console.log('🧠 Self-Organizing AI Agent Framework activated');
    } catch (error) {
      console.error('Failed to initialize agent framework:', error);
      // Don't crash - continue without agents
      this.isInitialized = false;
    }
  }

  public async validateSignal(signal: any): Promise<{approved: boolean; reason?: string}> {
    if (!this.isInitialized) return { approved: true };
    
    // Mobile: Skip validation
    if (isMobile()) return { approved: true };
    
    try {
      const riskManager = Array.from((this.orchestrator as any).agents?.values() || [])
        .find((a: any) => a.role === 'RISK_MANAGER');
      
      if (riskManager) {
        // Queue message instead of immediate send
        this.queueMessage({
          from: 'PLATFORM',
          to: (riskManager as any).id,
          type: 'REQUEST' as const,
          payload: { action: 'VALIDATE_SIGNAL', signal },
          timestamp: Date.now(),
          correlationId: `sig_${Date.now()}`
        });
        
        return { approved: true };
      }
    } catch (e) {
      console.warn('Signal validation error:', e);
    }
    
    return { approved: true };
  }

  public updateAIState(enabled: boolean): void {
    if (!this.isInitialized || isMobile()) return;
    
    this.queueMessage({
      from: 'PLATFORM',
      to: 'BROADCAST',
      type: 'BROADCAST',
      payload: { type: 'AI_STATE_CHANGE', enabled, timestamp: Date.now() },
      timestamp: Date.now()
    });
  }

  public updateBalance(balance: number): void {
    if (!this.isInitialized || isMobile()) return;
    
    this.queueMessage({
      from: 'PLATFORM',
      to: 'RISK_MANAGER',
      type: 'BROADCAST',
      payload: { type: 'BALANCE_UPDATE', balance, timestamp: Date.now() },
      timestamp: Date.now()
    });
  }

  private queueMessage(message: any): void {
    this.messageQueue.push(message);
    this.processQueue();
  }

  private async processQueue(): Promise<void> {
    if (this.isProcessing || this.messageQueue.length === 0) return;
    
    this.isProcessing = true;
    
    // Process one message at a time to prevent blocking
    while (this.messageQueue.length > 0) {
      const message = this.messageQueue.shift();
      try {
        await this.orchestrator.routeMessage(message);
      } catch (e) {
        console.warn('Message routing error:', e);
      }
      // Small delay to prevent blocking UI
      await new Promise(resolve => setTimeout(resolve, 0));
    }
    
    this.isProcessing = false;
  }

  private setupEventListeners(): void {
    // Wrap handlers in try-catch to prevent crashes
    this.orchestrator.on('risk:emergency', (data: any) => {
      try {
        console.error('🚨 Agent Risk Emergency:', data);
        this.executeEmergencyProtocol(data);
      } catch (e) {
        console.error('Emergency protocol error:', e);
      }
    });

    this.orchestrator.on('approval:required', (data: any) => {
      try {
        this.showApprovalRequest(data);
      } catch (e) {
        console.error('Approval request error:', e);
      }
    });

    this.orchestrator.on('agent:spawned', (data: any) => {
      console.log(`🤖 New agent spawned: ${data.name} (${data.role})`);
    });
  }

  private connectToTradingStore(): void {
    if (isMobile()) return; // Skip on mobile
    
    try {
      const unsubscribe = useTradingStore.subscribe((state: any) => {
        if (state.positions.length > 0) {
          this.queueMessage({
            from: 'PLATFORM',
            to: 'RISK_MANAGER',
            type: 'BROADCAST',
            payload: {
              type: 'POSITION_UPDATE',
              positions: state.positions,
              equity: state.balance,
              timestamp: Date.now()
            },
            timestamp: Date.now()
          });
        }
      });
      this.unsubscribeFunctions.push(unsubscribe);
    } catch (e) {
      console.warn('Trading store connection error:', e);
    }
  }

  private connectToMarketData(): void {
    if (isMobile()) return; // Skip on mobile
    
    try {
      const handlePriceUpdate = (data: any) => {
        // Throttle updates - max 1 per second
        if (this.throttle('priceUpdate', 1000)) {
          this.queueMessage({
            from: 'PLATFORM',
            to: 'BROADCAST',
            type: 'BROADCAST',
            payload: {
              type: 'PRICE_TICK',
              symbol: data.symbol,
              price: data.price,
              volume: data.volume,
              timestamp: Date.now()
            },
            timestamp: Date.now()
          });
        }
      };

      // Don't override - use addEventListener pattern instead
      const originalCallback = (binanceWS as any).onMessage;
      (binanceWS as any).onMessage = (data: any) => {
        handlePriceUpdate(data);
        if (originalCallback) originalCallback(data);
      };
    } catch (e) {
      console.warn('Market data connection error:', e);
    }
  }

  private connectToDemoTrading(): void {
    if (isMobile()) return; // Skip on mobile
    
    try {
      const store = useTradingStore.getState();
      const originalAddPosition = store.addPosition;
      
      useTradingStore.setState({
        addPosition: async (position: any) => {
          try {
            const validation = await this.validateTrade(position);
            if (validation.approved) {
              const optimizedPosition = validation.adjustments 
                ? { ...position, ...validation.adjustments }
                : position;
              return originalAddPosition(optimizedPosition);
            } else {
              this.showTradeBlockedNotification(validation.reason || 'Trade blocked');
              return null;
            }
          } catch (e) {
            console.error('Trade validation error:', e);
            return originalAddPosition(position);
          }
        }
      });
    } catch (e) {
      console.warn('Demo trading connection error:', e);
    }
  }

  private async validateTrade(_position: any): Promise<{approved: boolean; adjustments?: any; reason?: string}> {
    return { approved: true };
  }

  private async executeEmergencyProtocol(data: any): Promise<void> {
    try {
      const store = useTradingStore.getState();
      if (data.params?.urgency === 'IMMEDIATE') {
        const riskyPositions = store.positions
          .sort((a: any, b: any) => (b.size * b.leverage) - (a.size * a.leverage))
          .slice(0, Math.ceil(store.positions.length / 2));
        
        for (const pos of riskyPositions) {
          await store.closePosition(pos.id as string, 'AGENT_EMERGENCY_CLOSE');
        }
      }
    } catch (e) {
      console.error('Emergency protocol execution error:', e);
    }
  }

  private showApprovalRequest(data: any): void {
    try {
      window.dispatchEvent(new CustomEvent('agent:approval_required', {
        detail: {
          agentId: data.agentId,
          action: data.decision?.action,
          params: data.decision?.params,
          confidence: data.decision?.confidence,
          reasoning: data.decision?.reasoning
        }
      }));
    } catch (e) {
      console.error('Approval request display error:', e);
    }
  }

  private showTradeBlockedNotification(reason: string): void {
    try {
      window.dispatchEvent(new CustomEvent('agent:trade_blocked', {
        detail: { reason, timestamp: Date.now() }
      }));
    } catch (e) {
      console.error('Trade blocked notification error:', e);
    }
  }

  // Simple throttle helper
  private throttleCache: Map<string, number> = new Map();
  private throttle(key: string, delay: number): boolean {
    const now = Date.now();
    const last = this.throttleCache.get(key) || 0;
    if (now - last > delay) {
      this.throttleCache.set(key, now);
      return true;
    }
    return false;
  }

  public getAgentStatus(): any {
    if (!this.isInitialized || isMobile()) {
      return { status: 'disabled', reason: isMobile() ? 'mobile_mode' : 'not_initialized' };
    }
    return this.orchestrator.getSystemStatus();
  }

  public async shutdown(): Promise<void> {
    try {
      this.unsubscribeFunctions.forEach(fn => {
        try { fn(); } catch (e) { /* ignore */ }
      });
      if (!isMobile()) {
        await this.orchestrator.stop();
      }
    } catch (e) {
      console.error('Shutdown error:', e);
    }
    this.isInitialized = false;
  }
}

export const agentAdapter = new AgentPlatformAdapter();
