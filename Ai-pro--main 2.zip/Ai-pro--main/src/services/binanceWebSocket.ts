export interface PriceData {
  symbol: string;
  price: number;
  change24h: number;
  volume: number;
  high24h: number;
  low24h: number;
  timestamp: number;
}

export interface OrderBookData {
  bids: [string, string][];
  asks: [string, string][];
  lastUpdateId: number;
}

interface TickerData {
  s: string;
  c: string;
  P: string;
  v: string;
  h: string;
  l: string;
}

interface CombinedStreamMessage {
  stream: string;
  data: TickerData;
}

class BinanceWebSocket {
  private ws: WebSocket | null = null;
  private subscribers: Map<string, Set<(symbol: string, price: number, change24h: number) => void>> = new Map();
  private tickerSubscribers: Map<string, Set<(data: PriceData) => void>> = new Map();
  private orderBookSubscribers: Set<(data: OrderBookData) => void> = new Set();
  private mapSubscribers: Set<(prices: Map<string, PriceData>) => void> = new Set();
  private priceData: Map<string, PriceData> = new Map();
  private reconnectAttempts = 0;
  private maxReconnectAttempts = 5;
  private reconnectDelay = 3000;
  private subscribedSymbols: string[] = [];
  
  private orderBookWs: WebSocket | null = null;
  private heartbeatInterval: ReturnType<typeof setInterval> | null = null;

  // Convert BTC/USDT format to btcusdt for Binance
  private normalizeSymbol(symbol: string): string {
    return symbol.replace('/', '').toLowerCase();
  }

  // Convert btcusdt back to BTC/USDT
  private formatSymbol(symbol: string): string {
    // Handle USDT pairs
    if (symbol.endsWith('usdt')) {
      return symbol.replace('usdt', '/USDT').toUpperCase();
    }
    // Handle other quote currencies
    if (symbol.endsWith('btc')) {
      return symbol.replace('btc', '/BTC').toUpperCase();
    }
    if (symbol.endsWith('eth')) {
      return symbol.replace('eth', '/ETH').toUpperCase();
    }
    return symbol.toUpperCase();
  }

  connect(symbols: string[] = ['BTC/USDT', 'ETH/USDT', 'SOL/USDT']): void {
    if (this.ws?.readyState === WebSocket.OPEN) return;
    
    // Store original format symbols
    this.subscribedSymbols = symbols;
    
    // Convert to Binance format
    const binanceSymbols = symbols.map(s => this.normalizeSymbol(s));
    const streams = binanceSymbols.map(s => `${s}@ticker`).join('/');
    
    // Use combined stream endpoint
    const url = `wss://stream.binance.com:9443/stream?streams=${streams}`;

    console.log('[BinanceWS] Connecting to:', url);

    try {
      this.ws = new WebSocket(url);
      
      this.ws.onopen = () => {
        console.log('[BinanceWS] Connected');
        this.reconnectAttempts = 0;
        this.startHeartbeat();
      };
      
      this.ws.onmessage = (event) => {
        try {
          const message: CombinedStreamMessage = JSON.parse(event.data);
          const data = message.data;
          const streamSymbol = message.stream.replace('@ticker', '');
          const symbol = this.formatSymbol(streamSymbol);
          
          const price = parseFloat(data.c);
          const change24h = parseFloat(data.P);
          const volume = parseFloat(data.v);
          const high24h = parseFloat(data.h);
          const low24h = parseFloat(data.l);
          
          const priceData: PriceData = { 
            symbol, 
            price, 
            change24h, 
            volume, 
            high24h, 
            low24h, 
            timestamp: Date.now() 
          };
          
          this.priceData.set(symbol, priceData);
          
          // Notify symbol-specific subscribers
          const subs = this.subscribers.get(symbol);
          if (subs) subs.forEach(cb => cb(symbol, price, change24h));
          
          // Notify general subscribers (key 'all')
          const allSubs = this.subscribers.get('all');
          if (allSubs) allSubs.forEach(cb => cb(symbol, price, change24h));
          
          // Notify ticker subscribers
          const tickerSubs = this.tickerSubscribers.get(symbol);
          if (tickerSubs) tickerSubs.forEach(cb => cb(priceData));
          
          // Notify map subscribers
          this.mapSubscribers.forEach(cb => cb(new Map(this.priceData)));
          
        } catch (error) { 
          console.error('[BinanceWS] Error parsing message:', error); 
        }
      };
      
      this.ws.onerror = (error) => {
        console.error('[BinanceWS] Error:', error);
      };
      
      this.ws.onclose = () => {
        console.log('[BinanceWS] Disconnected');
        this.stopHeartbeat();
        this.attemptReconnect();
      };
      
    } catch (error) { 
      console.error('[BinanceWS] Failed to connect:', error); 
    }
  }

  private startHeartbeat(): void {
    // Binance sends ping every 20 seconds, we need to respond with pong
    // But we'll also send our own ping to keep connection alive
    this.heartbeatInterval = setInterval(() => {
      if (this.ws?.readyState === WebSocket.OPEN) {
        // Send pong response (empty payload as recommended)
        this.ws.send(JSON.stringify({ pong: Date.now() }));
      }
    }, 30000);
  }

  private stopHeartbeat(): void {
    if (this.heartbeatInterval) { 
      clearInterval(this.heartbeatInterval); 
      this.heartbeatInterval = null; 
    }
  }

  private attemptReconnect(): void {
    if (this.reconnectAttempts < this.maxReconnectAttempts) {
      this.reconnectAttempts++;
      console.log(`[BinanceWS] Reconnecting... Attempt ${this.reconnectAttempts}/${this.maxReconnectAttempts}`);
      setTimeout(() => this.connect(this.subscribedSymbols), this.reconnectDelay);
    } else {
      console.error('[BinanceWS] Max reconnect attempts reached');
    }
  }

  subscribe(callback: (symbol: string, price: number, change24h: number) => void): () => void {
    const key = 'all';
    if (!this.subscribers.has(key)) this.subscribers.set(key, new Set());
    this.subscribers.get(key)!.add(callback);
    
    // Auto-connect if not connected
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) {
      this.connect();
    }
    
    return () => this.subscribers.get(key)?.delete(callback);
  }

  subscribeToSymbol(symbol: string, callback: (symbol: string, price: number, change24h: number) => void): () => void {
    if (!this.subscribers.has(symbol)) this.subscribers.set(symbol, new Set());
    this.subscribers.get(symbol)!.add(callback);
    
    // Auto-connect if not connected
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) {
      this.connect();
    }
    
    return () => this.subscribers.get(symbol)?.delete(callback);
  }

  subscribeToTicker(symbol: string, callback: (data: PriceData) => void): () => void {
    if (!this.tickerSubscribers.has(symbol)) this.tickerSubscribers.set(symbol, new Set());
    this.tickerSubscribers.get(symbol)!.add(callback);
    
    // Auto-connect if not connected
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) {
      this.connect();
    }
    
    return () => this.tickerSubscribers.get(symbol)?.delete(callback);
  }

  subscribeToMap(callback: (prices: Map<string, PriceData>) => void): () => void {
    this.mapSubscribers.add(callback);
    
    // Auto-connect if not connected
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) {
      this.connect();
    }
    
    return () => this.mapSubscribers.delete(callback);
  }

  getPriceData(symbol: string): PriceData | undefined { 
    return this.priceData.get(symbol); 
  }
  
  getAllPriceData(): PriceData[] { 
    return Array.from(this.priceData.values()); 
  }
  
  getStatus(): boolean { 
    return this.ws?.readyState === WebSocket.OPEN; 
  }

  subscribeToOrderBook(symbol: string, callback: (data: OrderBookData) => void): () => void {
    if (this.orderBookWs) this.orderBookWs.close();
    
    this.orderBookSubscribers.clear();
    this.orderBookSubscribers.add(callback);
    
    const binanceSymbol = this.normalizeSymbol(symbol);
    const url = `wss://stream.binance.com:9443/ws/${binanceSymbol}@depth20@100ms`;
    
    try {
      this.orderBookWs = new WebSocket(url);
      this.orderBookWs.onopen = () => console.log(`[BinanceWS] Order book ${symbol}`);
      this.orderBookWs.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          this.orderBookSubscribers.forEach(cb => cb({ 
            bids: data.bids || [], 
            asks: data.asks || [], 
            lastUpdateId: data.lastUpdateId || 0 
          }));
        } catch (error) { 
          console.error('[BinanceWS] Order book error:', error); 
        }
      };
    } catch (error) { 
      console.error('[BinanceWS] Failed to connect order book:', error); 
    }
    
    return () => this.orderBookSubscribers.delete(callback);
  }

  unsubscribeFromOrderBook(): void {
    if (this.orderBookWs) { 
      this.orderBookWs.close(); 
      this.orderBookWs = null; 
    }
    this.orderBookSubscribers.clear();
  }

  disconnect(): void {
    this.stopHeartbeat();
    if (this.ws) { 
      this.ws.close(); 
      this.ws = null; 
    }
    if (this.orderBookWs) { 
      this.orderBookWs.close(); 
      this.orderBookWs = null; 
    }
    this.subscribers.clear(); 
    this.tickerSubscribers.clear(); 
    this.mapSubscribers.clear();
    this.orderBookSubscribers.clear(); 
    this.priceData.clear();
  }
}

export const binanceWS = new BinanceWebSocket();
export default binanceWS;
