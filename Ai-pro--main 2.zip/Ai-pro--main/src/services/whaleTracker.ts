export interface WhaleTransaction {
  id: string;
  symbol: string;
  amount: number;
  valueUsd: number;
  type: 'inflow' | 'outflow' | 'transfer';
  from: string;
  to: string;
  timestamp: number;
  blockchain: string;
  txHash: string;
}

export interface WhaleAlert {
  symbol: string;
  direction: 'accumulation' | 'distribution' | 'neutral';
  confidence: number;
  transactions: WhaleTransaction[];
  totalValue: number;
  impact: 'high' | 'medium' | 'low';
  timestamp: number;
}

// Mobile detection
const isMobile = () => /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);

export class WhaleTrackerService {
  private whaleAlertApiKey: string | null = null;
  private transactions: WhaleTransaction[] = [];
  private subscribers: Set<(alert: WhaleAlert) => void> = new Set();
  private intervals: number[] = [];
  private ws: WebSocket | null = null;
  private isRunning = false;
  private lastAnalysis = 0;
  private analysisThrottle = 5000; // Min 5 seconds between analyses
  
  setApiKey(key: string) {
    this.whaleAlertApiKey = key;
  }

  startTracking(symbols: string[]) {
    if (this.isRunning) return; // Prevent multiple starts
    this.isRunning = true;
    
    // Mobile: Skip whale tracking entirely or reduce significantly
    if (isMobile()) {
      console.log('[WhaleTracker] Mobile detected - running lightweight mode');
      this.startMobileMode(symbols);
      return;
    }

    if (this.whaleAlertApiKey) {
      this.connectWhaleAlertWebSocket();
    } else {
      this.startSimulation(symbols);
    }
  }

  stopTracking() {
    this.isRunning = false;
    
    // Clear all intervals
    this.intervals.forEach(id => clearInterval(id));
    this.intervals = [];
    
    // Close WebSocket
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
    
    // Clear transactions to free memory
    this.transactions = [];
    this.subscribers.clear();
  }

  private startMobileMode(symbols: string[]) {
    // Mobile: Generate 1 alert every 2 minutes instead of every 30 seconds
    const interval = window.setInterval(() => {
      if (!this.isRunning) return;
      
      const symbol = symbols[Math.floor(Math.random() * symbols.length)];
      this.generateMobileWhaleActivity(symbol);
    }, 120000); // 2 minutes
    
    this.intervals.push(interval);
  }

  private generateMobileWhaleActivity(symbol: string) {
    // Simplified activity for mobile
    const isAccumulation = Math.random() > 0.5;
    const valueUsd = Math.random() * 5000000 + 1000000; // $1M-$6M
    
    const tx: WhaleTransaction = {
      id: `mob_${Date.now()}`,
      symbol: symbol.replace('USDT', '').replace('USD', ''),
      amount: valueUsd / 30000, // Approximate BTC/ETH amount
      valueUsd: valueUsd,
      type: isAccumulation ? 'outflow' : 'inflow',
      from: isAccumulation ? 'Exchange' : 'Wallet',
      to: isAccumulation ? 'Wallet' : 'Exchange',
      timestamp: Date.now(),
      blockchain: symbol.includes('BTC') ? 'bitcoin' : 'ethereum',
      txHash: `0x${Math.random().toString(16).substr(2, 16)}` // Shorter hash
    };
    
    this.transactions.push(tx);
    
    // Strict limit for mobile
    const maxTx = isMobile() ? 50 : 1000;
    if (this.transactions.length > maxTx) {
      this.transactions = this.transactions.slice(-maxTx);
    }
    
    // Throttled analysis
    this.throttledAnalysis(symbol);
  }

  private connectWhaleAlertWebSocket() {
    if (!this.whaleAlertApiKey || isMobile()) return;
    
    try {
      this.ws = new WebSocket(`wss://leviathan.whale-alert.io/ws?api_key=${this.whaleAlertApiKey}`);
      
      this.ws.onopen = () => {
        console.log('[WhaleTracker] Connected to Whale Alert');
        const subscription = {
          type: 'subscribe_alerts',
          blockchains: ['bitcoin', 'ethereum'],
          symbols: ['btc', 'eth', 'usdt', 'usdc'],
          min_value_usd: 100000
        };
        this.ws?.send(JSON.stringify(subscription));
      };
      
      this.ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          this.processWhaleAlert(data);
        } catch (error) {
          console.error('[WhaleTracker] Error parsing alert:', error);
        }
      };
      
      this.ws.onerror = (error) => {
        console.error('[WhaleTracker] WebSocket error:', error);
        // Don't crash - fallback to simulation
        this.startSimulation(['BTCUSDT', 'ETHUSDT']);
      };
      
      this.ws.onclose = () => {
        if (!this.isRunning) return;
        console.log('[WhaleTracker] Disconnected, reconnecting...');
        setTimeout(() => this.connectWhaleAlertWebSocket(), 5000);
      };
    } catch (e) {
      console.error('[WhaleTracker] WebSocket connection failed:', e);
    }
  }

  private processWhaleAlert(data: any) {
    if (!data.amounts || data.amounts.length === 0) return;
    
    const tx: WhaleTransaction = {
      id: data.transaction?.hash || Date.now().toString(),
      symbol: data.amounts[0].symbol.toUpperCase(),
      amount: data.amounts[0].amount,
      valueUsd: data.amounts[0].value_usd,
      type: this.classifyTransactionType(data.from, data.to),
      from: data.from,
      to: data.to,
      timestamp: data.timestamp * 1000,
      blockchain: data.blockchain,
      txHash: data.transaction?.hash
    };
    
    this.transactions.push(tx);
    
    // Memory management
    const maxTx = isMobile() ? 50 : 1000;
    if (this.transactions.length > maxTx) {
      this.transactions = this.transactions.slice(-maxTx);
    }
    
    this.throttledAnalysis(tx.symbol);
  }

  private classifyTransactionType(from: string, to: string): 'inflow' | 'outflow' | 'transfer' {
    const exchangeKeywords = ['exchange', 'binance', 'coinbase', 'kraken', 'kucoin', 'okx'];
    const fromIsExchange = exchangeKeywords.some(k => from.toLowerCase().includes(k));
    const toIsExchange = exchangeKeywords.some(k => to.toLowerCase().includes(k));
    
    if (!fromIsExchange && toIsExchange) return 'inflow';
    if (fromIsExchange && !toIsExchange) return 'outflow';
    return 'transfer';
  }

  private startSimulation(symbols: string[]) {
    if (isMobile()) {
      this.startMobileMode(symbols);
      return;
    }

    console.log('[WhaleTracker] Starting simulation mode');
    
    // Desktop: Every 30-60 seconds
    const interval = window.setInterval(() => {
      if (!this.isRunning) return;
      
      const symbol = symbols[Math.floor(Math.random() * symbols.length)];
      this.generateSimulatedWhaleActivity(symbol);
    }, 30000 + Math.random() * 30000);
    
    this.intervals.push(interval);
  }

  private generateSimulatedWhaleActivity(symbol: string) {
    const isAccumulation = Math.random() > 0.5;
    const baseAmount = Math.random() * 100 + 50;
    const valueUsd = baseAmount * (Math.random() * 50000 + 30000);
    
    const tx: WhaleTransaction = {
      id: `sim_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
      symbol: symbol.replace('USDT', '').replace('USD', ''),
      amount: baseAmount,
      valueUsd: valueUsd,
      type: isAccumulation ? 'outflow' : 'inflow',
      from: isAccumulation ? 'Unknown Wallet' : 'Exchange',
      to: isAccumulation ? 'Cold Wallet' : 'Exchange',
      timestamp: Date.now(),
      blockchain: symbol.includes('BTC') ? 'bitcoin' : 'ethereum',
      txHash: `0x${Math.random().toString(16).substr(2, 40)}`
    };
    
    this.transactions.push(tx);
    
    const maxTx = isMobile() ? 50 : 1000;
    if (this.transactions.length > maxTx) {
      this.transactions = this.transactions.slice(-maxTx);
    }
    
    this.throttledAnalysis(symbol);
  }

  private throttledAnalysis(symbol: string) {
    const now = Date.now();
    if (now - this.lastAnalysis < this.analysisThrottle) return;
    
    this.lastAnalysis = now;
    
    // Use setTimeout to prevent blocking
    setTimeout(() => this.analyzeWhaleActivity(symbol), 0);
  }

  private analyzeWhaleActivity(symbol: string) {
    // Mobile: Skip complex analysis
    if (isMobile()) {
      this.simpleMobileAnalysis(symbol);
      return;
    }

    const symbolClean = symbol.replace('USDT', '').replace('USD', '');
    const recentTxs = this.transactions
      .filter(tx => tx.symbol === symbolClean)
      .filter(tx => Date.now() - tx.timestamp < 3600000);
    
    if (recentTxs.length < 3) return;
    
    const inflows = recentTxs.filter(tx => tx.type === 'inflow');
    const outflows = recentTxs.filter(tx => tx.type === 'outflow');
    
    const inflowValue = inflows.reduce((sum, tx) => sum + tx.valueUsd, 0);
    const outflowValue = outflows.reduce((sum, tx) => sum + tx.valueUsd, 0);
    
    const netflow = outflowValue - inflowValue;
    const totalValue = inflowValue + outflowValue;
    
    let direction: 'accumulation' | 'distribution' | 'neutral' = 'neutral';
    let confidence = 0;
    
    if (netflow > totalValue * 0.2) {
      direction = 'accumulation';
      confidence = Math.min(100, (netflow / totalValue) * 100);
    } else if (netflow < -totalValue * 0.2) {
      direction = 'distribution';
      confidence = Math.min(100, (Math.abs(netflow) / totalValue) * 100);
    }
    
    if (confidence > 30) {
      const alert: WhaleAlert = {
        symbol,
        direction,
        confidence,
        transactions: recentTxs.slice(-10),
        totalValue,
        impact: totalValue > 10000000 ? 'high' : totalValue > 1000000 ? 'medium' : 'low',
        timestamp: Date.now()
      };
      
      this.notifySubscribers(alert);
    }
  }

  private simpleMobileAnalysis(symbol: string) {
    // Simplified: Just check last transaction
    const lastTx = this.transactions[this.transactions.length - 1];
    if (!lastTx) return;
    
    const direction: 'accumulation' | 'distribution' = 
      lastTx.type === 'outflow' ? 'accumulation' : 'distribution';
    
    const alert: WhaleAlert = {
      symbol,
      direction,
      confidence: 60,
      transactions: [lastTx],
      totalValue: lastTx.valueUsd,
      impact: lastTx.valueUsd > 5000000 ? 'high' : 'medium',
      timestamp: Date.now()
    };
    
    this.notifySubscribers(alert);
  }

  subscribe(callback: (alert: WhaleAlert) => void): () => void {
    this.subscribers.add(callback);
    return () => this.subscribers.delete(callback);
  }

  private notifySubscribers(alert: WhaleAlert) {
    // Use setTimeout to prevent blocking
    this.subscribers.forEach(cb => {
      setTimeout(() => {
        try {
          cb(alert);
        } catch (e) {
          console.error('Subscriber error:', e);
        }
      }, 0);
    });
  }

  getRecentTransactions(symbol: string, limit: number = 20): WhaleTransaction[] {
    const symbolClean = symbol.replace('USDT', '').replace('USD', '');
    
    // Mobile: Return fewer transactions
    const actualLimit = isMobile() ? 5 : limit;
    
    return this.transactions
      .filter(tx => tx.symbol === symbolClean)
      .sort((a, b) => b.timestamp - a.timestamp)
      .slice(0, actualLimit);
  }

  calculateSmartMoneyIndex(symbol: string): number {
    // Mobile: Return default value
    if (isMobile()) return 50;
    
    const symbolClean = symbol.replace('USDT', '').replace('USD', '');
    const recentTxs = this.transactions
      .filter(tx => tx.symbol === symbolClean)
      .filter(tx => Date.now() - tx.timestamp < 86400000);
    
    if (recentTxs.length === 0) return 50;
    
    const buyVolume = recentTxs
      .filter(tx => tx.type === 'outflow')
      .reduce((sum, tx) => sum + tx.valueUsd, 0);
    
    const sellVolume = recentTxs
      .filter(tx => tx.type === 'inflow')
      .reduce((sum, tx) => sum + tx.valueUsd, 0);
    
    const total = buyVolume + sellVolume;
    if (total === 0) return 50;
    
    return (buyVolume / total) * 100;
  }

  generateSignal(symbol: string): { signal: 'buy' | 'sell' | 'hold'; confidence: number; reason: string } {
    // Mobile: Simplified signal
    if (isMobile()) {
      const lastTx = this.transactions[this.transactions.length - 1];
      if (lastTx && lastTx.valueUsd > 3000000) {
        return {
          signal: lastTx.type === 'outflow' ? 'buy' : 'sell',
          confidence: 60,
          reason: `Large ${lastTx.type} detected: $${(lastTx.valueUsd / 1000000).toFixed(1)}M`
        };
      }
      return { signal: 'hold', confidence: 50, reason: 'No significant whale activity' };
    }

    const smi = this.calculateSmartMoneyIndex(symbol);
    const recentTxs = this.getRecentTransactions(symbol, 10);
    const largeBuys = recentTxs.filter(tx => tx.type === 'outflow' && tx.valueUsd > 5000000).length;
    const largeSells = recentTxs.filter(tx => tx.type === 'inflow' && tx.valueUsd > 5000000).length;
    
    if (smi > 70 && largeBuys > largeSells) {
      return {
        signal: 'buy',
        confidence: Math.min(100, smi),
        reason: `Strong accumulation detected. ${largeBuys} large outflows vs ${largeSells} inflows. Smart Money Index: ${smi.toFixed(1)}`
      };
    } else if (smi < 30 && largeSells > largeBuys) {
      return {
        signal: 'sell',
        confidence: Math.min(100, 100 - smi),
        reason: `Distribution pattern detected. ${largeSells} large inflows vs ${largeBuys} outflows. Smart Money Index: ${smi.toFixed(1)}`
      };
    }
    
    return {
      signal: 'hold',
      confidence: 50,
      reason: 'Mixed whale activity. No clear directional bias.'
    };
  }
}

export const whaleTracker = new WhaleTrackerService();
export default whaleTracker;
