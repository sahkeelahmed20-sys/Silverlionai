import type { CandleData } from '../types';

const isMobile = () => /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);

export class TechnicalAnalysisService {
  
  calculateRSI(prices: number[], period: number = 14): number {
    if (prices.length < period + 1) return 50;
    
    if (isMobile() && prices.length > 50) {
      prices = prices.slice(-30);
    }
    
    let gains = 0;
    let losses = 0;
    
    for (let i = 1; i <= period; i++) {
      const change = prices[prices.length - i] - prices[prices.length - i - 1];
      if (change > 0) gains += change;
      else losses += Math.abs(change);
    }
    
    let avgGain = gains / period;
    let avgLoss = losses / period;
    
    if (!isMobile()) {
      for (let i = period + 1; i < prices.length; i++) {
        const change = prices[i] - prices[i - 1];
        const gain = change > 0 ? change : 0;
        const loss = change < 0 ? Math.abs(change) : 0;
        
        avgGain = ((avgGain * (period - 1)) + gain) / period;
        avgLoss = ((avgLoss * (period - 1)) + loss) / period;
      }
    }
    
    if (avgLoss === 0) return 100;
    const rs = avgGain / avgLoss;
    return 100 - (100 / (1 + rs));
  }

  calculateMACD(prices: number[], fastPeriod: number = 12, slowPeriod: number = 26, signalPeriod: number = 9) {
    if (isMobile()) {
      const ema12 = this.calculateEMA(prices.slice(-30), fastPeriod);
      const ema26 = this.calculateEMA(prices.slice(-30), slowPeriod);
      const macdLine = ema12 - ema26;
      return { macd: macdLine, signal: macdLine * 0.9, histogram: macdLine * 0.1 };
    }

    const ema12 = this.calculateEMA(prices, fastPeriod);
    const ema26 = this.calculateEMA(prices, slowPeriod);
    const macdLine = ema12 - ema26;
    
    const macdHistory: number[] = [];
    
    for (let i = prices.length - 1; i >= slowPeriod && macdHistory.length < signalPeriod * 2; i--) {
      const slice = prices.slice(0, i + 1);
      const e12 = this.calculateEMA(slice, fastPeriod);
      const e26 = this.calculateEMA(slice, slowPeriod);
      macdHistory.unshift(e12 - e26);
    }
    
    const signalLine = this.calculateEMA(macdHistory, signalPeriod);
    const histogram = macdLine - signalLine;
    
    return { macd: macdLine, signal: signalLine, histogram };
  }

  calculateEMA(prices: number[], period: number): number {
    if (prices.length < period) return prices[prices.length - 1];
    
    const multiplier = 2 / (period + 1);
    let ema = prices.slice(0, period).reduce((a, b) => a + b) / period;
    
    for (let i = period; i < prices.length; i++) {
      ema = (prices[i] - ema) * multiplier + ema;
    }
    
    return ema;
  }

  calculateBollingerBands(prices: number[], period: number = 20, stdDev: number = 2) {
    if (isMobile()) {
      const price = prices[prices.length - 1];
      const volatility = this.calculateVolatility(prices.slice(-10));
      return { 
        upper: price * (1 + volatility), 
        middle: price, 
        lower: price * (1 - volatility) 
      };
    }

    if (prices.length < period) {
      const price = prices[prices.length - 1];
      return { upper: price * 1.02, middle: price, lower: price * 0.98 };
    }
    
    const slice = prices.slice(-period);
    const sma = slice.reduce((a, b) => a + b) / period;
    const variance = slice.reduce((sum, price) => sum + Math.pow(price - sma, 2), 0) / period;
    const std = Math.sqrt(variance);
    
    return {
      upper: sma + (stdDev * std),
      middle: sma,
      lower: sma - (stdDev * std)
    };
  }

  private calculateVolatility(prices: number[]): number {
    if (prices.length < 2) return 0.02;
    const returns: number[] = [];
    for (let i = 1; i < prices.length; i++) {
      returns.push((prices[i] - prices[i-1]) / prices[i-1]);
    }
    const mean = returns.reduce((a, b) => a + b) / returns.length;
    const variance = returns.reduce((sum, r) => sum + Math.pow(r - mean, 2), 0) / returns.length;
    return Math.sqrt(variance) * 2;
  }

  calculateATR(candles: CandleData[], period: number = 14): number {
    if (candles.length < 2) return 0;
    
    if (isMobile()) {
      const recent = candles.slice(-5);
      let total = 0;
      for (let i = 1; i < recent.length; i++) {
        total += recent[i].high - recent[i].low;
      }
      return total / (recent.length - 1) || candles[candles.length - 1].close * 0.02;
    }
    
    const trValues: number[] = [];
    
    for (let i = 1; i < candles.length; i++) {
      const high = candles[i].high;
      const low = candles[i].low;
      const prevClose = candles[i - 1].close;
      
      const tr1 = high - low;
      const tr2 = Math.abs(high - prevClose);
      const tr3 = Math.abs(low - prevClose);
      
      trValues.push(Math.max(tr1, tr2, tr3));
    }
    
    if (trValues.length < period) return trValues.reduce((a, b) => a + b) / trValues.length;
    
    return trValues.slice(-period).reduce((a, b) => a + b) / period;
  }

  calculateStochRSI(prices: number[], rsiPeriod: number = 14, stochPeriod: number = 14) {
    if (isMobile()) return { k: 50, d: 50 };
    
    const rsiValues: number[] = [];
    
    for (let i = rsiPeriod; i <= prices.length; i++) {
      rsiValues.push(this.calculateRSI(prices.slice(0, i), rsiPeriod));
    }
    
    if (rsiValues.length < stochPeriod) return { k: 50, d: 50 };
    
    const rsiSlice = rsiValues.slice(-stochPeriod);
    const minRSI = Math.min(...rsiSlice);
    const maxRSI = Math.max(...rsiSlice);
    
    const k = maxRSI - minRSI === 0 ? 50 : ((rsiValues[rsiValues.length - 1] - minRSI) / (maxRSI - minRSI)) * 100;
    
    return { k, d: k };
  }

  findSupportResistance(candles: CandleData[], lookback: number = 20): { support: number[], resistance: number[] } {
    if (isMobile()) {
      const recent = candles.slice(-10);
      const low = Math.min(...recent.map(c => c.low));
      const high = Math.max(...recent.map(c => c.high));
      return { 
        support: [low], 
        resistance: [high] 
      };
    }

    const highs = candles.slice(-lookback).map(c => c.high);
    const lows = candles.slice(-lookback).map(c => c.low);
    
    const resistance = this.findLevels(highs, 3);
    const support = this.findLevels(lows, 3);
    
    return { support, resistance };
  }

  private findLevels(prices: number[], touches: number): number[] {
    const levels: number[] = [];
    const tolerance = 0.002;
    
    const maxIterations = isMobile() ? 50 : prices.length;
    
    for (let i = 0; i < Math.min(prices.length, maxIterations); i++) {
      let touchCount = 0;
      for (let j = 0; j < prices.length; j++) {
        if (Math.abs(prices[i] - prices[j]) / prices[i] < tolerance) {
          touchCount++;
        }
      }
      if (touchCount >= touches && !levels.some(l => Math.abs(l - prices[i]) / l < tolerance)) {
        levels.push(prices[i]);
      }
    }
    
    return levels.sort((a, b) => a - b);
  }

  detectPatterns(candles: CandleData[]): string[] {
    if (isMobile()) {
      const patterns: string[] = [];
      if (candles.length < 3) return patterns;
      
      const current = candles[candles.length - 1];
      
      const bodySize = Math.abs(current.close - current.open);
      const lowerShadow = Math.min(current.open, current.close) - current.low;
      
      if (lowerShadow > bodySize * 2) {
        patterns.push('HAMMER');
      }
      
      return patterns;
    }

    const patterns: string[] = [];
    if (candles.length < 5) return patterns;
    
    const last5 = candles.slice(-5);
    const current = last5[last5.length - 1];
    const prev = last5[last5.length - 2];
    
    const bodySize = Math.abs(current.close - current.open);
    const lowerShadow = Math.min(current.open, current.close) - current.low;
    const upperShadow = current.high - Math.max(current.open, current.close);
    
    if (lowerShadow > bodySize * 2 && upperShadow < bodySize * 0.5) {
      patterns.push('HAMMER');
    }
    
    const prevBody = Math.abs(prev.close - prev.open);
    const currBody = Math.abs(current.close - current.open);
    
    if (currBody > prevBody * 1.5 && 
        ((prev.close < prev.open && current.close > current.open && current.open < prev.close && current.close > prev.open) ||
         (prev.close > prev.open && current.close < current.open && current.open > prev.close && current.close < prev.open))) {
      patterns.push(prev.close < prev.open ? 'BULLISH_ENGULFING' : 'BEARISH_ENGULFING');
    }
    
    if (bodySize < (current.high - current.low) * 0.1) {
      patterns.push('DOJI');
    }
    
    return patterns;
  }

  analyze(candles: CandleData[]) {
    if (isMobile()) {
      return this.analyzeMobile(candles);
    }

    if (candles.length < 50) {
      return {
        trend: 'NEUTRAL',
        strength: 0,
        indicators: {},
        patterns: [],
        signals: []
      };
    }
    
    const prices = candles.map(c => c.close);
    const currentPrice = prices[prices.length - 1];
    
    const rsi = this.calculateRSI(prices);
    const macd = this.calculateMACD(prices);
    const bb = this.calculateBollingerBands(prices);
    const atr = this.calculateATR(candles);
    const stochRSI = this.calculateStochRSI(prices);
    const { support, resistance } = this.findSupportResistance(candles);
    const patterns = this.detectPatterns(candles);
    
    const ema20 = this.calculateEMA(prices, 20);
    const ema50 = this.calculateEMA(prices, 50);
    const trend = currentPrice > ema20 && ema20 > ema50 ? 'BULLISH' : 
                  currentPrice < ema20 && ema20 < ema50 ? 'BEARISH' : 'NEUTRAL';
    
    const adx = this.calculateADX(candles);
    
    const signals: string[] = [];
    
    if (rsi < 30) signals.push('RSI_OVERSOLD');
    if (rsi > 70) signals.push('RSI_OVERBOUGHT');
    if (macd.histogram > 0 && macd.macd > macd.signal) signals.push('MACD_BULLISH');
    if (macd.histogram < 0 && macd.macd < macd.signal) signals.push('MACD_BEARISH');
    if (currentPrice < bb.lower) signals.push('PRICE_BELOW_BB');
    if (currentPrice > bb.upper) signals.push('PRICE_ABOVE_BB');
    if (patterns.includes('HAMMER')) signals.push('HAMMER_BULLISH');
    if (patterns.includes('BULLISH_ENGULFING')) signals.push('ENGULFING_BULLISH');
    
    return {
      trend,
      strength: adx,
      indicators: {
        rsi,
        macd,
        bollinger: bb,
        atr,
        stochRSI,
        ema20,
        ema50
      },
      levels: { support: support.slice(-3), resistance: resistance.slice(-3) },
      patterns,
      signals,
      currentPrice
    };
  }

  private analyzeMobile(candles: CandleData[]) {
    if (candles.length < 10) {
      return {
        trend: 'NEUTRAL',
        strength: 25,
        indicators: { rsi: 50 },
        patterns: [],
        signals: [],
        currentPrice: candles[candles.length - 1]?.close || 0
      };
    }

    const recent = candles.slice(-20);
    const prices = recent.map(c => c.close);
    const currentPrice = prices[prices.length - 1];
    
    const rsi = this.calculateRSI(prices, 10);
    const sma = prices.reduce((a, b) => a + b) / prices.length;
    const trend = currentPrice > sma ? 'BULLISH' : currentPrice < sma ? 'BEARISH' : 'NEUTRAL';
    
    const patterns = this.detectPatterns(recent);
    
    const signals: string[] = [];
    if (rsi < 30) signals.push('RSI_OVERSOLD');
    if (rsi > 70) signals.push('RSI_OVERBOUGHT');
    if (patterns.includes('HAMMER')) signals.push('HAMMER_BULLISH');

    return {
      trend,
      strength: 25,
      indicators: { rsi },
      patterns,
      signals,
      currentPrice
    };
  }

  private calculateADX(candles: CandleData[], period: number = 14): number {
    if (isMobile()) return 25;
    
    if (candles.length < period * 2) return 25;
    
    const trValues: number[] = [];
    const plusDM: number[] = [];
    const minusDM: number[] = [];
    
    for (let i = 1; i < candles.length; i++) {
      const high = candles[i].high;
      const low = candles[i].low;
      const prevHigh = candles[i - 1].high;
      const prevLow = candles[i - 1].low;
      const prevClose = candles[i - 1].close;
      
      const tr = Math.max(high - low, Math.abs(high - prevClose), Math.abs(low - prevClose));
      trValues.push(tr);
      
      const upMove = high - prevHigh;
      const downMove = prevLow - low;
      
      plusDM.push(upMove > downMove && upMove > 0 ? upMove : 0);
      minusDM.push(downMove > upMove && downMove > 0 ? downMove : 0);
    }
    
    const atr = this.smoothAverage(trValues, period);
    const smoothedPlusDM = this.smoothAverage(plusDM, period);
    const smoothedMinusDM = this.smoothAverage(minusDM, period);
    
    const plusDI = (smoothedPlusDM / atr) * 100;
    const minusDI = (smoothedMinusDM / atr) * 100;
    
    const dx = Math.abs(plusDI - minusDI) / (plusDI + minusDI) * 100;
    
    return dx;
  }

  private smoothAverage(values: number[], period: number): number {
    if (values.length < period) return values.reduce((a, b) => a + b) / values.length;
    return values.slice(-period).reduce((a, b) => a + b) / period;
  }

  cleanup() {
    // No cache to clean up in this version
  }
}

export const technicalAnalysis = new TechnicalAnalysisService();
export default technicalAnalysis;
