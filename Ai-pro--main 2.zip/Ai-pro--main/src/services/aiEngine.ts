import { technicalAnalysis } from './technicalAnalysis';
import { sentimentService, type AggregatedSentiment } from './sentimentService';
import { whaleTracker } from './whaleTracker';
import { mlPredictor } from './mlPredictor';
import type { CandleData, MarketRegime } from '../types';

export interface AIAnalysis {
  signal: 'BUY' | 'SELL' | 'HOLD';
  confidence: number;
  entry: number;
  stopLoss: number;
  takeProfit: number;
  riskReward: number;
  reasoning: string[];
  agentVotes: AgentVote[];
  marketRegime: MarketRegime;
  timestamp: number;
}

export interface AgentVote {
  name: string;
  vote: 'BUY' | 'SELL' | 'HOLD';
  confidence: number;
  weight: number;
  reasoning: string;
}

// Mobile detection - can be overridden for "mobile pro" mode
const isMobile = () => /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);

// MOBILE PRO MODE: Set to true to enable more features on mobile
const MOBILE_PRO_MODE = true;

// Helper to check if we should use full features
const useFullFeatures = () => !isMobile() || MOBILE_PRO_MODE;

// Type guard for MACD indicator
interface MACDIndicator {
  macd: number;
  signal: number;
  histogram: number;
}

function hasMACD(indicators: any): indicators is { macd: MACDIndicator } {
  return indicators && typeof indicators === 'object' && 'macd' in indicators && indicators.macd !== null && typeof indicators.macd === 'object';
}

// Type guard for RSI
function hasRSI(indicators: any): indicators is { rsi: number } {
  return indicators && typeof indicators === 'object' && 'rsi' in indicators && typeof indicators.rsi === 'number';
}

export class AIEngine {
  private candleData: Map<string, CandleData[]> = new Map();
  private lastAnalysis: Map<string, AIAnalysis> = new Map();
  private analysisQueue: Map<string, Promise<AIAnalysis>> = new Map();
  private initialized = false;

  async initialize() {
    if (this.initialized) return;
    
    try {
      if (useFullFeatures()) {
        await mlPredictor.initialize();
      }
      this.initialized = true;
      console.log('[AI Engine] Initialized');
    } catch (e) {
      console.warn('[AI Engine] Initialization warning:', e);
      this.initialized = true;
    }
  }

  updateCandles(symbol: string, candles: CandleData[]) {
    const maxCandles = isMobile() ? 200 : 500;
    if (candles.length > maxCandles) {
      candles = candles.slice(-maxCandles);
    }
    this.candleData.set(symbol, candles);
  }

  async analyze(symbol: string, currentPrice: number): Promise<AIAnalysis> {
    if (this.analysisQueue.has(symbol)) {
      return this.analysisQueue.get(symbol)!;
    }

    const analysisPromise = this.performAnalysis(symbol, currentPrice);
    this.analysisQueue.set(symbol, analysisPromise);

    try {
      const result = await analysisPromise;
      return result;
    } finally {
      this.analysisQueue.delete(symbol);
    }
  }

  private async performAnalysis(symbol: string, currentPrice: number): Promise<AIAnalysis> {
    const candles = this.candleData.get(symbol) || [];
    
    if (candles.length < 50) {
      return this.createNeutralAnalysis(currentPrice);
    }

    // Mobile Pro: Use enhanced analysis instead of simplified
    if (isMobile() && !MOBILE_PRO_MODE) {
      return this.performSimplifiedAnalysis(symbol, candles, currentPrice);
    }

    // Mobile Pro: Full analysis with all agents
    try {
      const [technical, sentiment, whaleSignal, mlPrediction] = await Promise.all([
        this.technicalAnalysis(candles),
        sentimentService.getAggregatedSentiment(symbol).catch(() => null),
        Promise.resolve(whaleTracker.generateSignal(symbol)).catch(() => ({ signal: 'hold' as const, confidence: 50, reason: 'No data' })),
        useFullFeatures() ? mlPredictor.predict(candles).catch(() => ({ trend: 'sideways', confidence: 50 })) : Promise.resolve({ trend: 'sideways', confidence: 50 })
      ]);

      const agents: AgentVote[] = [
        technical,
        sentiment ? this.sentimentToVote(sentiment) : null,
        this.whaleToVote(whaleSignal),
        this.mlToVote(mlPrediction)
      ].filter((a): a is AgentVote => a !== null);

      return this.compileAnalysis(symbol, agents, currentPrice, candles);
    } catch (error) {
      console.error('[AI Engine] Analysis error:', error);
      return this.createNeutralAnalysis(currentPrice);
    }
  }

  // Simplified analysis for basic mobile mode
  private performSimplifiedAnalysis(symbol: string, candles: CandleData[], currentPrice: number): AIAnalysis {
    const analysis = technicalAnalysis.analyze(candles);
    const regime = this.detectMarketRegime(candles);
    
    let signal: 'BUY' | 'SELL' | 'HOLD' = 'HOLD';
    let confidence = 50;
    const reasons: string[] = [];

    // Safe access to RSI
    const rsi = hasRSI(analysis.indicators) ? analysis.indicators.rsi : undefined;
    
    if (rsi !== undefined) {
      if (rsi < 30) {
        signal = 'BUY';
        confidence = 70;
        reasons.push(`RSI oversold (${rsi.toFixed(1)})`);
      } else if (rsi > 70) {
        signal = 'SELL';
        confidence = 70;
        reasons.push(`RSI overbought (${rsi.toFixed(1)})`);
      }
    }

    if (analysis.trend === 'BULLISH' && signal !== 'SELL') {
      signal = signal === 'HOLD' ? 'BUY' : signal;
      confidence += 10;
      reasons.push('Uptrend detected');
    } else if (analysis.trend === 'BEARISH' && signal !== 'BUY') {
      signal = signal === 'HOLD' ? 'SELL' : signal;
      confidence += 10;
      reasons.push('Downtrend detected');
    }

    const { stopLoss, takeProfit } = this.calculatePriceLevels(currentPrice, signal, candles, regime);

    const result: AIAnalysis = {
      signal,
      confidence: Math.min(100, confidence),
      entry: currentPrice,
      stopLoss,
      takeProfit,
      riskReward: signal === 'HOLD' ? 1 : Math.abs(takeProfit - currentPrice) / Math.abs(currentPrice - stopLoss),
      reasoning: reasons.length > 0 ? reasons : ['No clear signals'],
      agentVotes: [{
        name: 'Technical Analyst',
        vote: signal,
        confidence,
        weight: 1,
        reasoning: reasons.join('; ') || 'Analysis complete'
      }],
      marketRegime: regime,
      timestamp: Date.now()
    };

    this.lastAnalysis.set(symbol, result);
    return result;
  }

  private compileAnalysis(symbol: string, agents: AgentVote[], currentPrice: number, candles: CandleData[]): AIAnalysis {
    const ensemble = this.calculateEnsemble(agents);
    const regime = this.detectMarketRegime(candles);
    const { stopLoss, takeProfit } = this.calculatePriceLevels(currentPrice, ensemble.signal, candles, regime);

    const analysis: AIAnalysis = {
      signal: ensemble.signal,
      confidence: ensemble.confidence,
      entry: currentPrice,
      stopLoss,
      takeProfit,
      riskReward: ensemble.signal === 'HOLD' ? 1 : Math.abs(takeProfit - currentPrice) / Math.abs(currentPrice - stopLoss),
      reasoning: ensemble.reasoning,
      agentVotes: agents,
      marketRegime: regime,
      timestamp: Date.now()
    };

    this.lastAnalysis.set(symbol, analysis);
    return analysis;
  }

  private async technicalAnalysis(candles: CandleData[]): Promise<AgentVote> {
    if (isMobile()) {
      await new Promise(resolve => setTimeout(resolve, 0));
    }

    const analysis = technicalAnalysis.analyze(candles);
    
    let vote: 'BUY' | 'SELL' | 'HOLD' = 'HOLD';
    let confidence = 50;
    const reasons: string[] = [];

    // Safe access with type guards
    const rsi = hasRSI(analysis.indicators) ? analysis.indicators.rsi : undefined;
    const macdData = hasMACD(analysis.indicators) ? analysis.indicators.macd : undefined;
    
    if (rsi !== undefined) {
      if (rsi < 30) {
        vote = 'BUY';
        confidence += 20;
        reasons.push(`RSI oversold (${rsi.toFixed(1)})`);
      } else if (rsi > 70) {
        vote = 'SELL';
        confidence += 20;
        reasons.push(`RSI overbought (${rsi.toFixed(1)})`);
      }
    }

    // Safe MACD access
    if (macdData && 
        typeof macdData.histogram === 'number' && 
        typeof macdData.macd === 'number' && 
        typeof macdData.signal === 'number') {
      if (macdData.histogram > 0 && macdData.macd > macdData.signal) {
        if (vote === 'BUY') confidence += 15;
        else if (vote === 'HOLD') { vote = 'BUY'; confidence += 10; }
        reasons.push('MACD bullish crossover');
      } else if (macdData.histogram < 0 && macdData.macd < macdData.signal) {
        if (vote === 'SELL') confidence += 15;
        else if (vote === 'HOLD') { vote = 'SELL'; confidence += 10; }
        reasons.push('MACD bearish crossover');
      }
    }

    if (analysis.trend === 'BULLISH') {
      if (vote !== 'SELL') { vote = 'BUY'; confidence += 10; }
      reasons.push('Uptrend detected (EMA20 > EMA50)');
    } else if (analysis.trend === 'BEARISH') {
      if (vote !== 'BUY') { vote = 'SELL'; confidence += 10; }
      reasons.push('Downtrend detected (EMA20 < EMA50)');
    }

    const bullishPatterns = ['HAMMER', 'BULLISH_ENGULFING'];
    const patterns = analysis.patterns || [];
    const hasBullishPattern = patterns.some((p: string) => bullishPatterns.includes(p));
    if (hasBullishPattern) {
      if (vote !== 'SELL') { vote = 'BUY'; confidence += 15; }
      reasons.push(`Bullish pattern: ${patterns.join(', ')}`);
    }

    return {
      name: 'Technical Analyst',
      vote,
      confidence: Math.min(100, confidence),
      weight: 0.30,
      reasoning: reasons.join('; ') || 'No clear signals'
    };
  }

  private sentimentToVote(sentiment: AggregatedSentiment): AgentVote {
    let vote: 'BUY' | 'SELL' | 'HOLD' = 'HOLD';
    let confidence = 50;

    if (sentiment.overall > 0.3) {
      vote = 'BUY';
      confidence = 50 + (sentiment.overall * 50);
    } else if (sentiment.overall < -0.3) {
      vote = 'SELL';
      confidence = 50 + (Math.abs(sentiment.overall) * 50);
    }

    return {
      name: 'Sentiment Analyzer',
      vote,
      confidence: Math.min(100, confidence),
      weight: 0.20,
      reasoning: `Market sentiment: ${(sentiment.overall * 100).toFixed(1)}% (${sentiment.trend})`
    };
  }

  private whaleToVote(whaleSignal: { signal: string; confidence: number; reason: string }): AgentVote {
    const voteMap: { [key: string]: 'BUY' | 'SELL' | 'HOLD' } = {
      'buy': 'BUY',
      'sell': 'SELL',
      'hold': 'HOLD'
    };

    return {
      name: 'Whale Tracker',
      vote: voteMap[whaleSignal.signal] || 'HOLD',
      confidence: whaleSignal.confidence,
      weight: 0.25,
      reasoning: whaleSignal.reason
    };
  }

  private mlToVote(prediction: { trend: string; confidence: number }): AgentVote {
    const voteMap: { [key: string]: 'BUY' | 'SELL' | 'HOLD' } = {
      'up': 'BUY',
      'down': 'SELL',
      'sideways': 'HOLD'
    };

    return {
      name: 'ML Predictor',
      vote: voteMap[prediction.trend] || 'HOLD',
      confidence: prediction.confidence,
      weight: 0.25,
      reasoning: `LSTM model predicts ${prediction.trend} trend (${prediction.confidence.toFixed(1)}% confidence)`
    };
  }

  private calculateEnsemble(agents: AgentVote[]): { 
    signal: 'BUY' | 'SELL' | 'HOLD'; 
    confidence: number; 
    reasoning: string[] 
  } {
    let buyScore = 0;
    let sellScore = 0;
    let holdScore = 0;
    const reasoning: string[] = [];

    agents.forEach(agent => {
      const weightedConfidence = agent.confidence * agent.weight;
      if (agent.vote === 'BUY') buyScore += weightedConfidence;
      else if (agent.vote === 'SELL') sellScore += weightedConfidence;
      else holdScore += weightedConfidence;
      reasoning.push(`${agent.name}: ${agent.vote} (${agent.confidence.toFixed(0)}%)`);
    });

    const total = buyScore + sellScore + holdScore || 1;
    const buyPct = (buyScore / total) * 100;
    const sellPct = (sellScore / total) * 100;
    const holdPct = (holdScore / total) * 100;

    let signal: 'BUY' | 'SELL' | 'HOLD' = 'HOLD';
    let confidence = holdPct;

    if (buyPct > sellPct && buyPct > holdPct) {
      signal = 'BUY';
      confidence = buyPct;
    } else if (sellPct > buyPct && sellPct > holdPct) {
      signal = 'SELL';
      confidence = sellPct;
    }

    return { signal, confidence, reasoning };
  }

  private detectMarketRegime(candles: CandleData[]): MarketRegime {
    if (candles.length < 20) return 'RANGE';

    const analysis = technicalAnalysis.analyze(candles);
    const adx = analysis.strength;
    const currentPrice = candles[candles.length - 1].close;
    
    const priceRange = Math.max(...candles.slice(-20).map(c => c.high)) - 
                       Math.min(...candles.slice(-20).map(c => c.low));
    const volatility = (priceRange / currentPrice) * 100;

    if (adx > 40 && volatility > 5) return 'TREND';
    if (adx < 20 && volatility < 3) return 'CHOP';
    if (volatility > 8) return 'BREAKOUT';
    
    const rsi = hasRSI(analysis.indicators) ? analysis.indicators.rsi : undefined;
    if (rsi !== undefined && (rsi < 20 || rsi > 80)) return 'PANIC';
    
    return 'RANGE';
  }

  private calculatePriceLevels(
    currentPrice: number, 
    signal: 'BUY' | 'SELL' | 'HOLD',
    candles: CandleData[],
    regime: MarketRegime
  ): { stopLoss: number; takeProfit: number } {
    const atr = technicalAnalysis.calculateATR(candles, 14);
    const multiplier = regime === 'TREND' ? 2 : regime === 'BREAKOUT' ? 3 : 1.5;
    const stopDistance = atr * multiplier;
    const rewardRatio = regime === 'TREND' ? 3 : 2;

    if (signal === 'BUY') {
      return {
        stopLoss: currentPrice - stopDistance,
        takeProfit: currentPrice + (stopDistance * rewardRatio)
      };
    } else if (signal === 'SELL') {
      return {
        stopLoss: currentPrice + stopDistance,
        takeProfit: currentPrice - (stopDistance * rewardRatio)
      };
    }

    return { stopLoss: currentPrice * 0.95, takeProfit: currentPrice * 1.05 };
  }

  private createNeutralAnalysis(currentPrice: number): AIAnalysis {
    return {
      signal: 'HOLD',
      confidence: 0,
      entry: currentPrice,
      stopLoss: currentPrice * 0.95,
      takeProfit: currentPrice * 1.05,
      riskReward: 1,
      reasoning: ['Insufficient data for analysis'],
      agentVotes: [],
      marketRegime: 'RANGE',
      timestamp: Date.now()
    };
  }

  getLastAnalysis(symbol: string): AIAnalysis | undefined {
    return this.lastAnalysis.get(symbol);
  }

  async autoTrain(symbol: string) {
    if (!useFullFeatures()) return;
    
    const candles = this.candleData.get(symbol);
    if (candles && candles.length > 200) {
      try {
        await mlPredictor.train(candles);
      } catch (e) {
        console.warn('[AI Engine] Auto-train failed:', e);
      }
    }
  }

  cleanup() {
    this.candleData.clear();
    this.lastAnalysis.clear();
    this.analysisQueue.clear();
  }
}

export const aiEngine = new AIEngine();
export default aiEngine;
