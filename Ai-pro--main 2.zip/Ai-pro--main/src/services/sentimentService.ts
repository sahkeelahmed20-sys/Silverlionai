import axios from 'axios';

export interface SentimentScore {
  source: string;
  score: number;
  volume: number;
  timestamp: number;
  keywords: string[];
}

export interface AggregatedSentiment {
  overall: number;
  bullish: number;
  bearish: number;
  neutral: number;
  volume: number;
  trend: 'IMPROVING' | 'DECLINING' | 'STABLE';
  sources: SentimentScore[];
}

const isMobile = () => /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);

const apiClient = axios.create({
  timeout: isMobile() ? 3000 : 10000,
  headers: {
    'Accept': 'application/json',
  }
});

export class SentimentService {
  private cache: Map<string, { data: AggregatedSentiment; timestamp: number }> = new Map();
  private cacheDuration = isMobile() ? 10 * 60 * 1000 : 5 * 60 * 1000;
  private maxCacheSize = isMobile() ? 10 : 50;
  private pendingRequests = new Map<string, Promise<AggregatedSentiment>>();

  async getFearAndGreedIndex(): Promise<number> {
    if (isMobile()) {
      return 0.5;
    }

    try {
      const response = await apiClient.get('https://api.alternative.me/fng/');
      return parseInt(response.data.data[0].value) / 100;
    } catch (error) {
      console.error('Failed to fetch Fear & Greed:', error);
      return 0.5;
    }
  }

  analyzeText(text: string): number {
    if (isMobile()) {
      const lowerText = text.toLowerCase();
      const bullish = ['bullish', 'buy', 'pump', 'moon', 'breakout'].some(k => lowerText.includes(k));
      const bearish = ['bearish', 'sell', 'dump', 'crash', 'bear'].some(k => lowerText.includes(k));
      
      if (bullish && !bearish) return 0.5;
      if (bearish && !bullish) return -0.5;
      return 0;
    }

    const bullishKeywords = [
      'bullish', 'moon', 'pump', 'breakout', ' ATH', 'all time high', 'accumulate',
      'buy', 'long', 'support', 'bounce', 'recovery', 'surge', 'rally', 'green',
      'hodl', 'hold', 'strong', 'growth', 'adoption', 'partnership', 'listing'
    ];
    
    const bearishKeywords = [
      'bearish', 'dump', 'crash', 'bear', 'short', 'sell', 'resistance', 'rejection',
      'death cross', 'red', 'liquidation', 'fud', 'scam', 'rug', 'correction',
      'pullback', 'decline', 'drop', 'falling', 'weak', 'panic'
    ];
    
    const lowerText = text.toLowerCase();
    let bullishCount = 0;
    let bearishCount = 0;
    
    for (const keyword of bullishKeywords) {
      if (lowerText.includes(keyword.toLowerCase())) bullishCount++;
    }
    
    for (const keyword of bearishKeywords) {
      if (lowerText.includes(keyword.toLowerCase())) bearishCount++;
    }
    
    const total = bullishCount + bearishCount;
    if (total === 0) return 0;
    
    return (bullishCount - bearishCount) / total;
  }

  async getSocialSentiment(symbol: string): Promise<SentimentScore[]> {
    if (isMobile()) {
      return [
        {
          source: 'Social',
          score: (Math.random() - 0.5) * 0.4,
          volume: Math.floor(Math.random() * 5000) + 1000,
          timestamp: Date.now(),
          keywords: [symbol.toLowerCase(), 'trading']
        }
      ];
    }

    const sources = [
      { name: 'Twitter', weight: 0.3 },
      { name: 'Reddit', weight: 0.25 },
      { name: 'Telegram', weight: 0.2 },
      { name: 'News', weight: 0.25 }
    ];
    
    return sources.map(source => {
      const baseSentiment = (Math.random() - 0.5) * 0.4;
      const volume = Math.floor(Math.random() * 10000) + 1000;
      
      return {
        source: source.name,
        score: baseSentiment,
        volume,
        timestamp: Date.now(),
        keywords: this.extractKeywords(symbol)
      };
    });
  }

  async getNewsSentiment(symbol: string): Promise<SentimentScore> {
    if (isMobile()) {
      return {
        source: 'News',
        score: (Math.random() - 0.5) * 0.3,
        volume: Math.floor(Math.random() * 2000) + 500,
        timestamp: Date.now(),
        keywords: [symbol.toLowerCase(), 'market']
      };
    }

    try {
      const headlines = [
        `${symbol} breaks key resistance level`,
        `Whales accumulate ${symbol} amid market uncertainty`,
        `Technical analysis suggests ${symbol} bullish momentum`,
        `Market volatility affects ${symbol} price action`
      ];
      
      const randomHeadline = headlines[Math.floor(Math.random() * headlines.length)];
      const score = this.analyzeText(randomHeadline);
      
      return {
        source: 'CryptoNews',
        score,
        volume: Math.floor(Math.random() * 5000) + 500,
        timestamp: Date.now(),
        keywords: ['breakout', 'accumulation', 'technical', 'whales']
      };
    } catch (error) {
      return {
        source: 'CryptoNews',
        score: 0,
        volume: 0,
        timestamp: Date.now(),
        keywords: []
      };
    }
  }

  async getAggregatedSentiment(symbol: string): Promise<AggregatedSentiment> {
    const cacheKey = `sentiment_${symbol}`;
    
    if (this.pendingRequests.has(cacheKey)) {
      return this.pendingRequests.get(cacheKey)!;
    }

    const cached = this.cache.get(cacheKey);
    if (cached && Date.now() - cached.timestamp < this.cacheDuration) {
      return cached.data;
    }

    const requestPromise = this.fetchAggregatedSentiment(symbol);
    this.pendingRequests.set(cacheKey, requestPromise);

    try {
      const result = await requestPromise;
      return result;
    } finally {
      this.pendingRequests.delete(cacheKey);
    }
  }

  private async fetchAggregatedSentiment(symbol: string): Promise<AggregatedSentiment> {
    if (isMobile()) {
      const mockSentiment: AggregatedSentiment = {
        overall: (Math.random() - 0.5) * 0.4,
        bullish: Math.floor(Math.random() * 10) + 5,
        bearish: Math.floor(Math.random() * 10) + 5,
        neutral: Math.floor(Math.random() * 5) + 2,
        volume: Math.floor(Math.random() * 10000) + 5000,
        trend: 'STABLE',
        sources: [
          {
            source: 'Aggregated',
            score: (Math.random() - 0.5) * 0.4,
            volume: Math.floor(Math.random() * 5000) + 1000,
            timestamp: Date.now(),
            keywords: [symbol.toLowerCase()]
          }
        ]
      };
      
      this.manageCache(`sentiment_${symbol}`, mockSentiment);
      return mockSentiment;
    }

    try {
      const [socialSentiment, newsSentiment, fearGreed] = await Promise.all([
        this.getSocialSentiment(symbol),
        this.getNewsSentiment(symbol),
        this.getFearAndGreedIndex()
      ]);
      
      const allSources = [...socialSentiment, newsSentiment];
      
      let totalWeight = 0;
      let weightedSum = 0;
      
      for (const source of allSources) {
        const weight = source.volume;
        weightedSum += source.score * weight;
        totalWeight += weight;
      }
      
      const fearGreedScore = (fearGreed - 0.5) * 2;
      weightedSum += fearGreedScore * totalWeight * 0.5;
      totalWeight += totalWeight * 0.5;
      
      const overall = totalWeight > 0 ? weightedSum / totalWeight : 0;
      
      const bullish = allSources.filter(s => s.score > 0.2).length;
      const bearish = allSources.filter(s => s.score < -0.2).length;
      const neutral = allSources.length - bullish - bearish;
      
      const recentScores = allSources.map(s => s.score);
      const avgRecent = recentScores.slice(-3).reduce((a, b) => a + b, 0) / 3;
      const avgOlder = recentScores.slice(0, -3).reduce((a, b) => a + b, 0) / Math.max(1, recentScores.length - 3);
      
      const trend = avgRecent > avgOlder + 0.1 ? 'IMPROVING' : 
                    avgRecent < avgOlder - 0.1 ? 'DECLINING' : 'STABLE';
      
      const result: AggregatedSentiment = {
        overall,
        bullish,
        bearish,
        neutral,
        volume: allSources.reduce((sum, s) => sum + s.volume, 0),
        trend,
        sources: allSources
      };
      
      this.manageCache(`sentiment_${symbol}`, result);
      return result;
      
    } catch (error) {
      console.error('Sentiment analysis error:', error);
      return {
        overall: 0,
        bullish: 0,
        bearish: 0,
        neutral: 0,
        volume: 0,
        trend: 'STABLE',
        sources: []
      };
    }
  }

  private manageCache(key: string, data: AggregatedSentiment): void {
    if (this.cache.size >= this.maxCacheSize) {
      const oldestKey = this.cache.keys().next().value;
      if (oldestKey) this.cache.delete(oldestKey);
    }
    
    this.cache.set(key, { data, timestamp: Date.now() });
  }

  private extractKeywords(symbol: string): string[] {
    if (isMobile()) {
      return [symbol.toLowerCase(), 'market', 'price'];
    }

    const keywords = [
      'trading', 'price', 'analysis', 'market', 'crypto',
      symbol.toLowerCase(), 'blockchain', 'investment'
    ];
    return keywords.slice(0, Math.floor(Math.random() * 3) + 3);
  }

  async getMarketSentiment(coins: string[]): Promise<Map<string, AggregatedSentiment>> {
    const results = new Map<string, AggregatedSentiment>();
    
    if (isMobile()) {
      for (const coin of coins) {
        try {
          const sentiment = await this.getAggregatedSentiment(coin);
          results.set(coin, sentiment);
          await new Promise(r => setTimeout(r, 100));
        } catch (e) {
          console.warn(`Failed to get sentiment for ${coin}:`, e);
        }
      }
      return results;
    }

    await Promise.all(
      coins.map(async (coin) => {
        try {
          const sentiment = await this.getAggregatedSentiment(coin);
          results.set(coin, sentiment);
        } catch (e) {
          console.warn(`Failed to get sentiment for ${coin}:`, e);
        }
      })
    );
    
    return results;
  }

  cleanup(): void {
    this.cache.clear();
    this.pendingRequests.clear();
  }
}

export const sentimentService = new SentimentService();
export default sentimentService;
