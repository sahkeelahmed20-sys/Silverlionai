declare module 'zustand' {
  export function create<T>(fn: (set: any, get: any) => T): () => T;
}

declare module 'zustand/middleware' {
  export function persist<T>(config: T, options: any): T;
}