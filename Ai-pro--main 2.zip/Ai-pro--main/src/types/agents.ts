export interface AgentSystemStatus {
  active: boolean;
  agents: Array<{
    id: string;
    role: string;
    name: string;
    status: string;
    performance: number;
    autonomy: number;
  }>;
  messageQueue: number;
}

export interface AgentApprovalRequest {
  agentId: string;
  action: string;
  params: any;
  confidence: number;
  reasoning: string;
}
