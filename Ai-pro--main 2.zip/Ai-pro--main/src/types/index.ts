export type MarketRegime = 'TREND' | 'CHOP' | 'RANGE' | 'BREAKOUT' | 'PANIC';
export type KillSwitchLevel = 'OFF' | 'SOFT' | 'HARD' | 'LOCKED';
export type PositionSide = 'LONG' | 'SHORT';
export type TradeSide = 'BUY' | 'SELL';
export type Timeframe = '1m' | '5m' | '15m' | '1h' | '4h' | '1d' | '1w';

// AUTHENTICATION TYPES
export interface User {
  id: string;
  email: string;
  username: string;
  avatar?: string;
  createdAt: string;
  lastLogin?: string;
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  token: string | null;
}

export interface LoginCredentials {
  email: string;
  password: string;
  rememberMe?: boolean;
}

export interface RegisterCredentials {
  username: string;
  email: string;
  password: string;
  confirmPassword: string;
}

export interface AuthResponse {
  user: User;
  token: string;
  message?: string;
}

export interface TradingState {
  aiEnabled: boolean;
  marketRegime: MarketRegime;
  killSwitchLevel: KillSwitchLevel;
  killReason: string | null;
  confidence: number;
  ensembleScore: number;
  selectedCoin: string;
  selectedTimeframe: string;
  demoBalance: number;
  maxDailyLoss: number;
  maxPositionSize: number;
  autoPositionSizing: boolean;
  trailingStopEnabled: boolean;
  trailingStopPercent: number;
}

export interface PersistedTradingState {
  tradingState: TradingState;
  positions: Position[];
  tradeHistory: Trade[];
  portfolioValue: number;
  lastUpdated: string;
  settings: {
    initialCapital: number;
    currentBalance: number;
    totalPnL: number;
  };
  userId?: string; // ADD THIS for user-specific data
}

export interface LivePriceData {
  symbol: string;
  price: number;
  timestamp: number;
  change24h: number;
  volume: number;
  high24h: number;
  low24h: number;
}

export interface Position {
  id: number;
  symbol: string;
  side: 'LONG' | 'SHORT';
  size: number;
  entryPrice: number;
  currentPrice: number;
  pnl: number;
  pnlPercent: number;
  stopLoss?: number;
  takeProfit?: number;
  leverage?: number;
  margin?: number;
  timestamp: string;
}

export interface Trade {
  id: number;
  symbol: string;
  side: 'BUY' | 'SELL';
  type: 'OPEN' | 'CLOSE';
  price: number;
  size: number;
  pnl?: number;
  pnlPercent?: number;
  leverage?: number;
  timestamp: string;
}


export interface Signal {
  type: 'BUY' | 'SELL' | 'HOLD' | 'LONG' | 'SHORT';
  confidence: number;
  entry: number;
  stopLoss: number;
  takeProfit: number;
  riskReward: number;
  timestamp?: string;
}

export type AISignal = Signal;

export interface Agent {
  id: string;
  name: string;
  vote: 'BUY' | 'SELL' | 'HOLD';
  confidence: number;
  weight: number;
  description: string;
  lastUpdated?: string;
}

export interface PriceData {
  symbol: string;
  price: number;
  change24h: number;
  volume: number;
  high24h: number;
  low24h: number;
  timestamp: number;
}

export interface OrderBookData {
  bids: [string, string][];
  asks: [string, string][];
  lastUpdateId: number;
}

export interface CandleData {
  time: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  timestamp?: number;
}
