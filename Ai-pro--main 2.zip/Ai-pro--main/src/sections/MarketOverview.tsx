import { useState, useEffect, useRef } from 'react';
import { 
  TrendingUp, 
  TrendingDown, 
  Activity, 
  BarChart3,
  Clock,
  ArrowUpRight,
  ArrowDownRight,
  RefreshCw
} from 'lucide-react';
import { cn } from '../lib/utils';
import { createChart, type IChartApi, type ISeriesApi, type CandlestickData, type Time } from 'lightweight-charts';

interface MarketOverviewProps {
  tradingState: {
    aiEnabled: boolean;
    marketRegime: string;
    confidence: number;
  };
  onSymbolChange: (symbol: string) => void;
  selectedSymbol: string;
}

interface MarketStat {
  label: string;
  value: string;
  change: number;
  icon: React.ElementType;
}

interface TickerData {
  symbol: string;
  price: number;
  change24h: number;
  volume: number;
  high24h: number;
  low24h: number;
}

interface CandleData {
  time: Time;
  open: number;
  high: number;
  low: number;
  close: number;
}

export function MarketOverview({ 
  tradingState, 
  onSymbolChange,
  selectedSymbol 
}: MarketOverviewProps) {
  const [data, setData] = useState<TickerData>({
    symbol: selectedSymbol,
    price: 0,
    change24h: 0,
    volume: 0,
    high24h: 0,
    low24h: 0,
  });
  const [lastUpdate, setLastUpdate] = useState<Date>(new Date());
  const [isLoading, setIsLoading] = useState(true);
  const [candles, setCandles] = useState<CandleData[]>([]);
  
  const chartContainerRef = useRef<HTMLDivElement>(null);
  const chartRef = useRef<IChartApi | null>(null);
  const seriesRef = useRef<ISeriesApi<"Candlestick"> | null>(null);
  const isChartReadyRef = useRef(false);

  // Fetch ticker data
  const fetchTickerData = async () => {
    try {
      const response = await fetch(
        `https://api.binance.com/api/v3/ticker/24hr?symbol=${selectedSymbol}`
      );
      
      if (!response.ok) throw new Error('Failed to fetch ticker data');
      
      const ticker = await response.json();
      
      setData({
        symbol: selectedSymbol,
        price: parseFloat(ticker.lastPrice),
        change24h: parseFloat(ticker.priceChangePercent),
        volume: parseFloat(ticker.volume),
        high24h: parseFloat(ticker.highPrice),
        low24h: parseFloat(ticker.lowPrice),
      });
      setLastUpdate(new Date());
      setIsLoading(false);
    } catch (error) {
      console.error('[MarketOverview] Error fetching ticker:', error);
      setIsLoading(false);
    }
  };

  // Fetch candlestick data for chart
  const fetchCandleData = async () => {
    try {
      const response = await fetch(
        `https://api.binance.com/api/v3/klines?symbol=${selectedSymbol}&interval=1h&limit=100`
      );
      
      if (!response.ok) throw new Error('Failed to fetch candle data');
      
      const klines = await response.json();
      
      const formattedCandles: CandleData[] = klines.map((k: any[]) => ({
        time: k[0] / 1000 as Time,
        open: parseFloat(k[1]),
        high: parseFloat(k[2]),
        low: parseFloat(k[3]),
        close: parseFloat(k[4]),
      }));
      
      setCandles(formattedCandles);
    } catch (error) {
      console.error('[MarketOverview] Error fetching candles:', error);
    }
  };

  // Initialize chart
  useEffect(() => {
    if (!chartContainerRef.current) return;

    // Cleanup existing chart
    if (chartRef.current) {
      try {
        chartRef.current.remove();
      } catch (e) {
        console.warn('Chart already disposed');
      }
      chartRef.current = null;
      seriesRef.current = null;
      isChartReadyRef.current = false;
    }

    // Create chart
    const chart = createChart(chartContainerRef.current, {
      layout: {
        background: { color: 'transparent' },
        textColor: '#888888',
      },
      grid: {
        vertLines: { color: '#2a2a2a' },
        horzLines: { color: '#2a2a2a' },
      },
      crosshair: {
        mode: 1,
      },
      rightPriceScale: {
        borderColor: '#2a2a2a',
      },
      timeScale: {
        borderColor: '#2a2a2a',
        timeVisible: true,
      },
      width: chartContainerRef.current.clientWidth,
      height: 350,
    });

    // Create candlestick series - v5 API
    let candleSeries: ISeriesApi<"Candlestick">;
    try {
      candleSeries = chart.addCandlestickSeries({
        upColor: '#d0ff59',
        downColor: '#ef4444',
        borderUpColor: '#d0ff59',
        borderDownColor: '#ef4444',
        wickUpColor: '#d0ff59',
        wickDownColor: '#ef4444',
      });
    } catch (e) {
      console.error('Error creating candlestick series:', e);
      chart.remove();
      return;
    }

    chartRef.current = chart;
    seriesRef.current = candleSeries;
    isChartReadyRef.current = true;

    // Handle resize
    const handleResize = () => {
      if (chartContainerRef.current && chartRef.current && isChartReadyRef.current) {
        try {
          chartRef.current.applyOptions({
            width: chartContainerRef.current.clientWidth,
          });
        } catch (e) {
          console.warn('Resize error (chart disposed):', e);
        }
      }
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      isChartReadyRef.current = false;
      if (chartRef.current) {
        try {
          chartRef.current.remove();
        } catch (e) {
          console.warn('Chart already disposed during cleanup');
        }
        chartRef.current = null;
        seriesRef.current = null;
      }
    };
  }, [selectedSymbol]);

  // Update chart data when candles change
  useEffect(() => {
    if (seriesRef.current && candles.length > 0 && isChartReadyRef.current) {
      try {
        const candleData: CandlestickData[] = candles.map(c => ({
          time: c.time,
          open: c.open,
          high: c.high,
          low: c.low,
          close: c.close,
        }));
        
        seriesRef.current.setData(candleData);
        chartRef.current?.timeScale().fitContent();
      } catch (error) {
        console.warn('Error updating chart data (chart may be disposed):', error);
      }
    }
  }, [candles]);

  // Fetch data when symbol changes
  useEffect(() => {
    setIsLoading(true);
    fetchTickerData();
    fetchCandleData();
    
    const interval = setInterval(() => {
      fetchTickerData();
      fetchCandleData();
    }, 5000);
    
    return () => clearInterval(interval);
  }, [selectedSymbol]);

  const stats: MarketStat[] = [
    {
      label: '24h Change',
      value: `${data.change24h >= 0 ? '+' : ''}${data.change24h.toFixed(2)}%`,
      change: data.change24h,
      icon: data.change24h >= 0 ? TrendingUp : TrendingDown,
    },
    {
      label: '24h Volume',
      value: data.volume > 0 && data.price > 0 ? `$${((data.volume * data.price) / 1e9).toFixed(2)}B` : '$0.00B',
      change: 0,
      icon: BarChart3,
    },
    {
      label: '24h High',
      value: data.high24h > 0 ? `$${data.high24h.toLocaleString()}` : '$0',
      change: 0,
      icon: ArrowUpRight,
    },
    {
      label: '24h Low',
      value: data.low24h > 0 ? `$${data.low24h.toLocaleString()}` : '$0',
      change: 0,
      icon: ArrowDownRight,
    },
  ];

  if (isLoading) {
    return (
      <div className="bg-[#1a1a1a] border border-[#2a2a2a] rounded-xl p-6">
        <div className="flex items-center justify-center h-32">
          <div className="animate-spin w-8 h-8 border-2 border-[#d0ff59] border-t-transparent rounded-full" />
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-6">
      {/* Price Header */}
      <div className="bg-[#1a1a1a] border border-[#2a2a2a] rounded-xl p-6">
        <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4 mb-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <h2 className="text-2xl sm:text-3xl font-bold text-white">
                {selectedSymbol.replace('USDT', '')}/USDT
              </h2>
              <span className="px-2 py-1 bg-[#d0ff59]/20 text-[#d0ff59] text-xs rounded-full font-medium">
                Perpetual
              </span>
            </div>
            <div className="flex flex-wrap items-center gap-3">
              <span className="text-3xl sm:text-4xl font-bold text-white">
                ${data.price > 0 ? data.price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : '0.00'}
              </span>
              <span className={cn(
                "flex items-center gap-1 px-2 py-1 rounded-lg text-sm font-medium",
                data.change24h >= 0 ? "bg-green-500/20 text-green-400" : "bg-red-500/20 text-red-400"
              )}>
                {data.change24h >= 0 ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
                {data.change24h >= 0 ? '+' : ''}{data.change24h.toFixed(2)}%
              </span>
            </div>
          </div>
          
          <div className="flex items-center gap-2 text-[#888888] text-sm">
            <Clock className="w-4 h-4" />
            <span>Updated {lastUpdate.toLocaleTimeString()}</span>
            <button 
              onClick={() => {
                setIsLoading(true);
                fetchTickerData();
                fetchCandleData();
              }}
              className="p-1 hover:bg-white/10 rounded transition-colors"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="flex flex-wrap gap-2 mt-4">
          {['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'BNBUSDT', 'ADAUSDT'].map((symbol) => (
            <button
              key={symbol}
              onClick={() => onSymbolChange(symbol)}
              className={cn(
                "px-3 py-1.5 rounded-lg text-sm font-medium transition-all",
                selectedSymbol === symbol 
                  ? "bg-[#d0ff59] text-black" 
                  : "bg-[#2a2a2a] text-[#888888] hover:bg-[#3a3a3a] hover:text-white"
              )}
            >
              {symbol.replace('USDT', '')}
            </button>
          ))}
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {stats.map((stat, idx) => (
          <div 
            key={idx}
            className="bg-[#1a1a1a] border border-[#2a2a2a] rounded-xl p-4 hover:border-[#d0ff59]/30 transition-colors"
          >
            <div className="flex items-center gap-2 mb-2">
              <stat.icon className={cn(
                "w-4 h-4",
                stat.change > 0 ? "text-green-400" : 
                stat.change < 0 ? "text-red-400" : "text-[#888888]"
              )} />
              <span className="text-xs text-[#888888] uppercase tracking-wider">{stat.label}</span>
            </div>
            <div className={cn(
              "text-lg font-bold",
              stat.change > 0 ? "text-green-400" : 
              stat.change < 0 ? "text-red-400" : "text-white"
            )}>
              {stat.value}
            </div>
          </div>
        ))}
      </div>

      {/* REAL CHART - Using lightweight-charts */}
      <div className="bg-[#1a1a1a] border border-[#2a2a2a] rounded-xl p-4">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-[#d0ff59]" />
            <h3 className="text-lg font-semibold text-white">Price Chart</h3>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs text-[#888888]">1H Interval</span>
            <div className="flex items-center gap-1 text-xs">
              <span className="w-3 h-3 rounded-sm bg-[#d0ff59]"></span>
              <span className="text-[#888888]">Up</span>
              <span className="w-3 h-3 rounded-sm bg-red-500 ml-2"></span>
              <span className="text-[#888888]">Down</span>
            </div>
          </div>
        </div>
        <div 
          ref={chartContainerRef} 
          className="w-full h-[350px] rounded-lg overflow-hidden"
        />
      </div>

      {/* Market Regime */}
      <div className="bg-[#1a1a1a] border border-[#2a2a2a] rounded-xl p-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div className="flex items-center gap-3">
            <Activity className="w-5 h-5 text-[#d0ff59]" />
            <div>
              <div className="text-sm font-medium text-white">Market Regime</div>
              <div className="text-xs text-[#888888]">Current market condition</div>
            </div>
          </div>
          <div className={cn(
            "px-4 py-2 rounded-lg font-medium self-start sm:self-auto",
            tradingState.marketRegime === 'TREND' ? "bg-green-500/20 text-green-400" :
            tradingState.marketRegime === 'CHOP' ? "bg-yellow-500/20 text-yellow-400" :
            tradingState.marketRegime === 'PANIC' ? "bg-red-500/20 text-red-400" :
            tradingState.marketRegime === 'BREAKOUT' ? "bg-[#d0ff59]/20 text-[#d0ff59]" :
            "bg-[#2a2a2a] text-[#888888]"
          )}>
            {tradingState.marketRegime}
          </div>
        </div>
        
        <div className="mt-3 text-sm text-[#888888]">
          {tradingState.marketRegime === 'TREND' && "Strong directional movement detected. Trend-following strategies recommended."}
          {tradingState.marketRegime === 'CHOP' && "Sideways price action. Range trading or waiting for breakout advised."}
          {tradingState.marketRegime === 'PANIC' && "High volatility and fear detected. Reduce position sizes, tight stops."}
          {tradingState.marketRegime === 'BREAKOUT' && "Price breaking key levels. Momentum strategies effective."}
          {tradingState.marketRegime === 'RANGE' && "Price oscillating between support and resistance."}
        </div>
      </div>
    </div>
  );
}

export default MarketOverview;
