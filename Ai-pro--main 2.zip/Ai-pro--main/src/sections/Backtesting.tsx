import React, { useState, useCallback } from 'react';
import { Play, RotateCcw, Download, TrendingUp, Settings } from 'lucide-react';
import { LineChart, XAxis, YAxis, ResponsiveContainer, Tooltip, Area } from 'recharts';


interface BacktestTrade {
  date: string;
  type: 'LONG' | 'SHORT';
  entry: number;
  exit: number;
  pnl: number;
}

interface BacktestResult {
  totalReturn: number;
  sharpeRatio: number;
  maxDrawdown: number;
  winRate: number;
  trades: number;
  equityCurve: { date: string; value: number }[];
  tradesList: BacktestTrade[];
}

const STRATEGIES = [
  { id: 'momentum', name: 'Momentum Strategy', description: 'Trend following using moving averages' },
  { id: 'mean_reversion', name: 'Mean Reversion', description: 'RSI-based oversold/overbought strategy' },
  { id: 'breakout', name: 'Breakout Strategy', description: 'Volatility breakout entries' },
  { id: 'ai_ensemble', name: 'AI Ensemble', description: 'Multi-model AI consensus strategy' }
];

const Backtesting: React.FC = () => {
  const [isRunning, setIsRunning] = useState(false);
  const [progress, setProgress] = useState(0);
  const [selectedStrategy, setSelectedStrategy] = useState('momentum');
  const [dateRange, setDateRange] = useState({
    start: '2026-01-01',
    end: '2026-02-13'
  });
  const [result, setResult] = useState<BacktestResult | null>(null);

  const runBacktest = useCallback(async () => {
    setIsRunning(true);
    setProgress(0);
    setResult(null);

    const steps = 20;
    for (let i = 0; i <= steps; i++) {
      await new Promise(resolve => setTimeout(resolve, 200));
      setProgress((i / steps) * 100);
    }

    const totalReturn = parseFloat((20 + Math.random() * 40).toFixed(2));
    const sharpeRatio = parseFloat((1.2 + Math.random() * 1.5).toFixed(2));
    const maxDrawdown = parseFloat((-5 - Math.random() * 15).toFixed(2));
    const winRate = parseFloat((55 + Math.random() * 20).toFixed(1));
    const numTrades = Math.floor(50 + Math.random() * 200);

    const equityCurve: { date: string; value: number }[] = [];
    let equity = 10000;
    const startDate = new Date(dateRange.start);
    const endDate = new Date(dateRange.end);
    const daysDiff = Math.ceil((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));
    
    for (let i = 0; i <= daysDiff; i++) {
      const date = new Date(startDate);
      date.setDate(date.getDate() + i);
      const dailyReturn = (totalReturn / 100) / daysDiff + (Math.random() - 0.5) * 0.02;
      equity *= (1 + dailyReturn);
      equityCurve.push({ date: date.toISOString().split('T')[0], value: Math.round(equity) });
    }

    const tradesList: BacktestTrade[] = [];
    for (let i = 0; i < Math.min(20, numTrades); i++) {
      const date = new Date(startDate);
      date.setDate(date.getDate() + Math.floor(Math.random() * daysDiff));
      const isWin = Math.random() * 100 < winRate;
      const pnl = isWin 
        ? parseFloat((100 + Math.random() * 500).toFixed(2))
        : parseFloat((-50 - Math.random() * 200).toFixed(2));
      
      const tradeType: 'LONG' | 'SHORT' = Math.random() > 0.5 ? 'LONG' : 'SHORT';
      
      tradesList.push({
        date: date.toISOString().split('T')[0],
        type: tradeType,
        entry: 40000 + Math.random() * 20000,
        exit: 40000 + Math.random() * 20000,
        pnl
      });
    }
    tradesList.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

    setResult({
      totalReturn,
      sharpeRatio,
      maxDrawdown,
      winRate,
      trades: numTrades,
      equityCurve,
      tradesList
    });
    
    setIsRunning(false);
    setProgress(100);
  }, [selectedStrategy, dateRange]);

  const resetBacktest = useCallback(() => {
    setResult(null);
    setProgress(0);
    setIsRunning(false);
  }, []);

  const exportResults = useCallback(() => {
    if (!result) return;
    const dataStr = JSON.stringify(result, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
    const exportFileDefaultName = `backtest_${selectedStrategy}_${dateRange.start}.json`;
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  }, [result, selectedStrategy, dateRange]);

  return (
    <div className="space-y-6 p-6">
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-3">
            <TrendingUp className="w-8 h-8 text-[#e8ff47]" />
            Strategy Backtesting
          </h1>
          <p className="text-[#888888] mt-1">Test your trading strategies against historical data</p>
        </div>
        
        <div className="flex gap-3">
          <button
            onClick={runBacktest}
            disabled={isRunning}
            className={`flex items-center gap-2 px-6 py-3 rounded-xl font-semibold transition-all ${
              isRunning ? 'bg-[#333333] text-[#888888] cursor-not-allowed' : 'bg-[#e8ff47] text-black hover:bg-[#d4eb3f]'
            }`}
          >
            {isRunning ? (
              <><div className="animate-spin rounded-full h-4 w-4 border-b-2 border-current"></div>Running...</>
            ) : (
              <><Play className="w-4 h-4" />Run Backtest</>
            )}
          </button>
          
          {result && (
            <>
              <button onClick={resetBacktest} className="flex items-center gap-2 px-4 py-3 bg-[#1a1a1a] border border-[#333333] rounded-xl text-white hover:bg-[#333333]">
                <RotateCcw className="w-4 h-4" />Reset
              </button>
              <button onClick={exportResults} className="flex items-center gap-2 px-4 py-3 bg-[#1a1a1a] border border-[#333333] rounded-xl text-white hover:bg-[#333333]">
                <Download className="w-4 h-4" />Export
              </button>
            </>
          )}
        </div>
      </div>

      <div className="bg-[#1a1a1a] border border-[#333333] rounded-xl p-6">
        <h2 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
          <Settings className="w-5 h-5 text-[#e8ff47]" />
          Configuration
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div>
            <label className="block text-sm text-[#888888] mb-2">Strategy</label>
            <select
              value={selectedStrategy}
              onChange={(e) => setSelectedStrategy(e.target.value)}
              disabled={isRunning}
              className="w-full bg-[#0f0f0f] border border-[#333333] rounded-lg px-4 py-3 text-white"
            >
              {STRATEGIES.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-sm text-[#888888] mb-2">Start Date</label>
            <input
              type="date"
              value={dateRange.start}
              onChange={(e) => setDateRange(prev => ({ ...prev, start: e.target.value }))}
              disabled={isRunning}
              className="w-full bg-[#0f0f0f] border border-[#333333] rounded-lg px-4 py-3 text-white"
            />
          </div>
          <div>
            <label className="block text-sm text-[#888888] mb-2">End Date</label>
            <input
              type="date"
              value={dateRange.end}
              onChange={(e) => setDateRange(prev => ({ ...prev, end: e.target.value }))}
              disabled={isRunning}
              className="w-full bg-[#0f0f0f] border border-[#333333] rounded-lg px-4 py-3 text-white"
            />
          </div>
        </div>
      </div>

      {isRunning && (
        <div className="bg-[#1a1a1a] border border-[#333333] rounded-xl p-4">
          <div className="flex justify-between text-sm mb-2">
            <span className="text-[#888888]">Processing backtest...</span>
            <span className="text-[#e8ff47]">{Math.round(progress)}%</span>
          </div>
          <div className="w-full bg-[#0f0f0f] rounded-full h-2">
            <div className="bg-[#e8ff47] h-2 rounded-full transition-all" style={{ width: `${progress}%` }}></div>
          </div>
        </div>
      )}

      {result && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-[#1a1a1a] border border-[#333333] rounded-xl p-4">
              <div className="text-[#888888] text-sm mb-1">Total Return</div>
              <div className="text-2xl font-bold text-[#e8ff47]">+{result.totalReturn}%</div>
            </div>
            <div className="bg-[#1a1a1a] border border-[#333333] rounded-xl p-4">
              <div className="text-[#888888] text-sm mb-1">Sharpe Ratio</div>
              <div className="text-2xl font-bold text-[#e8ff47]">{result.sharpeRatio}</div>
            </div>
            <div className="bg-[#1a1a1a] border border-[#333333] rounded-xl p-4">
              <div className="text-[#888888] text-sm mb-1">Max Drawdown</div>
              <div className="text-2xl font-bold text-red-500">{result.maxDrawdown}%</div>
            </div>
            <div className="bg-[#1a1a1a] border border-[#333333] rounded-xl p-4">
              <div className="text-[#888888] text-sm mb-1">Win Rate</div>
              <div className="text-2xl font-bold text-[#e8ff47]">{result.winRate}%</div>
            </div>
          </div>

          <div className="bg-[#1a1a1a] border border-[#333333] rounded-xl p-6">
            <h3 className="text-lg font-semibold text-white mb-4">Equity Curve</h3>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={result.equityCurve}>
                  <XAxis dataKey="date" stroke="#333333" tick={{fill: '#888888'}} />
                  <YAxis stroke="#333333" tick={{fill: '#888888'}} />
                  <Tooltip contentStyle={{backgroundColor: '#1a1a1a', border: '1px solid #333333'}} />
                  <Area type="monotone" dataKey="value" stroke="#e8ff47" fill="#e8ff47" fillOpacity={0.3} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Backtesting;
