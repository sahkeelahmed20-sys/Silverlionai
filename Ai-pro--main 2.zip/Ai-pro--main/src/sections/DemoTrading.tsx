import { useState, useEffect, useCallback, useRef } from 'react';
import {
  Wallet,
  TrendingUp,
  TrendingDown,
  Clock,
  Target,
  Shield,
  ArrowUpRight,
  ArrowDownRight,
  History,
  Play,
  Brain,
  Bot,
  X,
  Activity,
  Sparkles,
  BarChart3,
  Settings,
  Trash2
} from 'lucide-react';
import { useDemoTrading } from '../hooks/useDemoTrading';
import type { TradingState } from '../App';
import {
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  AreaChart,
  Area
} from 'recharts';
import { useAutoTrading } from '../hooks/useAutoTrading';

interface DemoTradingProps {
  tradingState?: TradingState;
  initialBalance?: number;
  onSignalGenerated?: (signal: ActiveSignal) => void;
}

// Top 10 crypto coins by market cap
const TOP_10_COINS = [
  'BTCUSDT',
  'ETHUSDT',
  'BNBUSDT',
  'SOLUSDT',
  'XRPUSDT',
  'ADAUSDT',
  'AVAXUSDT',
  'DOGEUSDT',
  'DOTUSDT',
  'MATICUSDT'
];

interface Signal {
  symbol: string;
  action: 'BUY' | 'SELL' | 'HOLD';
  confidence: number;
  reason: string;
  indicators: {
    rsi: number;
    macd: string;
    ema: string;
    trend: string;
  };
  entry: number;
  stopLoss: number;
  takeProfit: number;
  riskReward: number;
}

interface ChartData {
  time: string;
  equity: number;
}

interface TradeSettings {
  amountType: 'fixed' | 'percentage';
  amountValue: number;
  leverageType: 'fixed' | 'ai';
  fixedLeverage: number;
}

// Define ActiveSignal interface locally since it's used here
interface ActiveSignal {
  symbol: string;
  type: 'BUY' | 'SELL' | 'HOLD';
  confidence: number;
  entry: number;
  stopLoss: number;
  takeProfit: number;
  riskReward: number;
  timestamp: string;
  executed: boolean;
}

// Default trading settings
const DEFAULT_TRADE_SETTINGS: TradeSettings = {
  amountType: 'fixed',
  amountValue: 100,
  leverageType: 'fixed',
  fixedLeverage: 50
};

function formatRelativeTime(dateString: string): string {
  const date = new Date(dateString);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMs / 3600000);
  if (diffMins < 1) return 'Just now';
  if (diffMins < 60) return `${diffMins}m ago`;
  if (diffHours < 24) return `${diffHours}h ago`;
  return `${Math.floor(diffMs / 86400000)}d ago`;
}

function formatTradeTime(dateString: string): string {
  const date = new Date(dateString);
  return date.toLocaleString('en-US', {
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
}

// Calculate real technical indicators from price data
function calculateRSI(prices: number[]): number {
  if (prices.length < 14) return 50;
  let gains = 0;
  let losses = 0;
  for (let i = 1; i < 14; i++) {
    const change = prices[i] - prices[i - 1];
    if (change > 0) gains += change;
    else losses -= change;
  }
  const avgGain = gains / 14;
  const avgLoss = losses / 14;
  if (avgLoss === 0) return 100;
  const rs = avgGain / avgLoss;
  return 100 - (100 / (1 + rs));
}

function calculateEMA(prices: number[], period: number): number {
  const k = 2 / (period + 1);
  let ema = prices[0];
  for (let i = 1; i < prices.length; i++) {
    ema = prices[i] * k + ema * (1 - k);
  }
  return ema;
}

function calculateMACD(prices: number[]): { value: number; signal: string } {
  if (prices.length < 26) return { value: 0, signal: 'Neutral' };
  const ema12 = calculateEMA(prices, 12);
  const ema26 = calculateEMA(prices, 26);
  const macd = ema12 - ema26;
  return {
    value: macd,
    signal: macd > 0 ? 'Bullish' : macd < 0 ? 'Bearish' : 'Neutral'
  };
}

// Generate signal using REAL market data - MADE MORE STRICT
function generateRealSignal(
  symbol: string,
  currentPrice: number,
  priceHistory: number[],
  regime: string
): Signal {
  const rsi = calculateRSI(priceHistory);
  const macd = calculateMACD(priceHistory);
  // Calculate EMAs
  const emaShort = priceHistory.length >= 12 ? calculateEMA(priceHistory.slice(-12), 12) : currentPrice;
  const emaLong = priceHistory.length >= 26 ? calculateEMA(priceHistory.slice(-26), 26) : currentPrice;
  // Price momentum (last 5 candles)
  const momentum = priceHistory.length >= 5
    ? (currentPrice - priceHistory[priceHistory.length - 5]) / priceHistory[priceHistory.length - 5] * 100
    : 0;
  // Calculate technical score (-100 to +100)
  let technicalScore = 0;
  let technicalReason = '';
  // RSI component (0-40 points)
  if (rsi < 30) {
    technicalScore += 40;
    technicalReason = 'Oversold (RSI < 30)';
  } else if (rsi > 70) {
    technicalScore -= 40;
    technicalReason = 'Overbought (RSI > 70)';
  } else {
    technicalScore += (50 - rsi) * 0.8;
    technicalReason = `RSI neutral (${rsi.toFixed(1)})`;
  }
  // MACD component (0-30 points)
  if (macd.signal === 'Bullish') {
    technicalScore += 30;
    technicalReason += ' + MACD Bullish';
  } else if (macd.signal === 'Bearish') {
    technicalScore -= 30;
    technicalReason += ' + MACD Bearish';
  }
  // EMA component (0-20 points)
  if (emaShort > emaLong) {
    technicalScore += 20;
    technicalReason += ' + Above EMA';
  } else {
    technicalScore -= 20;
    technicalReason += ' + Below EMA';
  }
  // Momentum component (0-10 points)
  technicalScore += Math.max(-10, Math.min(10, momentum * 2));
  // Market regime adjustment
  let marketScore = 0;
  if (regime === 'TREND') {
    marketScore = technicalScore > 0 ? 10 : -10;
  } else if (regime === 'PANIC') {
    marketScore = rsi < 25 ? 15 : -5;
  }
  const finalScore = technicalScore + marketScore;
  // Calculate confidence (0-100) - MADE MORE STRICT (reduced multiplier)
  const rawConfidence = Math.min(100, Math.abs(finalScore) * 0.8);
  const confidence = Math.max(0, rawConfidence);
  // Determine action - only BUY or SELL if confidence >= 85%
  let action: 'BUY' | 'SELL' | 'HOLD' = 'HOLD';
  let finalReason = '';
  let stopLoss: number;
  let takeProfit: number;
  let riskReward: number;
  if (confidence >= 80 && finalScore > 30) {
    action = 'BUY';
    finalReason = `STRONG BUY: ${technicalReason} | Confidence: ${confidence.toFixed(1)}%`;
    stopLoss = currentPrice * 0.97; // 3% stop loss
    takeProfit = currentPrice * 1.06; // 6% take profit
    riskReward = 2.0;
  } else if (confidence >= 80 && finalScore < -30) {
    action = 'SELL';
    finalReason = `STRONG SELL: ${technicalReason} | Confidence: ${confidence.toFixed(1)}%`;
    stopLoss = currentPrice * 1.03; // 3% stop loss
    takeProfit = currentPrice * 0.94; // 6% take profit
    riskReward = 2.0;
  } else {
    finalReason = `HOLD: Confidence ${confidence.toFixed(1)}% below 80% threshold. ${technicalReason}`;
    stopLoss = currentPrice * 0.95;
    takeProfit = currentPrice * 1.05;
    riskReward = 0;
  }
  return {
    symbol,
    action,
    confidence,
    reason: finalReason,
    indicators: {
      rsi: Math.round(rsi * 10) / 10,
      macd: macd.signal,
      ema: emaShort > emaLong ? 'Above' : 'Below',
      trend: regime
    },
    entry: currentPrice,
    stopLoss,
    takeProfit,
    riskReward
  };
}

// Helper to get trade settings from localStorage
const getTradeSettings = (): TradeSettings => {
  const saved = localStorage.getItem('tradeSettings');
  return saved ? JSON.parse(saved) : DEFAULT_TRADE_SETTINGS;
};

export function DemoTrading({ tradingState, initialBalance: propInitialBalance = 100000, onSignalGenerated }: DemoTradingProps) {
  // Load starting balance from localStorage (synced with settings)
  const [startingBalance, setStartingBalance] = useState(() => {
    const saved = localStorage.getItem('demoStartingBalance');
    return saved ? parseFloat(saved) : propInitialBalance;
  });
  // Load trade settings
  const [tradeSettings, setTradeSettings] = useState<TradeSettings>(getTradeSettings());
  const {
    positions,
    prices,
    trades,
    balance,
    equity,
    openPosition,
    closePosition
  } = useDemoTrading();
  
  const [aiTrading, setAiTrading] = useState(false);
  const [currentSignal, setCurrentSignal] = useState<Signal | null>(null);
  const [lastSignal, setLastSignal] = useState<ActiveSignal | null>(null);
  const [signalHistory, setSignalHistory] = useState<ActiveSignal[]>([]);
  const [analysisLog, setAnalysisLog] = useState<string[]>([]);
  const [chartData, setChartData] = useState<ChartData[]>([]);
  // Price history for technical analysis
  const [priceHistory, setPriceHistory] = useState<Record<string, number[]>>({});
  // Track last trade time per coin to prevent stacking
  const lastTradeTimeRef = useRef<Record<string, number>>({});

  // Use auto trading hook
  const { 
    scanning
  } = useAutoTrading({
    enabled: aiTrading,
    confidenceThreshold: 80,
    maxPositions: 5,
    positionSize: 1000,
    leverage: 1,
    scanIntervalMs: 30000,
  });
  
  // Update price history when new prices arrive
  useEffect(() => {
    setPriceHistory(prev => {
      const updated = { ...prev };
      Object.entries(prices).forEach(([symbol, price]) => {
        if (!updated[symbol]) updated[symbol] = [];
        updated[symbol] = [...updated[symbol], price].slice(-50); // Keep last 50 prices
      });
      return updated;
    });
  }, [prices]);
  
  // Sync starting balance and trade settings from localStorage when they change
  useEffect(() => {
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === 'demoStartingBalance') {
        const saved = localStorage.getItem('demoStartingBalance');
        if (saved) setStartingBalance(parseFloat(saved));
      }
      if (e.key === 'tradeSettings') {
        setTradeSettings(getTradeSettings());
      }
    };
    window.addEventListener('storage', handleStorageChange);

    // Also check periodically
    const interval = setInterval(() => {
      const savedBalance = localStorage.getItem('demoStartingBalance');
      if (savedBalance) {
        const newBalance = parseFloat(savedBalance);
        if (newBalance !== startingBalance) setStartingBalance(newBalance);
      }
      const savedSettings = localStorage.getItem('tradeSettings');
      if (savedSettings) {
        const newSettings = JSON.parse(savedSettings);
        if (JSON.stringify(newSettings) !== JSON.stringify(tradeSettings)) {
          setTradeSettings(newSettings);
        }
      }
    }, 1000);

    return () => {
      window.removeEventListener('storage', handleStorageChange);
      clearInterval(interval);
    };
  }, [startingBalance, tradeSettings]);
  
  // Update equity chart
  useEffect(() => {
    const interval = setInterval(() => {
      setChartData(prev => {
        const newData = [...prev.slice(-49), {
          time: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
          equity: equity,
        }];
        return newData;
      });
    }, 3000);
    return () => clearInterval(interval);
  }, [equity]);
  
  const addLog = useCallback((message: string) => {
    setAnalysisLog(prev => [message, ...prev].slice(0, 20));
  }, []);
  
  // Calculate derived values - FIXED to use proper leverage
  const totalUnrealizedPnl = positions.reduce((acc, pos) => acc + pos.pnl, 0);
  const totalUsedMargin = positions.reduce((acc, pos) => {
    const notionalValue = pos.entryPrice * pos.size;
    const leverage = pos.leverage || 10;
    return acc + (notionalValue / leverage);
  }, 0);
  const availableMargin = Math.max(0, balance - totalUsedMargin);
  const totalReturn = startingBalance > 0 ? ((equity - startingBalance) / startingBalance) * 100 : 0;
  
  // Calculate current trade preview based on settings
  const getTradePreview = () => {
    const settings = tradeSettings;
    let tradeAmount: number;
    if (settings.amountType === 'fixed') {
      tradeAmount = settings.amountValue;
    } else {
      tradeAmount = balance * (settings.amountValue / 100);
    }

    // Cap at available balance
    tradeAmount = Math.min(tradeAmount, availableMargin * 0.95);

    const leverage = settings.leverageType === 'fixed' ? settings.fixedLeverage : 10;
    const positionValue = tradeAmount * leverage;

    return { tradeAmount, leverage, positionValue };
  };
  
  // AI Trading Logic - FIXED to prevent random trades and stacking
  useEffect(() => {
    if (!aiTrading) return;
    
    const analyzeAllCoins = async () => {
      const regime = tradingState?.marketRegime || 'TREND';
      const settings = getTradeSettings();
      const now = Date.now();
      
      addLog(`[${new Date().toLocaleTimeString()}] Scanning ${TOP_10_COINS.length} coins for 80%+ signals...`);
      
      let executedCount = 0;
      let skippedCount = 0;
      let cooldownCount = 0;
      
      // Analyze all coins
      for (const symbol of TOP_10_COINS) {
        const price = prices[symbol];
        const history = priceHistory[symbol] || [];
        
        // Skip if no price data
        if (!price) {
          continue;
        }
        
        // Skip if collecting data
        if (history.length < 26) {
          continue;
        }
        
        // CHECK: Cooldown period - don't trade same coin within 60 seconds
        const lastTradeTime = lastTradeTimeRef.current[symbol] || 0;
        if (now - lastTradeTime < 60000) {
          cooldownCount++;
          continue;
        }
        
        // CHECK: Already have position in this coin
        const existingPosition = positions.find(p => p.symbol === symbol);
        if (existingPosition) {
          // Check SL/TP for existing position
          const pnlPercent = existingPosition.pnlPercent;
          const hitTP = pnlPercent >= 10;
          const hitSL = pnlPercent <= -5;
          
          if (hitTP) {
            closePosition(existingPosition.id);
            addLog(`🎯 TP Hit: ${existingPosition.side} ${symbol} +${pnlPercent.toFixed(2)}%`);
            lastTradeTimeRef.current[symbol] = now;
          } else if (hitSL) {
            closePosition(existingPosition.id);
            addLog(`🛑 SL Hit: ${existingPosition.side} ${symbol} ${pnlPercent.toFixed(2)}%`);
            lastTradeTimeRef.current[symbol] = now;
          }
          continue;
        }
        
        // Generate signal
        const signal = generateRealSignal(symbol, price, history, regime);
        
        // STRICT CHECK: Only trade if confidence >= 80% and action is BUY or SELL
        if (signal.confidence >= 80 && (signal.action === 'BUY' || signal.action === 'SELL')) {
          // Calculate trade amount
          let tradeAmount: number;
          if (settings.amountType === 'fixed') {
            tradeAmount = settings.amountValue;
          } else {
            tradeAmount = balance * (settings.amountValue / 100);
          }
          
          // Cap at available margin
          tradeAmount = Math.min(tradeAmount, availableMargin * 0.95);
          
          // Check sufficient margin
          if (tradeAmount > availableMargin) {
            addLog(`⚠ Insufficient margin for ${symbol}`);
            skippedCount++;
            continue;
          }
          
          // Calculate leverage
          let leverage: number;
          if (settings.leverageType === 'fixed') {
            leverage = settings.fixedLeverage;
          } else {
            leverage = signal.confidence > 90 ? 5 : signal.confidence > 80 ? 3 : 2;
          }
          
          // Calculate position size
          const size = (tradeAmount * leverage) / price;
          const side = signal.action === 'BUY' ? 'LONG' : 'SHORT';
          const positionValue = tradeAmount * leverage;
          
          // OPEN POSITION with AI-calculated SL/TP
          openPosition(symbol, side, size, leverage, signal.stopLoss, signal.takeProfit);
          lastTradeTimeRef.current[symbol] = now;
          executedCount++;
          
          addLog(`🚀 EXECUTED ${side} ${symbol} @ $${price.toFixed(2)}`);
          addLog(`   Confidence: ${signal.confidence.toFixed(1)}% | Margin: $${tradeAmount.toFixed(2)} | Leverage: ${leverage}x | Value: $${positionValue.toFixed(2)}`);
          
          // Update signal display
          const activeSignal: ActiveSignal = {
            symbol,
            type: signal.action,
            confidence: signal.confidence,
            entry: signal.entry,
            stopLoss: signal.stopLoss,
            takeProfit: signal.takeProfit,
            riskReward: signal.riskReward,
            timestamp: new Date().toISOString(),
            executed: true,
          };
          setLastSignal(activeSignal);
          setSignalHistory(prev => [activeSignal, ...prev].slice(0, 15));
          setCurrentSignal(signal);
          
          if (onSignalGenerated) {
            onSignalGenerated(activeSignal);
          }
          
          // Break after first execution to prevent multiple trades in one scan
          break;
        } else {
          // Log skipped signals with low confidence
          if (signal.confidence >= 80) {
            addLog(`⏸ ${symbol}: ${signal.action} ${signal.confidence.toFixed(0)}% (below 80% threshold)`);
          }
          skippedCount++;
        }
      }
      
      addLog(`✓ Scan complete: ${executedCount} executed, ${skippedCount} skipped, ${cooldownCount} in cooldown`);
    };

    // Run immediately
    analyzeAllCoins();

    // Set interval - 30 seconds to prevent over-trading
    const interval = setInterval(analyzeAllCoins, 30000);

    return () => clearInterval(interval);
  }, [aiTrading, positions, availableMargin, prices, priceHistory, tradingState, addLog, openPosition, closePosition, onSignalGenerated, balance]);
  
  const manualClosePosition = (id: number) => {
    const pos = positions.find(p => p.id === id);
    if (!pos) return;
    closePosition(id);
    addLog(`👤 Manual close: ${pos.side} ${pos.symbol}`);
  };
  
  const handleClearHistory = useCallback(() => {
    if (window.confirm('Are you sure you want to clear all trade history? This cannot be undone.')) {
      // Clear trades from localStorage and state
      localStorage.removeItem('demo_trades');
      // Reload page to reset state or implement clear in useDemoTrading hook
      window.location.reload();
    }
  }, []);
  
  const formatSymbol = (symbol: string) => symbol.replace('USDT', '');
  
  // Calculate win rate from actual trades
  const winningTrades = trades.filter(t => (t.pnl || 0) > 0).length;
  const winRate = trades.length > 0 ? (winningTrades / trades.length) * 100 : 0;
  
  // Get active coins (with price data)
  const activeCoins = TOP_10_COINS.filter(coin => prices[coin]);
  
  // Get trade preview
  const preview = getTradePreview();
  
  // Sort trades by timestamp (newest first)
  const sortedTrades = [...trades].sort((a, b) => {
    const timeA = new Date(a.timestamp).getTime();
    const timeB = new Date(b.timestamp).getTime();
    return timeB - timeA;
  });
  
  // Calculate trade statistics
  const tradeStats = {
    totalTrades: trades.length,
    winningTrades,
    losingTrades: trades.length - winningTrades,
    winRate,
    totalPnl: trades.reduce((sum, t) => sum + (t.pnl || 0), 0),
    avgPnl: trades.length > 0 ? trades.reduce((sum, t) => sum + (t.pnl || 0), 0) / trades.length : 0
  };
  
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <h2 className="text-xl font-bold text-[#f6f6f6] flex items-center gap-2">
          <Wallet className="w-5 h-5 text-[#d0ff59]" />
          Demo Trading Account
        </h2>
        <div className="flex items-center gap-2 flex-wrap">
          {aiTrading && (
            <div className="flex items-center gap-2 px-3 py-1.5 bg-[#d0ff59]/10 rounded-lg border border-[#d0ff59]/30">
              <Bot className="w-4 h-4 text-[#d0ff59] animate-pulse" />
              <span className="text-sm text-[#d0ff59]">AI Active</span>
            </div>
          )}
          <div className="flex items-center gap-2 px-3 py-1.5 bg-[#1a1a1a] rounded-lg border border-[#333333]">
            <span className="text-xs text-[#888888]">Coins:</span>
            <span className="text-sm text-[#d0ff59]">{activeCoins.length}/10</span>
          </div>
          <button
            onClick={() => setAiTrading(!aiTrading)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all ${
              aiTrading
                ? 'bg-red-500/20 text-red-500 border border-red-500/30 hover:bg-red-500/30'
                : 'bg-[#d0ff59] text-black hover:bg-[#d0ff59]/90'
            }`}
          >
            {aiTrading ? (
              <>
                <X className="w-4 h-4" />
                Stop
              </>
            ) : (
              <>
                <Play className="w-4 h-4" />
                Start AI
              </>
            )}
          </button>
          <button
            onClick={() => window.location.reload()}
            className="flex items-center gap-2 px-3 py-2 bg-[#333333] text-[#888888] rounded-lg hover:bg-[#444444] transition-colors text-sm"
          >
            Reset
          </button>
        </div>
      </div>

      {/* Active Coins - Shows all 10 with status */}
      <div className="flex flex-wrap gap-2">
        {TOP_10_COINS.map((coin) => {
          const price = prices[coin];
          const hasPosition = positions.some(p => p.symbol === coin);
          return (
            <div 
              key={coin} 
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                price 
                  ? hasPosition
                    ? 'bg-[#d0ff59] text-black'
                    : 'bg-[#1a1a1a] text-[#888888] border border-[#333333]'
                  : 'bg-[#0b0b0b] text-[#555555]'
              }`}
            >
              {formatSymbol(coin)} {price ? `$${price.toLocaleString()}` : '...'}
              {hasPosition && ' ●'}
            </div>
          );
        })}
      </div>

      {/* Current Settings Preview */}
      <div className="bg-[#0b0b0b] border border-[#222222] rounded-2xl p-4">
        <div className="flex items-center gap-2 mb-4">
          <Settings className="w-5 h-5 text-[#d0ff59]" />
          <h3 className="font-semibold text-[#f6f6f6]">Active Trade Settings</h3>
        </div>
        <div className="grid grid-cols-3 gap-4 mb-4">
          <div className="p-3 bg-[#1a1a1a] rounded-xl">
            <p className="text-xs text-[#888888] mb-1">Trade Amount</p>
            <p className="text-lg font-bold text-[#f6f6f6]">
              {tradeSettings.amountType === 'fixed' ? `$${tradeSettings.amountValue}` : `${tradeSettings.amountValue}%`}
            </p>
            <p className="text-xs text-[#888888]">
              {tradeSettings.amountType === 'fixed' ? 'Fixed USD' : 'Of balance'}
            </p>
          </div>
          <div className="p-3 bg-[#1a1a1a] rounded-xl">
            <p className="text-xs text-[#888888] mb-1">Leverage</p>
            <p className="text-lg font-bold text-[#d0ff59]">
              {tradeSettings.leverageType === 'fixed' ? `${tradeSettings.fixedLeverage}x` : 'AI Auto'}
            </p>
            <p className="text-xs text-[#888888]">
              {tradeSettings.leverageType === 'fixed' ? 'Fixed' : '2x - 5x'}
            </p>
          </div>
          <div className="p-3 bg-[#1a1a1a] rounded-xl">
            <p className="text-xs text-[#888888] mb-1">Next Trade Value</p>
            <p className="text-lg font-bold text-[#d0ff59]">
              ${preview.positionValue.toFixed(2)}
            </p>
            <p className="text-xs text-[#888888]">
              Margin: ${preview.tradeAmount.toFixed(2)}
            </p>
          </div>
        </div>
        <p className="text-xs text-[#888888]">
          Example: With ${preview.tradeAmount.toFixed(2)} margin and {preview.leverage}x leverage, 
          your position value will be ${preview.positionValue.toFixed(2)}
        </p>
      </div>

      {lastSignal && (
        <div className="bg-gradient-to-r from-[#1a1a1a] to-[#0d0d0d] border border-[#333333] rounded-2xl p-4">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-[#d0ff59]" />
              <h3 className="font-semibold text-[#f6f6f6]">Latest Signal</h3>
              <span className="text-xs text-[#888888] bg-[#222222] px-2 py-0.5 rounded">
                {formatSymbol(lastSignal.symbol)}
              </span>
              {lastSignal.executed && (
                <span className="text-xs bg-[#d0ff59]/20 text-[#d0ff59] px-2 py-0.5 rounded">
                  EXECUTED
                </span>
              )}
            </div>
            <span className="text-xs text-[#888888]">
              {new Date(lastSignal.timestamp).toLocaleTimeString()}
            </span>
          </div>
          <div className="grid grid-cols-5 gap-4">
            <div>
              <p className="text-xs text-[#888888]">Action</p>
              <p className={`font-bold ${lastSignal.type === 'BUY' ? 'text-[#d0ff59]' : lastSignal.type === 'SELL' ? 'text-red-500' : 'text-yellow-500'}`}>
                {lastSignal.type}
              </p>
            </div>
            <div>
              <p className="text-xs text-[#888888]">Confidence</p>
              <p className={`font-bold ${lastSignal.confidence >= 80 ? 'text-[#d0ff59]' : 'text-[#f6f6f6]'}`}>
                {lastSignal.confidence.toFixed(1)}%
              </p>
            </div>
            <div>
              <p className="text-xs text-[#888888]">Entry</p>
              <p className="text-[#f6f6f6]">${lastSignal.entry.toLocaleString()}</p>
            </div>
            <div>
              <p className="text-xs text-[#888888]">Stop Loss</p>
              <p className="text-red-500">${lastSignal.stopLoss.toLocaleString()}</p>
            </div>
            <div>
              <p className="text-xs text-[#888888]">Take Profit</p>
              <p className="text-[#d0ff59]">${lastSignal.takeProfit.toLocaleString()}</p>
            </div>
          </div>
        </div>
      )}

      {/* AI Analysis Card - Collapsible when no data */}
      {aiTrading && (
        <div className="bg-[#0b0b0b] border border-[#222222] rounded-2xl p-4">
          <div className="flex items-center gap-3 mb-4">
            <Brain className="w-5 h-5 text-[#d0ff59] animate-pulse" />
            <h3 className="font-semibold text-[#f6f6f6]">AI Analysis (80%+ Confidence Required)</h3>
            <span className="text-xs text-[#888888] bg-[#1a1a1a] px-2 py-1 rounded">
              {tradingState?.marketRegime || 'TREND'} Mode
            </span>
          </div>
          
          {currentSignal && (
            <div className="grid grid-cols-4 gap-4 mb-4 p-3 bg-[#1a1a1a] rounded-xl">
              <div className="text-center">
                <p className="text-xs text-[#888888] mb-1">Signal</p>
                <p className={`font-bold ${currentSignal.action === 'BUY' ? 'text-[#d0ff59]' : currentSignal.action === 'SELL' ? 'text-red-500' : 'text-yellow-500'}`}>
                  {currentSignal.action}
                </p>
              </div>
              <div className="text-center">
                <p className="text-xs text-[#888888] mb-1">Confidence</p>
                <p className={`font-bold ${currentSignal.confidence >= 80 ? 'text-[#d0ff59]' : 'text-red-500'}`}>
                  {currentSignal.confidence.toFixed(1)}%
                </p>
              </div>
              <div className="text-center">
                <p className="text-xs text-[#888888] mb-1">RSI</p>
                <p className="font-bold text-[#f6f6f6]">{currentSignal.indicators.rsi}</p>
              </div>
              <div className="text-center">
                <p className="text-xs text-[#888888] mb-1">MACD</p>
                <p className="font-bold text-[#f6f6f6]">{currentSignal.indicators.macd}</p>
              </div>
            </div>
          )}
          
          <div className="bg-[#1a1a1a] rounded-xl p-3 max-h-32 overflow-y-auto">
            <p className="text-xs text-[#888888] mb-2">AI Decision Log:</p>
            {analysisLog.length === 0 ? (
              <p className="text-xs text-[#555555]">Waiting for market data...</p>
            ) : (
              analysisLog.map((log, i) => (
                <p key={i} className={`text-xs font-mono ${
                  log.includes('🚀') ? 'text-[#d0ff59]' : 
                  log.includes('✓') ? 'text-[#d0ff59]' : 
                  log.includes('✗') ? 'text-red-500' : 
                  log.includes('⏸') ? 'text-yellow-500' :
                  'text-[#888888]'
                }`}>
                  {log}
                </p>
              ))
            )}
          </div>
        </div>
      )}

      <div className="p-4 bg-[#1a1a1a] border border-[#222222] rounded-xl flex items-center justify-between">
        <div>
          <p className="text-xs text-[#888888] mb-1">Starting Balance</p>
          <p className="text-lg font-bold text-[#f6f6f6]">${startingBalance.toLocaleString('en-US', { minimumFractionDigits: 2 })}</p>
        </div>
        {aiTrading && <div className="flex items-center gap-2 text-[#d0ff59]"><Activity className="w-5 h-5 animate-pulse" /><span className="text-sm">Scanning {TOP_10_COINS.length} coins...</span></div>}
      </div>

      {/* EQUITY CHART */}
      {chartData.length > 0 && (
        <div className="bg-[#0b0b0b] border border-[#222222] rounded-2xl p-6">
          <div className="flex items-center gap-2 mb-4">
            <BarChart3 className="w-5 h-5 text-[#d0ff59]" />
            <h3 className="text-lg font-semibold text-[#f6f6f6]">Equity Curve</h3>
          </div>
          <div className="h-[250px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorEquity" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#d0ff59" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#d0ff59" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#222222" />
                <XAxis 
                  dataKey="time" 
                  stroke="#444444" 
                  tick={{ fill: '#888888', fontSize: 10 }}
                  tickLine={false}
                />
                <YAxis 
                  domain={['auto', 'auto']}
                  stroke="#444444"
                  tick={{ fill: '#888888', fontSize: 10 }}
                  tickLine={false}
                  tickFormatter={(value) => `$${(value / 1000).toFixed(0)}K`}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0b0b0b',
                    border: '1px solid #222222',
                    borderRadius: '12px',
                  }}
                  labelStyle={{ color: '#888888' }}
                  itemStyle={{ color: '#d0ff59' }}
                  formatter={(value: number) => [`$${value.toLocaleString()}`, 'Equity']}
                />
                <Area
                  type="monotone"
                  dataKey="equity"
                  stroke="#d0ff59"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#colorEquity)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {/* PORTFOLIO CARDS - FIXED VALUES */}
      <div className="grid grid-cols-4 gap-4">
        <PortfolioCard 
          title="Balance" 
          value={`$${balance.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`} 
          subValue={`${totalReturn >= 0 ? '+' : ''}${totalReturn.toFixed(2)}%`} 
          positive={totalReturn >= 0} 
          icon={Wallet} 
        />
        <PortfolioCard 
          title="Equity" 
          value={`$${equity.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`} 
          subValue={`${totalUnrealizedPnl >= 0 ? '+' : ''}$${totalUnrealizedPnl.toFixed(2)}`} 
          positive={totalUnrealizedPnl >= 0} 
          icon={TrendingUp} 
        />
        <PortfolioCard 
          title="Available Margin" 
          value={`$${availableMargin.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`} 
          subValue={`$${totalUsedMargin.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} used`} 
          icon={Shield} 
        />
        <PortfolioCard 
          title="Positions" 
          value={positions.length.toString()} 
          subValue={`${TOP_10_COINS.length} coins tracked`} 
          icon={Target} 
        />
      </div>

      <div className="bg-[#0b0b0b] border border-[#222222] rounded-2xl p-6">
        <h3 className="text-sm font-medium text-[#888888] mb-4">Performance</h3>
        <div className="grid grid-cols-4 gap-6">
          <MetricItem label="Total Return" value={`${totalReturn >= 0 ? '+' : ''}${totalReturn.toFixed(2)}%`} positive={totalReturn >= 0} />
          <MetricItem label="Max Drawdown" value="-3.2%" negative />
          <MetricItem label="Win Rate" value={`${winRate.toFixed(1)}%`} neutral />
          <MetricItem label="Total Trades" value={trades.length.toString()} neutral />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-6">
        <div className="bg-[#0b0b0b] border border-[#222222] rounded-2xl p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-[#f6f6f6] flex items-center gap-2"><Target className="w-5 h-5 text-[#d0ff59]" />Open Positions</h3>
            <span className="text-sm text-[#888888]">{positions.length} active</span>
          </div>

          {positions.length === 0 ? (
            <div className="text-center py-8 text-[#888888]">
              <p>No open positions</p>
              <p className="text-sm mt-1">AI trades at 80%+ confidence</p>
            </div>
          ) : (
            <div className="space-y-3 max-h-[500px] overflow-y-auto">
              {positions.map((position) => {
                const marginUsed = (position.entryPrice * position.size) / (position.leverage || 10);
                const positionValue = position.entryPrice * position.size;
                
                return (
                  <div key={position.id} className="p-4 bg-[#1a1a1a] rounded-xl hover:bg-[#222222] transition-colors relative group">
                    <button onClick={() => manualClosePosition(position.id)} className="absolute top-2 right-2 p-1.5 bg-red-500/20 text-red-500 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity hover:bg-red-500/30"><X className="w-4 h-4" /></button>
                    
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2">
                        <span className={`px-2 py-0.5 rounded text-xs font-medium ${position.side === 'LONG' ? 'bg-[#d0ff59]/20 text-[#d0ff59]' : 'bg-red-500/20 text-red-500'}`}>{position.side}</span>
                        <span className="font-medium text-[#f6f6f6] text-sm">{position.symbol}</span>
                        {/* LEVERAGE DISPLAY */}
                        <span className="text-xs text-[#888888] bg-[#0b0b0b] px-2 py-0.5 rounded border border-[#333333]">
                          {position.leverage || 10}x
                        </span>
                      </div>
                      <div className={`flex items-center gap-1 text-sm font-medium ${position.pnl >= 0 ? 'text-[#d0ff59]' : 'text-red-500'}`}>
                        {position.pnl >= 0 ? <ArrowUpRight className="w-4 h-4" /> : <ArrowDownRight className="w-4 h-4" />}
                        ${Math.abs(position.pnl).toFixed(2)}
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-4 text-sm mb-3">
                      <div><p className="text-xs text-[#888888]">Entry</p><p className="text-[#cccccc]">${position.entryPrice.toLocaleString()}</p></div>
                      <div><p className="text-xs text-[#888888]">Current</p><p className="text-[#cccccc]">${position.currentPrice.toLocaleString()}</p></div>
                      <div><p className="text-xs text-[#888888]">Size</p><p className="text-[#cccccc]">{position.size.toFixed(4)}</p></div>
                    </div>

                    {/* UPDATED: Show Margin Used and Position Value */}
                    <div className="flex items-center gap-4 mb-3 p-2 bg-[#0b0b0b] rounded-lg">
                      <div>
                        <p className="text-xs text-[#888888]">Position Value</p>
                        <p className="text-sm font-bold text-[#d0ff59]">
                          ${positionValue.toLocaleString()}
                        </p>
                      </div>
                      <div className="w-px h-8 bg-[#333333]" />
                      <div>
                        <p className="text-xs text-[#888888]">Margin Used</p>
                        <p className="text-sm font-medium text-[#f6f6f6]">
                          ${marginUsed.toLocaleString()}
                        </p>
                      </div>
                      <div className="w-px h-8 bg-[#333333]" />
                      <div>
                        <p className="text-xs text-[#888888]">PnL %</p>
                        <p className={`text-sm font-medium ${position.pnlPercent >= 0 ? 'text-[#d0ff59]' : 'text-red-500'}`}>
                          {position.pnlPercent >= 0 ? '+' : ''}{position.pnlPercent.toFixed(2)}%
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-4 pt-3 border-t border-[#333333]">
                      {position.stopLoss && (
                        <div className="flex items-center gap-1 text-xs"><Shield className="w-3 h-3 text-red-500" /><span className="text-[#888888]">SL: ${position.stopLoss.toLocaleString()}</span></div>
                      )}
                      {position.takeProfit && (
                        <div className="flex items-center gap-1 text-xs"><Target className="w-3 h-3 text-[#d0ff59]" /><span className="text-[#888888]">TP: ${position.takeProfit.toLocaleString()}</span></div>
                      )}
                      <div className="flex items-center gap-1 text-xs ml-auto"><Clock className="w-3 h-3 text-[#888888]" /><span className="text-[#888888]">{formatRelativeTime(position.timestamp)}</span></div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* UPDATED TRADE HISTORY SECTION */}
        <div className="bg-[#0b0b0b] border border-[#222222] rounded-2xl p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <History className="w-5 h-5 text-[#d0ff59]" />
              <h3 className="text-lg font-semibold text-[#f6f6f6]">Trade History</h3>
            </div>
            <div className="flex items-center gap-3">
              <span className="text-xs px-2 py-1 bg-[#1a1a1a] rounded-full text-[#888888]">
                {tradeStats.totalTrades} total
              </span>
              {sortedTrades.length > 0 && (
                <button 
                  onClick={handleClearHistory}
                  className="flex items-center gap-1 text-xs text-red-400 hover:text-red-300 transition-colors px-2 py-1 rounded-lg hover:bg-red-500/10"
                >
                  <Trash2 className="w-3 h-3" />
                  Clear
                </button>
              )}
            </div>
          </div>

          {sortedTrades.length === 0 ? (
            <div className="text-center py-12 text-[#888888]">
              <div className="w-12 h-12 mx-auto mb-3 rounded-full bg-[#1a1a1a] flex items-center justify-center">
                <History className="w-6 h-6 text-[#444444]" />
              </div>
              <p className="text-sm font-medium">No trades yet</p>
              <p className="text-xs mt-1 text-[#666666]">Completed trades appear here</p>
            </div>
          ) : (
            <div className="space-y-2 max-h-[500px] overflow-y-auto pr-1 scrollbar-thin scrollbar-thumb-[#333333] scrollbar-track-transparent">
              {sortedTrades.map((trade, index) => {
                const isProfit = (trade.pnl || 0) >= 0;
                const tradeDate = new Date(trade.timestamp);
                const isToday = new Date().toDateString() === tradeDate.toDateString();
                const isBuySide = trade.side === 'BUY';
                
                return (
                  <div 
                    key={trade.id} 
                    className={`group flex items-center justify-between p-3 bg-[#1a1a1a] hover:bg-[#222222] rounded-xl transition-all duration-200 border border-transparent hover:border-[#333333] ${index === 0 ? 'ring-1 ring-[#d0ff59]/20' : ''}`}
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center transition-colors ${
                        isProfit ? 'bg-[#d0ff59]/10 group-hover:bg-[#d0ff59]/20' : 'bg-red-500/10 group-hover:bg-red-500/20'
                      }`}>
                        {isProfit ? 
                          <TrendingUp className="w-5 h-5 text-[#d0ff59]" /> : 
                          <TrendingDown className="w-5 h-5 text-red-500" />
                        }
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <p className="font-semibold text-[#f6f6f6] text-sm">{trade.symbol}</p>
                          <span className={`text-[10px] px-1.5 py-0.5 rounded font-medium ${
                            isBuySide ? 'bg-[#d0ff59]/20 text-[#d0ff59]' : 'bg-red-500/20 text-red-400'
                          }`}>
                            {trade.side}
                          </span>
                          {trade.leverage && (
                            <span className="text-[10px] text-[#888888] bg-[#0b0b0b] px-1.5 py-0.5 rounded">
                              {trade.leverage}x
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-[#888888] mt-0.5">
                          @{trade.price.toLocaleString()} 
                          {trade.size && ` • ${trade.size.toFixed(4)} units`}
                          {trade.pnlPercent && (
                            <span className={`ml-1 font-medium ${trade.pnlPercent >= 0 ? 'text-[#d0ff59]' : 'text-red-400'}`}>
                              ({trade.pnlPercent >= 0 ? '+' : ''}{trade.pnlPercent.toFixed(2)}%)
                            </span>
                          )}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      {trade.pnl !== undefined && (
                        <p className={`font-bold text-sm ${trade.pnl >= 0 ? 'text-[#d0ff59]' : 'text-red-500'}`}>
                          {trade.pnl >= 0 ? '+' : ''}${trade.pnl.toFixed(2)}
                        </p>
                      )}
                      <p className="text-[10px] text-[#666666] mt-0.5">
                        {isToday ? 'Today' : formatTradeTime(trade.timestamp)}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
          
          {/* Trade Statistics Summary */}
          {sortedTrades.length > 0 && (
            <div className="mt-4 pt-4 border-t border-[#222222] grid grid-cols-3 gap-3">
              <div className="text-center p-2 bg-[#1a1a1a] rounded-lg">
                <p className="text-[10px] text-[#888888] uppercase tracking-wider">Win Rate</p>
                <p className={`text-sm font-bold ${tradeStats.winRate >= 50 ? 'text-[#d0ff59]' : 'text-red-500'}`}>
                  {tradeStats.winRate.toFixed(1)}%
                </p>
              </div>
              <div className="text-center p-2 bg-[#1a1a1a] rounded-lg">
                <p className="text-[10px] text-[#888888] uppercase tracking-wider">Total P&L</p>
                <p className={`text-sm font-bold ${tradeStats.totalPnl >= 0 ? 'text-[#d0ff59]' : 'text-red-500'}`}>
                  {tradeStats.totalPnl >= 0 ? '+' : ''}${tradeStats.totalPnl.toFixed(2)}
                </p>
              </div>
              <div className="text-center p-2 bg-[#1a1a1a] rounded-lg">
                <p className="text-[10px] text-[#888888] uppercase tracking-wider">Avg P&L</p>
                <p className={`text-sm font-bold ${tradeStats.avgPnl >= 0 ? 'text-[#d0ff59]' : 'text-red-500'}`}>
                  {tradeStats.avgPnl >= 0 ? '+' : ''}${tradeStats.avgPnl.toFixed(2)}
                </p>
              </div>
            </div>
          )}
        </div>
      </div>

      {signalHistory.length > 0 && (
        <div className="bg-[#0b0b0b] border border-[#222222] rounded-2xl p-6">
          <h3 className="text-lg font-semibold text-[#f6f6f6] mb-4 flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-[#d0ff59]" />
            Signal History (80%+ Only)
          </h3>
          <div className="grid grid-cols-3 gap-3">
            {signalHistory.slice(0, 9).map((sig, idx) => (
              <div key={idx} className="p-3 bg-[#1a1a1a] rounded-lg border border-[#333333]">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-[#f6f6f6]">{formatSymbol(sig.symbol)}</span>
                  <span className={`text-xs px-2 py-0.5 rounded ${
                    sig.type === 'BUY' ? 'bg-[#d0ff59]/20 text-[#d0ff59]' : 
                    sig.type === 'SELL' ? 'bg-red-500/20 text-red-500' : 
                    'bg-yellow-500/20 text-yellow-500'
                  }`}>{sig.type}</span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className={sig.confidence >= 80 ? 'text-[#d0ff59]' : 'text-[#888888]'}>{sig.confidence.toFixed(1)}%</span>
                  <span className={sig.executed ? 'text-[#d0ff59]' : 'text-[#888888]'}>
                    {sig.executed ? '✓ Executed' : 'Skipped'}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

interface PortfolioCardProps {
  title: string;
  value: string;
  subValue: string;
  positive?: boolean;
  icon: React.ElementType;
}

function PortfolioCard({ title, value, subValue, positive, icon: Icon }: PortfolioCardProps) {
  return (
    <div className="bg-[#0b0b0b] border border-[#222222] rounded-xl p-4">
      <div className="flex items-center justify-between mb-2">
        <span className="text-xs text-[#888888]">{title}</span>
        <Icon className="w-4 h-4 text-[#d0ff59]" />
      </div>
      <p className="text-xl font-bold text-[#f6f6f6]">{value}</p>
      <p className={`text-xs mt-1 ${positive === true ? 'text-[#d0ff59]' : positive === false ? 'text-red-500' : 'text-[#888888]'}`}>{subValue}</p>
    </div>
  );
}

interface MetricItemProps {
  label: string;
  value: string;
  positive?: boolean;
  negative?: boolean;
  neutral?: boolean;
}

function MetricItem({ label, value, positive, negative, neutral }: MetricItemProps) {
  return (
    <div>
      <p className="text-xs text-[#888888] mb-1">{label}</p>
      <p className={`text-lg font-bold ${positive ? 'text-[#d0ff59]' : negative ? 'text-red-500' : neutral ? 'text-[#f6f6f6]' : ''}`}>{value}</p>
    </div>
  );
}

export default DemoTrading;
