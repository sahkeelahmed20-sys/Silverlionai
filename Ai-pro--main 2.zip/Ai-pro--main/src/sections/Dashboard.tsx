import React, { useEffect, useState } from 'react';
import { TrendingUp, Activity, DollarSign, BarChart3 } from 'lucide-react';
import { binanceWS } from '../services/binanceWebSocket';
import type { PriceData } from '../services/binanceWebSocket';

const Dashboard: React.FC = () => {
  const [prices, setPrices] = useState<Map<string, PriceData>>(new Map());
  const [isConnected, setIsConnected] = useState(false);

  useEffect(() => {
    const unsubscribe = binanceWS.subscribeToMap((newPrices) => setPrices(new Map(newPrices)));
    binanceWS.connect(['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'BNBUSDT']);
    setIsConnected(binanceWS.getStatus());
    const interval = setInterval(() => setIsConnected(binanceWS.getStatus()), 1000);
    return () => { unsubscribe(); clearInterval(interval); };
  }, []);

  const stats = [
    { label: 'Portfolio Value', value: '$101,250.50', change: '+12.5%', icon: DollarSign },
    { label: '24h Change', value: '+$1,250.50', change: '+5.2%', icon: TrendingUp },
    { label: 'Active Positions', value: '3', change: '2 long, 1 short', icon: Activity },
    { label: 'Win Rate', value: '68.5%', change: 'Last 30 days', icon: BarChart3 },
  ];

  return (
    <div className="space-y-6 p-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-white">Dashboard</h1>
          <p className="text-[#888888] mt-1">Welcome back to your trading dashboard</p>
        </div>
        <div className={`flex items-center gap-2 px-4 py-2 rounded-lg border ${isConnected ? 'border-green-500/30 bg-green-500/10 text-green-500' : 'border-red-500/30 bg-red-500/10 text-red-500'}`}>
          <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-green-500 animate-pulse' : 'bg-red-500'}`} />
          <span className="text-sm font-medium">{isConnected ? 'Connected' : 'Disconnected'}</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, idx) => (
          <div key={idx} className="bg-[#1a1a1a] border border-[#333333] rounded-xl p-6">
            <div className="flex items-center justify-between mb-4">
              <stat.icon className="w-8 h-8 text-[#e8ff47]" />
              <span className="text-xs text-[#e8ff47] bg-[#e8ff47]/10 px-2 py-1 rounded-full">{stat.change}</span>
            </div>
            <h3 className="text-[#888888] text-sm">{stat.label}</h3>
            <p className="text-2xl font-bold text-white mt-1">{stat.value}</p>
          </div>
        ))}
      </div>

      <div className="bg-[#1a1a1a] border border-[#333333] rounded-xl p-6">
        <h2 className="text-lg font-semibold text-white mb-4">Live Market Prices</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {Array.from(prices.values()).map((price) => (
            <div key={price.symbol} className="bg-[#0f0f0f] rounded-lg p-4 border border-[#333333]">
              <div className="flex justify-between items-start mb-2">
                <span className="text-white font-medium">{price.symbol.replace('USDT', '')}</span>
                <span className={`text-xs px-2 py-1 rounded ${price.change24h >= 0 ? 'bg-green-500/20 text-green-500' : 'bg-red-500/20 text-red-500'}`}>
                  {price.change24h >= 0 ? '+' : ''}{price.change24h.toFixed(2)}%
                </span>
              </div>
              <p className="text-xl font-bold text-white">${price.price.toLocaleString(undefined, {maximumFractionDigits: 2})}</p>
              <p className="text-xs text-[#555555] mt-1">Vol: ${(price.volume / 1e6).toFixed(2)}M</p>
            </div>
          ))}
          {prices.size === 0 && <div className="col-span-full text-center py-8 text-[#888888]"><div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#e8ff47] mx-auto mb-2"></div>Loading prices...</div>}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
