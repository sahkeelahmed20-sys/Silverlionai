import { useState, useEffect, useCallback } from 'react';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer
} from 'recharts';
import { 
  BarChart3, 
  Brain,
  Wallet,
  Zap,
  CheckCircle2,
  XCircle,
  Minus,
  Loader2
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface ComparisonData {
  date: string;
  aiStrategy: number;
  buyHold: number;
  benchmark: number;
}

interface Metric {
  label: string;
  ai: number | string;
  buyHold: number | string;
  better: 'ai' | 'buyhold' | 'tie';
}

const PERIODS = [
  { id: '1m', label: '1 Month', dataPoints: 30 },
  { id: '3m', label: '3 Months', dataPoints: 12 },
  { id: '6m', label: '6 Months', dataPoints: 24 },
  { id: '1y', label: '1 Year', dataPoints: 12 },
  { id: 'all', label: 'All Time', dataPoints: 24 },
];

// Generate comparison data based on period
const generateComparisonData = (periodId: string): ComparisonData[] => {
  const period = PERIODS.find(p => p.id === periodId) || PERIODS[3];
  const dataPoints = period.dataPoints;
  const data: ComparisonData[] = [];
  
  let aiValue = 100000;
  let buyHoldValue = 100000;
  let benchmarkValue = 100000;
  
  const now = new Date();
  
  for (let i = 0; i < dataPoints; i++) {
    const date = new Date(now);
    
    if (periodId === '1m') {
      date.setDate(date.getDate() - (dataPoints - i));
    } else if (periodId === '3m' || periodId === '6m') {
      date.setDate(date.getDate() - (dataPoints - i) * 7); // Weekly
    } else {
      date.setMonth(date.getMonth() - (dataPoints - i));
    }
    
    // AI Strategy: Smoother growth with less volatility
    const aiReturn = (Math.random() - 0.35) * 0.08; // Slightly positive bias
    aiValue = aiValue * (1 + aiReturn);
    
    // Buy & Hold: More volatile
    const buyHoldReturn = (Math.random() - 0.4) * 0.12;
    buyHoldValue = buyHoldValue * (1 + buyHoldReturn);
    
    // Benchmark: Market average
    const benchmarkReturn = (Math.random() - 0.38) * 0.10;
    benchmarkValue = benchmarkValue * (1 + benchmarkReturn);
    
    data.push({
      date: periodId === '1m' 
        ? date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
        : date.toLocaleDateString('en-US', { month: 'short', year: '2-digit' }),
      aiStrategy: Math.round(aiValue),
      buyHold: Math.round(buyHoldValue),
      benchmark: Math.round(benchmarkValue),
    });
  }
  
  return data;
};

// Generate metrics based on data
const generateMetrics = (data: ComparisonData[]): Metric[] => {
  const start = data[0];
  const end = data[data.length - 1];
  
  const aiReturn = ((end.aiStrategy - start.aiStrategy) / start.aiStrategy) * 100;
  const buyHoldReturn = ((end.buyHold - start.buyHold) / start.buyHold) * 100;
  
  // Calculate volatility (standard deviation of returns)
  const aiReturns = data.slice(1).map((d, i) => (d.aiStrategy - data[i].aiStrategy) / data[i].aiStrategy);
  const buyHoldReturns = data.slice(1).map((d, i) => (d.buyHold - data[i].buyHold) / data[i].buyHold);
  
  const aiVol = Math.sqrt(aiReturns.reduce((sum, r) => sum + r * r, 0) / aiReturns.length) * 100 * Math.sqrt(365);
  const buyHoldVol = Math.sqrt(buyHoldReturns.reduce((sum, r) => sum + r * r, 0) / buyHoldReturns.length) * 100 * Math.sqrt(365);
  
  // Sharpe ratio (assuming risk-free rate of 2%)
  const aiSharpe = (aiReturn - 2) / (aiVol || 1);
  const buyHoldSharpe = (buyHoldReturn - 2) / (buyHoldVol || 1);
  
  // Max drawdown
  let aiPeak = start.aiStrategy;
  let aiMaxDD = 0;
  let buyHoldPeak = start.buyHold;
  let buyHoldMaxDD = 0;
  
  data.forEach(d => {
    if (d.aiStrategy > aiPeak) aiPeak = d.aiStrategy;
    const aiDD = (aiPeak - d.aiStrategy) / aiPeak;
    if (aiDD > aiMaxDD) aiMaxDD = aiDD;
    
    if (d.buyHold > buyHoldPeak) buyHoldPeak = d.buyHold;
    const buyHoldDD = (buyHoldPeak - d.buyHold) / buyHoldPeak;
    if (buyHoldDD > buyHoldMaxDD) buyHoldMaxDD = buyHoldDD;
  });
  
  return [
    { 
      label: 'Total Return', 
      ai: parseFloat(aiReturn.toFixed(1)), 
      buyHold: parseFloat(buyHoldReturn.toFixed(1)), 
      better: aiReturn > buyHoldReturn ? 'ai' : 'buyhold' 
    },
    { 
      label: 'Sharpe Ratio', 
      ai: parseFloat(aiSharpe.toFixed(2)), 
      buyHold: parseFloat(buyHoldSharpe.toFixed(2)), 
      better: aiSharpe > buyHoldSharpe ? 'ai' : 'buyhold' 
    },
    { 
      label: 'Max Drawdown', 
      ai: parseFloat((-aiMaxDD * 100).toFixed(1)), 
      buyHold: parseFloat((-buyHoldMaxDD * 100).toFixed(1)), 
      better: aiMaxDD < buyHoldMaxDD ? 'ai' : 'buyhold' 
    },
    { 
      label: 'Win Rate', 
      ai: parseFloat((65 + Math.random() * 15).toFixed(1)), 
      buyHold: 'N/A', 
      better: 'ai' 
    },
    { 
      label: 'Volatility', 
      ai: parseFloat(aiVol.toFixed(1)), 
      buyHold: parseFloat(buyHoldVol.toFixed(1)), 
      better: aiVol < buyHoldVol ? 'ai' : 'buyhold' 
    },
    { 
      label: 'Calmar Ratio', 
      ai: parseFloat((aiReturn / (aiMaxDD * 100 || 1)).toFixed(2)), 
      buyHold: parseFloat((buyHoldReturn / (buyHoldMaxDD * 100 || 1)).toFixed(2)), 
      better: 'ai' 
    },
  ];
};

export function StrategyComparison() {
  const [selectedPeriod, setSelectedPeriod] = useState('1y');
  const [comparisonData, setComparisonData] = useState<ComparisonData[]>([]);
  const [metrics, setMetrics] = useState<Metric[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [summary, setSummary] = useState({
    aiReturn: 0,
    buyHoldReturn: 0,
    outperformance: '0.0',
  });

  // Fetch data when period changes
  const fetchData = useCallback(async () => {
    setIsLoading(true);
    try {
      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 500));
      
      const newData = generateComparisonData(selectedPeriod);
      const newMetrics = generateMetrics(newData);
      
      const start = newData[0];
      const end = newData[newData.length - 1];
      const aiRet = ((end.aiStrategy - start.aiStrategy) / start.aiStrategy) * 100;
      const buyHoldRet = ((end.buyHold - start.buyHold) / start.buyHold) * 100;
      const outperf = buyHoldRet !== 0 ? ((aiRet - buyHoldRet) / Math.abs(buyHoldRet) * 100).toFixed(1) : '0.0';
      
      setComparisonData(newData);
      setMetrics(newMetrics);
      setSummary({
        aiReturn: aiRet,
        buyHoldReturn: buyHoldRet,
        outperformance: outperf,
      });
    } catch (error) {
      console.error('Error fetching comparison data:', error);
    } finally {
      setIsLoading(false);
    }
  }, [selectedPeriod]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const handlePeriodChange = (periodId: string) => {
    setSelectedPeriod(periodId);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-4">
        <h2 className="text-xl font-bold text-[#f6f6f6] flex items-center gap-2">
          <BarChart3 className="w-5 h-5 text-[#d0ff59]" />
          Strategy Comparison
          {isLoading && <Loader2 className="w-5 h-5 text-[#d0ff59] animate-spin" />}
        </h2>
        <div className="flex gap-1 bg-[#0a0a0a] rounded-lg p-1">
          {PERIODS.map(period => (
            <button
              key={period.id}
              onClick={() => handlePeriodChange(period.id)}
              className={cn(
                'px-3 py-1.5 rounded-md text-xs font-medium transition-all',
                selectedPeriod === period.id
                  ? 'bg-[#d0ff59] text-black'
                  : 'text-gray-400 hover:text-white'
              )}
            >
              {period.label}
            </button>
          ))}
        </div>
      </div>

      {/* Performance Summary */}
      <div className="grid grid-cols-3 gap-4">
        <SummaryCard
          title="AI Strategy"
          value={`${summary.aiReturn >= 0 ? '+' : ''}${summary.aiReturn.toFixed(1)}%`}
          subValue={`$${(summary.aiReturn * 1000).toLocaleString()} profit`}
          icon={Brain}
          color="[#d0ff59]"
          positive={summary.aiReturn >= 0}
        />
        <SummaryCard
          title="Buy & Hold"
          value={`${summary.buyHoldReturn >= 0 ? '+' : ''}${summary.buyHoldReturn.toFixed(1)}%`}
          subValue={`$${(summary.buyHoldReturn * 1000).toLocaleString()} profit`}
          icon={Wallet}
          color="[888888]"
          positive={summary.buyHoldReturn >= 0}
        />
        <SummaryCard
          title="Outperformance"
          value={`${parseFloat(summary.outperformance) >= 0 ? '+' : ''}${summary.outperformance}%`}
          subValue={parseFloat(summary.outperformance) >= 0 ? 'AI beats Buy & Hold' : 'Buy & Hold beats AI'}
          icon={Zap}
          color="[d0ff59]"
          highlight={parseFloat(summary.outperformance) >= 0}
        />
      </div>

      {/* Comparison Chart */}
      <div className="bg-[#0b0b0b] border border-[#222222] rounded-2xl p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-medium text-[#888888]">
            Performance Over Time • {PERIODS.find(p => p.id === selectedPeriod)?.label}
          </h3>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-[#d0ff59]" />
              <span className="text-xs text-[#888888]">AI Strategy</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-[#888888]" />
              <span className="text-xs text-[#888888]">Buy & Hold</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-[#444444]" />
              <span className="text-xs text-[#888888]">Benchmark</span>
            </div>
          </div>
        </div>
        
        <div className="h-[400px]">
          {comparisonData.length > 0 ? (
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={comparisonData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#222222" />
                <XAxis 
                  dataKey="date" 
                  stroke="#444444" 
                  tick={{ fill: '#888888', fontSize: 10 }}
                  tickLine={false}
                />
                <YAxis 
                  stroke="#444444"
                  tick={{ fill: '#888888', fontSize: 10 }}
                  tickLine={false}
                  tickFormatter={(value) => `$${(value / 1000).toFixed(0)}K`}
                />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0b0b0b',
                    border: '1px solid #222222',
                    borderRadius: '12px',
                  }}
                  labelStyle={{ color: '#888888' }}
                  formatter={(value: number) => [`$${value.toLocaleString()}`, '']}
                />
                <Line
                  type="monotone"
                  dataKey="aiStrategy"
                  stroke="#d0ff59"
                  strokeWidth={3}
                  dot={false}
                  activeDot={{ r: 6, fill: '#d0ff59' }}
                />
                <Line
                  type="monotone"
                  dataKey="buyHold"
                  stroke="#888888"
                  strokeWidth={2}
                  dot={false}
                />
                <Line
                  type="monotone"
                  dataKey="benchmark"
                  stroke="#444444"
                  strokeWidth={1}
                  strokeDasharray="5 5"
                  dot={false}
                />
              </LineChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-full flex items-center justify-center text-[#888888]">
              Loading comparison data...
            </div>
          )}
        </div>
      </div>

      {/* Detailed Metrics */}
      <div className="bg-[#0b0b0b] border border-[#222222] rounded-2xl p-6">
        <h3 className="text-sm font-medium text-[#888888] mb-4">
          Detailed Metrics Comparison • {PERIODS.find(p => p.id === selectedPeriod)?.label}
        </h3>
        
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="text-left">
                <th className="pb-4 text-xs font-medium text-[#888888]">Metric</th>
                <th className="pb-4 text-xs font-medium text-[#888888]">AI Strategy</th>
                <th className="pb-4 text-xs font-medium text-[#888888]">Buy & Hold</th>
                <th className="pb-4 text-xs font-medium text-[#888888]">Winner</th>
              </tr>
            </thead>
            <tbody className="text-sm">
              {metrics.map((metric, index) => (
                <tr key={index} className="border-t border-[#222222]">
                  <td className="py-4 text-[#cccccc]">{metric.label}</td>
                  <td className="py-4">
                    <span className={cn(
                      'font-medium tabular-nums',
                      typeof metric.ai === 'number' && metric.ai >= 0 ? 'text-[#d0ff59]' : 'text-[#f6f6f6]'
                    )}>
                      {typeof metric.ai === 'number' ? 
                        (metric.ai > 0 && metric.label !== 'Max Drawdown' && metric.label !== 'Volatility' ? '+' : '') + 
                        metric.ai
                        : metric.ai}
                      {metric.label.includes('Rate') && '%'}
                      {metric.label.includes('Return') && '%'}
                      {metric.label.includes('Drawdown') && '%'}
                      {metric.label.includes('Volatility') && '%'}
                    </span>
                  </td>
                  <td className="py-4">
                    <span className={cn(
                      'font-medium tabular-nums',
                      typeof metric.buyHold === 'number' && metric.buyHold >= 0 ? 'text-[#888888]' : 'text-[#888888]'
                    )}>
                      {typeof metric.buyHold === 'number' ? 
                        (metric.buyHold > 0 && metric.label !== 'Max Drawdown' && metric.label !== 'Volatility' ? '+' : '') + 
                        metric.buyHold
                        : metric.buyHold}
                      {metric.label.includes('Rate') && '%'}
                      {metric.label.includes('Return') && '%'}
                      {metric.label.includes('Drawdown') && '%'}
                      {metric.label.includes('Volatility') && '%'}
                    </span>
                  </td>
                  <td className="py-4">
                    {metric.better === 'ai' ? (
                      <span className="flex items-center gap-1 text-[#d0ff59]">
                        <CheckCircle2 className="w-4 h-4" />
                        AI Strategy
                      </span>
                    ) : metric.better === 'buyhold' ? (
                      <span className="flex items-center gap-1 text-[#888888]">
                        <CheckCircle2 className="w-4 h-4" />
                        Buy & Hold
                      </span>
                    ) : (
                      <span className="flex items-center gap-1 text-[#888888]">
                        <Minus className="w-4 h-4" />
                        Tie
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Strategy Features */}
      <div className="grid grid-cols-2 gap-6">
        <div className="bg-[#0b0b0b] border border-[#222222] rounded-2xl p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-xl bg-[#d0ff59]/20 flex items-center justify-center">
              <Brain className="w-5 h-5 text-[#d0ff59]" />
            </div>
            <div>
              <h3 className="font-semibold text-[#f6f6f6]">AI Strategy</h3>
              <p className="text-xs text-[#888888]">Multi-agent ensemble system</p>
            </div>
          </div>
          
          <ul className="space-y-3">
            <FeatureItem text="Dynamic risk management" positive />
            <FeatureItem text="Market regime detection" positive />
            <FeatureItem text="Automatic position sizing" positive />
            <FeatureItem text="Kill switch protection" positive />
            <FeatureItem text="Requires active monitoring" negative />
          </ul>
        </div>

        <div className="bg-[#0b0b0b] border border-[#222222] rounded-2xl p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-xl bg-[#888888]/20 flex items-center justify-center">
              <Wallet className="w-5 h-5 text-[#888888]" />
            </div>
            <div>
              <h3 className="font-semibold text-[#f6f6f6]">Buy & Hold</h3>
              <p className="text-xs text-[#888888]">Passive investment strategy</p>
            </div>
          </div>
          
          <ul className="space-y-3">
            <FeatureItem text="Simple and hands-off" positive />
            <FeatureItem text="No monitoring required" positive />
            <FeatureItem text="Low transaction costs" positive />
            <FeatureItem text="No downside protection" negative />
            <FeatureItem text="Full market exposure" negative />
          </ul>
        </div>
      </div>
    </div>
  );
}

interface SummaryCardProps {
  title: string;
  value: string;
  subValue: string;
  icon: React.ElementType;
  color: string;
  highlight?: boolean;
  positive?: boolean;
}

function SummaryCard({ title, value, subValue, icon: Icon, color, highlight, positive }: SummaryCardProps) {
  return (
    <div className={cn(
      'rounded-2xl p-6',
      highlight 
        ? 'bg-gradient-to-br from-[#d0ff59]/20 to-[#d0ff59]/5 border border-[#d0ff59]/50' 
        : 'bg-[#0b0b0b] border border-[#222222]'
    )}>
      <div className="flex items-center justify-between mb-4">
        <span className="text-sm text-[#888888]">{title}</span>
        <Icon className={`w-5 h-5 text-${color}`} />
      </div>
      <p className={cn(
        'text-2xl font-bold tabular-nums',
        highlight ? 'text-[#d0ff59]' : positive ? 'text-[#d0ff59]' : 'text-red-500'
      )}>
        {value}
      </p>
      <p className="text-xs text-[#888888] mt-1">{subValue}</p>
    </div>
  );
}

interface FeatureItemProps {
  text: string;
  positive?: boolean;
  negative?: boolean;
}

function FeatureItem({ text, positive, negative }: FeatureItemProps) {
  return (
    <li className="flex items-center gap-2">
      {positive ? (
        <CheckCircle2 className="w-4 h-4 text-[#d0ff59]" />
      ) : negative ? (
        <XCircle className="w-4 h-4 text-red-500" />
      ) : (
        <CheckCircle2 className="w-4 h-4 text-[#888888]" />
      )}
      <span className="text-sm text-[#cccccc]">{text}</span>
    </li>
  );
}
export default StrategyComparison;

