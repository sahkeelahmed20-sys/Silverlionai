import React, { useState } from 'react';
import { Play, Pause, Settings, TrendingUp, Activity, Shield } from 'lucide-react';

interface Strategy {
  id: string;
  name: string;
  description: string;
  type: 'Trend Following' | 'Mean Reversion' | 'Breakout';
  status: 'Active' | 'Paused';
  winRate: number;
  profitFactor: number;
  totalTrades: number;
}

const Strategies: React.FC = () => {
  const [strategies, setStrategies] = useState<Strategy[]>([
    {
      id: '1',
      name: 'Momentum Strategy',
      description: 'Trend following using moving averages and RSI',
      type: 'Trend Following',
      status: 'Active',
      winRate: 62.5,
      profitFactor: 1.85,
      totalTrades: 156
    },
    {
      id: '2',
      name: 'Mean Reversion',
      description: 'RSI-based oversold/overbought entries',
      type: 'Mean Reversion',
      status: 'Active',
      winRate: 58.2,
      profitFactor: 1.62,
      totalTrades: 89
    },
    {
      id: '3',
      name: 'Breakout Hunter',
      description: 'Volatility breakout with volume confirmation',
      type: 'Breakout',
      status: 'Paused',
      winRate: 55.8,
      profitFactor: 1.45,
      totalTrades: 67
    }
  ]);

  const toggleStrategy = (id: string) => {
    setStrategies(prev => prev.map(s => 
      s.id === id ? { ...s, status: s.status === 'Active' ? 'Paused' : 'Active' } : s
    ));
  };

  return (
    <div className="space-y-6 p-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-white">Trading Strategies</h1>
          <p className="text-[#888888] mt-1">Manage and monitor your AI strategies</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 bg-[#e8ff47] text-black rounded-lg font-medium hover:bg-[#d4eb3f] transition-all">
          <Settings className="w-4 h-4" />
          Configure All
        </button>
      </div>

      <div className="grid gap-4">
        {strategies.map((strategy) => (
          <div key={strategy.id} className="bg-[#1a1a1a] border border-[#333333] rounded-xl p-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="flex items-start gap-4">
                <div className={`p-3 rounded-lg ${
                  strategy.type === 'Trend Following' ? 'bg-blue-500/20 text-blue-500' :
                  strategy.type === 'Mean Reversion' ? 'bg-purple-500/20 text-purple-500' :
                  'bg-orange-500/20 text-orange-500'
                }`}>
                  {strategy.type === 'Trend Following' && <TrendingUp className="w-6 h-6" />}
                  {strategy.type === 'Mean Reversion' && <Activity className="w-6 h-6" />}
                  {strategy.type === 'Breakout' && <Shield className="w-6 h-6" />}
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-white">{strategy.name}</h3>
                  <p className="text-[#888888] text-sm">{strategy.description}</p>
                  <span className="inline-block mt-2 text-xs px-2 py-1 rounded bg-[#333333] text-[#888888]">
                    {strategy.type}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-6">
                <div className="grid grid-cols-3 gap-4 text-center">
                  <div>
                    <p className="text-lg font-bold text-white">{strategy.winRate}%</p>
                    <p className="text-xs text-[#888888]">Win Rate</p>
                  </div>
                  <div>
                    <p className="text-lg font-bold text-white">{strategy.profitFactor}</p>
                    <p className="text-xs text-[#888888]">Profit Factor</p>
                  </div>
                  <div>
                    <p className="text-lg font-bold text-white">{strategy.totalTrades}</p>
                    <p className="text-xs text-[#888888]">Trades</p>
                  </div>
                </div>

                <button
                  onClick={() => toggleStrategy(strategy.id)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all ${
                    strategy.status === 'Active'
                      ? 'bg-green-500/20 text-green-500 hover:bg-green-500/30'
                      : 'bg-[#333333] text-[#888888] hover:bg-[#444444]'
                  }`}
                >
                  {strategy.status === 'Active' ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                  {strategy.status}
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Strategies;
