import React, { useState, useEffect } from 'react';
import { Network, Globe, Server, Activity } from 'lucide-react';

interface Node {
  id: string;
  location: string;
  latency: number;
  status: 'online' | 'offline';
  version: string;
}

const Bitnodes: React.FC = () => {
  const [nodes, setNodes] = useState<Node[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setTimeout(() => {
      setNodes([
        { id: '1', location: 'US East', latency: 23, status: 'online', version: '27.0' },
        { id: '2', location: 'US West', latency: 45, status: 'online', version: '27.0' },
        { id: '3', location: 'Europe', latency: 67, status: 'online', version: '26.99' },
        { id: '4', location: 'Asia', latency: 89, status: 'offline', version: '27.0' },
        { id: '5', location: 'Australia', latency: 112, status: 'online', version: '27.0' },
      ]);
      setLoading(false);
    }, 1000);
  }, []);

  const onlineCount = nodes.filter(n => n.status === 'online').length;

  return (
    <div className="space-y-6 p-6">
      <div>
        <h1 className="text-2xl font-bold text-white">Bitnodes Network</h1>
        <p className="text-[#888888] mt-1">Bitcoin network node monitoring</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-[#1a1a1a] border border-[#333333] rounded-xl p-4">
          <div className="flex items-center gap-2 text-[#888888] mb-2">
            <Network className="w-4 h-4" />
            <span className="text-sm">Total Nodes</span>
          </div>
          <p className="text-2xl font-bold text-white">{nodes.length}</p>
        </div>
        <div className="bg-[#1a1a1a] border border-[#333333] rounded-xl p-4">
          <div className="flex items-center gap-2 text-[#888888] mb-2">
            <Activity className="w-4 h-4" />
            <span className="text-sm">Online</span>
          </div>
          <p className="text-2xl font-bold text-green-500">{onlineCount}</p>
        </div>
        <div className="bg-[#1a1a1a] border border-[#333333] rounded-xl p-4">
          <div className="flex items-center gap-2 text-[#888888] mb-2">
            <Globe className="w-4 h-4" />
            <span className="text-sm">Regions</span>
          </div>
          <p className="text-2xl font-bold text-white">5</p>
        </div>
        <div className="bg-[#1a1a1a] border border-[#333333] rounded-xl p-4">
          <div className="flex items-center gap-2 text-[#888888] mb-2">
            <Server className="w-4 h-4" />
            <span className="text-sm">Avg Latency</span>
          </div>
          <p className="text-2xl font-bold text-white">
            {nodes.length > 0 ? Math.round(nodes.reduce((a, b) => a + b.latency, 0) / nodes.length) : 0}ms
          </p>
        </div>
      </div>

      <div className="bg-[#1a1a1a] border border-[#333333] rounded-xl overflow-hidden">
        <table className="w-full">
          <thead className="bg-[#0f0f0f] border-b border-[#333333]">
            <tr>
              <th className="text-left py-4 px-6 text-[#888888] text-sm font-medium">Location</th>
              <th className="text-left py-4 px-6 text-[#888888] text-sm font-medium">Status</th>
              <th className="text-left py-4 px-6 text-[#888888] text-sm font-medium">Latency</th>
              <th className="text-left py-4 px-6 text-[#888888] text-sm font-medium">Version</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr>
                <td colSpan={4} className="text-center py-8 text-[#888888]">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#e8ff47] mx-auto"></div>
                </td>
              </tr>
            ) : (
              nodes.map((node) => (
                <tr key={node.id} className="border-b border-[#222222] hover:bg-[#0f0f0f]">
                  <td className="py-4 px-6 text-white">{node.location}</td>
                  <td className="py-4 px-6">
                    <span className={`inline-flex items-center gap-2 px-2 py-1 rounded-full text-xs ${
                      node.status === 'online' ? 'bg-green-500/20 text-green-500' : 'bg-red-500/20 text-red-500'
                    }`}>
                      <div className={`w-2 h-2 rounded-full ${node.status === 'online' ? 'bg-green-500' : 'bg-red-500'}`} />
                      {node.status}
                    </span>
                  </td>
                  <td className="py-4 px-6 text-white">{node.latency}ms</td>
                  <td className="py-4 px-6 text-[#888888]">{node.version}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Bitnodes;
