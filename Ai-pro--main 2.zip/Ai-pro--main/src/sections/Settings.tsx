import React, { useState, useEffect } from 'react';
import { 
  Wallet, 
  Save, 
  RotateCcw, 
  TrendingUp, 
  Shield, 
  Bell, 
  Moon, 
  User,
  DollarSign,
  BarChart3,
  Percent,
  Zap
} from 'lucide-react';
import { cn } from '../lib/utils';

interface SettingsProps {
  currentBalance: number;
  onBalanceChange: (balance: number) => void;
}

const PRESETS = [
  { label: '$10K', value: 10000 },
  { label: '$50K', value: 50000 },
  { label: '$100K', value: 100000 },
  { label: '$500K', value: 500000 },
  { label: '$1M', value: 1000000 },
];

// Storage keys (must match useDemoTrading)
const BALANCE_KEY = 'demoStartingBalance';
const TRADE_SETTINGS_KEY = 'tradeSettings';

// Trade settings interface matching DemoTrading expectations
interface TradeSettings {
  amountType: 'fixed' | 'percentage';
  amountValue: number;
  leverageType: 'fixed' | 'ai';
  fixedLeverage: number;
}

// Default trading settings
const DEFAULT_TRADE_SETTINGS: TradeSettings = {
  amountType: 'fixed',
  amountValue: 100,
  leverageType: 'fixed',
  fixedLeverage: 50
};

export const Settings: React.FC<SettingsProps> = ({ currentBalance, onBalanceChange }) => {
  const [balance, setBalance] = useState(currentBalance.toString());
  const [saved, setSaved] = useState(false);
  
  // Trade settings state
  const [tradeSettings, setTradeSettings] = useState<TradeSettings>(() => {
    const saved = localStorage.getItem(TRADE_SETTINGS_KEY);
    return saved ? JSON.parse(saved) : DEFAULT_TRADE_SETTINGS;
  });

  const [notifications, setNotifications] = useState(true);
  const [darkMode, setDarkMode] = useState(true);

  // Sync with parent when currentBalance changes externally
  useEffect(() => {
    setBalance(currentBalance.toString());
  }, [currentBalance]);

  // Save trade settings to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem(TRADE_SETTINGS_KEY, JSON.stringify(tradeSettings));
    // Also dispatch storage event for other components
    window.dispatchEvent(new StorageEvent('storage', {
      key: TRADE_SETTINGS_KEY,
      newValue: JSON.stringify(tradeSettings)
    }));
  }, [tradeSettings]);

  const handleSave = () => {
    const newBalance = parseFloat(balance);
    if (!isNaN(newBalance) && newBalance > 0) {
      // CRITICAL FIX: Save to localStorage FIRST
      localStorage.setItem(BALANCE_KEY, newBalance.toString());
      
      // Dispatch storage event for cross-tab communication
      window.dispatchEvent(new StorageEvent('storage', {
        key: BALANCE_KEY,
        newValue: newBalance.toString()
      }));
      
      // Then notify parent
      onBalanceChange(newBalance);
      
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
      
      console.log(`[Settings] Balance saved: $${newBalance.toLocaleString()}`);
    }
  };

  const handleReset = () => {
    const defaultBalance = 100000;
    setBalance(defaultBalance.toString());
    
    // CRITICAL FIX: Clear localStorage
    localStorage.removeItem(BALANCE_KEY);
    localStorage.removeItem(TRADE_SETTINGS_KEY);
    
    // Dispatch events
    window.dispatchEvent(new StorageEvent('storage', {
      key: BALANCE_KEY,
      newValue: null
    }));
    
    onBalanceChange(defaultBalance);
    setTradeSettings(DEFAULT_TRADE_SETTINGS);
  };

  const applyBalancePreset = (value: number) => {
    setBalance(value.toString());
  };

  const updateTradeSetting = <K extends keyof TradeSettings>(
    key: K, 
    value: TradeSettings[K]
  ) => {
    setTradeSettings(prev => ({ ...prev, [key]: value }));
  };

  // Calculate preview
  const getPositionPreview = () => {
    const amount = tradeSettings.amountType === 'fixed' 
      ? tradeSettings.amountValue 
      : (parseFloat(balance) || 100000) * (tradeSettings.amountValue / 100);
    
    const leverage = tradeSettings.leverageType === 'fixed' 
      ? tradeSettings.fixedLeverage 
      : 10; // AI default
    
    return {
      margin: amount,
      leverage,
      positionValue: amount * leverage
    };
  };

  const preview = getPositionPreview();

  return (
    <div className="flex flex-col gap-6 max-w-4xl mx-auto">
      {/* Header */}
      <div className="flex items-center gap-3 mb-2">
        <div className="p-2 bg-[#d0ff59]/10 rounded-lg">
          <User className="w-6 h-6 text-[#d0ff59]" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-white">Settings</h1>
          <p className="text-[#888888] text-sm">Manage your trading preferences</p>
        </div>
      </div>

      {/* Account Balance Section */}
      <div className="bg-[#1a1a1a] border border-[#2a2a2a] rounded-xl p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2 bg-[#d0ff59]/10 rounded-lg">
            <Wallet className="w-5 h-5 text-[#d0ff59]" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-white">Demo Trading Balance</h3>
            <p className="text-[#888888] text-sm">Set your virtual trading capital</p>
          </div>
        </div>

        {/* Current Balance Display */}
        <div className="bg-[#0a0a0a] rounded-xl p-4 mb-6">
          <div className="text-sm text-[#888888] mb-1">Current Balance</div>
          <div className="text-3xl font-bold text-[#d0ff59]">
            ${currentBalance.toLocaleString('en-US', { minimumFractionDigits: 2 })}
          </div>
        </div>

        {/* Edit Balance */}
        <div className="mb-4">
          <label className="block text-sm text-[#888888] mb-2">Set New Balance</label>
          <div className="relative">
            <DollarSign className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#888888]" />
            <input
              type="number"
              value={balance}
              onChange={(e) => setBalance(e.target.value)}
              className="w-full bg-[#0a0a0a] border border-[#2a2a2a] rounded-xl pl-12 pr-4 py-3 text-lg text-white placeholder:text-[#888888] focus:outline-none focus:border-[#d0ff59]/50"
              placeholder="Enter amount..."
            />
          </div>
        </div>

        {/* Quick Presets */}
        <div className="flex flex-wrap gap-2 mb-6">
          {PRESETS.map((preset) => (
            <button
              key={preset.value}
              onClick={() => applyBalancePreset(preset.value)}
              className="px-4 py-2 bg-[#2a2a2a] hover:bg-[#3a3a3a] text-[#888888] hover:text-white rounded-lg text-sm font-medium transition-colors"
            >
              {preset.label}
            </button>
          ))}
        </div>

        {/* Action Buttons */}
        <div className="flex gap-3">
          <button
            onClick={handleSave}
            className={cn(
              "flex-1 flex items-center justify-center gap-2 py-3 rounded-xl font-medium transition-all",
              saved 
                ? "bg-green-500 text-white" 
                : "bg-[#d0ff59] text-black hover:bg-[#d0ff59]/90"
            )}
          >
            <Save className="w-4 h-4" />
            {saved ? 'Saved!' : 'Save Balance'}
          </button>
          <button
            onClick={handleReset}
            className="flex items-center justify-center gap-2 px-6 py-3 bg-[#2a2a2a] hover:bg-[#3a3a3a] text-[#888888] hover:text-white rounded-xl font-medium transition-colors"
          >
            <RotateCcw className="w-4 h-4" />
            Reset
          </button>
        </div>
      </div>

      {/* AI TRADE SETTINGS SECTION */}
      <div className="bg-[#1a1a1a] border border-[#2a2a2a] rounded-xl p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2 bg-[#d0ff59]/10 rounded-lg">
            <Zap className="w-5 h-5 text-[#d0ff59]" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-white">AI Trade Settings</h3>
            <p className="text-[#888888] text-sm">Configure how AI opens positions</p>
          </div>
        </div>

        {/* Trade Amount Settings */}
        <div className="mb-6">
          <label className="block text-sm text-white font-medium mb-3">Trade Amount</label>
          
          {/* Amount Type Toggle */}
          <div className="flex gap-2 mb-4">
            <button
              onClick={() => updateTradeSetting('amountType', 'fixed')}
              className={cn(
                "flex-1 flex items-center justify-center gap-2 py-2 rounded-lg text-sm font-medium transition-colors",
                tradeSettings.amountType === 'fixed'
                  ? "bg-[#d0ff59] text-black"
                  : "bg-[#2a2a2a] text-[#888888] hover:bg-[#3a3a3a]"
              )}
            >
              <DollarSign className="w-4 h-4" />
              Fixed Amount
            </button>
            <button
              onClick={() => updateTradeSetting('amountType', 'percentage')}
              className={cn(
                "flex-1 flex items-center justify-center gap-2 py-2 rounded-lg text-sm font-medium transition-colors",
                tradeSettings.amountType === 'percentage'
                  ? "bg-[#d0ff59] text-black"
                  : "bg-[#2a2a2a] text-[#888888] hover:bg-[#3a3a3a]"
              )}
            >
              <Percent className="w-4 h-4" />
              % of Balance
            </button>
          </div>

          {/* Amount Input */}
          <div className="relative mb-4">
            {tradeSettings.amountType === 'fixed' ? (
              <DollarSign className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#888888]" />
            ) : (
              <Percent className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#888888]" />
            )}
            <input
              type="number"
              value={tradeSettings.amountValue}
              onChange={(e) => updateTradeSetting('amountValue', parseFloat(e.target.value) || 0)}
              className="w-full bg-[#0a0a0a] border border-[#2a2a2a] rounded-xl pl-12 pr-4 py-3 text-lg text-white focus:outline-none focus:border-[#d0ff59]/50"
              placeholder={tradeSettings.amountType === 'fixed' ? "Enter USD amount..." : "Enter percentage..."}
              min="1"
              step={tradeSettings.amountType === 'fixed' ? "10" : "0.1"}
            />
          </div>

          <p className="text-xs text-[#888888]">
            {tradeSettings.amountType === 'fixed' 
              ? 'Fixed USD amount to use for each trade (e.g., $100)'
              : 'Percentage of your current balance to use per trade (e.g., 5%)'
            }
          </p>
        </div>

        {/* Leverage Settings */}
        <div className="mb-6 pt-6 border-t border-[#2a2a2a]">
          <label className="block text-sm text-white font-medium mb-3">Leverage</label>
          
          {/* Leverage Type Toggle */}
          <div className="flex gap-2 mb-4">
            <button
              onClick={() => updateTradeSetting('leverageType', 'fixed')}
              className={cn(
                "flex-1 flex items-center justify-center gap-2 py-2 rounded-lg text-sm font-medium transition-colors",
                tradeSettings.leverageType === 'fixed'
                  ? "bg-[#d0ff59] text-black"
                  : "bg-[#2a2a2a] text-[#888888] hover:bg-[#3a3a3a]"
              )}
            >
              <TrendingUp className="w-4 h-4" />
              Fixed Leverage
            </button>
            <button
              onClick={() => updateTradeSetting('leverageType', 'ai')}
              className={cn(
                "flex-1 flex items-center justify-center gap-2 py-2 rounded-lg text-sm font-medium transition-colors",
                tradeSettings.leverageType === 'ai'
                  ? "bg-[#d0ff59] text-black"
                  : "bg-[#2a2a2a] text-[#888888] hover:bg-[#3a3a3a]"
              )}
            >
              <Zap className="w-4 h-4" />
              AI Auto
            </button>
          </div>

          {/* Fixed Leverage Slider */}
          {tradeSettings.leverageType === 'fixed' && (
            <div className="mb-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-[#888888]">Leverage</span>
                <span className="text-lg font-bold text-[#d0ff59]">{tradeSettings.fixedLeverage}x</span>
              </div>
              <input
                type="range"
                min="1"
                max="125"
                step="1"
                value={tradeSettings.fixedLeverage}
                onChange={(e) => updateTradeSetting('fixedLeverage', parseInt(e.target.value))}
                className="w-full h-2 bg-[#0a0a0a] rounded-lg appearance-none cursor-pointer accent-[#d0ff59]"
              />
              <div className="flex justify-between text-xs text-[#888888] mt-1">
                <span>1x</span>
                <span>125x</span>
              </div>
            </div>
          )}

          <p className="text-xs text-[#888888]">
            {tradeSettings.leverageType === 'fixed' 
              ? 'Fixed leverage multiplier for all AI trades'
              : 'AI automatically selects leverage (2x-5x) based on confidence level'
            }
          </p>
        </div>

        {/* Position Preview */}
        <div className="bg-[#0a0a0a] rounded-xl p-4 border border-[#d0ff59]/30">
          <div className="flex items-center gap-2 mb-3">
            <BarChart3 className="w-4 h-4 text-[#d0ff59]" />
            <span className="text-sm font-medium text-white">Next Trade Preview</span>
          </div>
          <div className="grid grid-cols-3 gap-4">
            <div>
              <p className="text-xs text-[#888888] mb-1">Your Margin</p>
              <p className="text-lg font-bold text-white">${preview.margin.toFixed(2)}</p>
            </div>
            <div>
              <p className="text-xs text-[#888888] mb-1">Leverage</p>
              <p className="text-lg font-bold text-[#d0ff59]">{preview.leverage}x</p>
            </div>
            <div>
              <p className="text-xs text-[#888888] mb-1">Position Value</p>
              <p className="text-lg font-bold text-[#d0ff59]">${preview.positionValue.toFixed(2)}</p>
            </div>
          </div>
          <p className="text-xs text-[#888888] mt-3">
            With ${preview.margin.toFixed(2)} margin and {preview.leverage}x leverage, 
            AI will open a ${preview.positionValue.toFixed(2)} position
          </p>
        </div>
      </div>

      {/* App Preferences */}
      <div className="bg-[#1a1a1a] border border-[#2a2a2a] rounded-xl p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2 bg-[#d0ff59]/10 rounded-lg">
            <Shield className="w-5 h-5 text-[#d0ff59]" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-white">App Preferences</h3>
            <p className="text-[#888888] text-sm">Customize your experience</p>
          </div>
        </div>

        <div className="space-y-4">
          {/* Notifications */}
          <div className="flex items-center justify-between p-4 bg-[#0a0a0a] rounded-xl">
            <div className="flex items-center gap-3">
              <Bell className="w-5 h-5 text-[#888888]" />
              <div>
                <div className="text-white font-medium">Notifications</div>
                <div className="text-sm text-[#888888]">Get alerts for trades and signals</div>
              </div>
            </div>
            <button
              onClick={() => setNotifications(!notifications)}
              className={cn(
                "w-12 h-6 rounded-full transition-colors relative",
                notifications ? "bg-[#d0ff59]" : "bg-[#2a2a2a]"
              )}
            >
              <div className={cn(
                "w-5 h-5 bg-white rounded-full absolute top-0.5 transition-transform",
                notifications ? "translate-x-6" : "translate-x-0.5"
              )} />
            </button>
          </div>

          {/* Dark Mode */}
          <div className="flex items-center justify-between p-4 bg-[#0a0a0a] rounded-xl">
            <div className="flex items-center gap-3">
              <Moon className="w-5 h-5 text-[#888888]" />
              <div>
                <div className="text-white font-medium">Dark Mode</div>
                <div className="text-sm text-[#888888]">Always on</div>
              </div>
            </div>
            <button
              onClick={() => setDarkMode(!darkMode)}
              className={cn(
                "w-12 h-6 rounded-full transition-colors relative",
                darkMode ? "bg-[#d0ff59]" : "bg-[#2a2a2a]"
              )}
            >
              <div className={cn(
                "w-5 h-5 bg-white rounded-full absolute top-0.5 transition-transform",
                darkMode ? "translate-x-6" : "translate-x-0.5"
              )} />
            </button>
          </div>
        </div>
      </div>

      {/* Info Card */}
      <div className="bg-[#d0ff59]/5 border border-[#d0ff59]/20 rounded-xl p-4">
        <div className="flex items-start gap-3">
          <div className="p-1 bg-[#d0ff59]/20 rounded">
            <Shield className="w-4 h-4 text-[#d0ff59]" />
          </div>
          <div>
            <h4 className="text-[#d0ff59] font-medium mb-1">Demo Trading Mode</h4>
            <p className="text-[#888888] text-sm">
              Changes to your balance and trading settings take effect immediately. 
              Position Value = Margin × Leverage. P&L is calculated on the full position value.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Settings;
