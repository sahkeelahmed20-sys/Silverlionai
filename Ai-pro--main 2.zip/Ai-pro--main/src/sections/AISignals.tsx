import React, { useEffect, useState } from 'react';
import { useAISignals, TOP_10_COINS, type TopCoin } from '../hooks/useAISignals';
import { 
  TrendingUp, 
  TrendingDown, 
  Minus, 
  Brain, 
  Activity,
  Target,
  Shield,
  RefreshCw,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  BarChart3,
  ChevronLeft,
  ChevronRight,
  Pause,
  Play
} from 'lucide-react';
import { cn } from '../lib/utils';

interface AISignalsProps {
  symbol?: string;
  tradingState?: {
    aiEnabled: boolean;
    marketRegime: string;
  };
  onSymbolChange?: (symbol: string) => void;
}

export const AISignals: React.FC<AISignalsProps> = ({ 
  symbol: externalSymbol, 
  tradingState,
  onSymbolChange 
}) => {
  const {
    currentSymbol,
    currentSignal,
    allSignals,
    isLoading,
    error,
    refresh,
    refreshAll,
    historicalAccuracy,
    isAutoRotating,
    setIsAutoRotating,
    setManualSymbol,
    rotationIndex
  } = useAISignals(externalSymbol as TopCoin || undefined);

  const [lastUpdated, setLastUpdated] = useState<Date>(new Date());

  useEffect(() => {
    if (externalSymbol && externalSymbol !== currentSymbol) {
      setManualSymbol(externalSymbol as TopCoin);
    }
  }, [externalSymbol, currentSymbol, setManualSymbol]);

  useEffect(() => {
    if (onSymbolChange && currentSymbol) {
      onSymbolChange(currentSymbol);
    }
    setLastUpdated(new Date());
  }, [currentSymbol, onSymbolChange]);

  const handlePrevCoin = () => {
    const newIndex = rotationIndex === 0 ? TOP_10_COINS.length - 1 : rotationIndex - 1;
    setManualSymbol(TOP_10_COINS[newIndex]);
  };

  const handleNextCoin = () => {
    const newIndex = (rotationIndex + 1) % TOP_10_COINS.length;
    setManualSymbol(TOP_10_COINS[newIndex]);
  };

  const handleCoinSelect = (coin: TopCoin) => {
    setManualSymbol(coin);
  };

  if (isLoading && !currentSignal) {
    return (
      <div className="bg-[#1a1a1a] border border-[#2a2a2a] rounded-xl p-6">
        <div className="flex items-center justify-center h-64">
          <div className="flex flex-col items-center gap-4">
            <Brain className="w-8 h-8 text-[#d0ff59] animate-pulse" />
            <p className="text-[#888888]">AI Analyzing Market Data...</p>
          </div>
        </div>
      </div>
    );
  }

  if (error || !currentSignal) {
    return (
      <div className="bg-[#1a1a1a] border border-[#2a2a2a] rounded-xl p-6">
        <div className="flex flex-col items-center justify-center h-64 text-red-500">
          <AlertTriangle className="w-8 h-8 mb-4" />
          <p>{error || 'Analysis unavailable'}</p>
          <button 
            onClick={refreshAll}
            className="mt-4 px-4 py-2 bg-[#d0ff59] text-black rounded-lg hover:bg-[#d0ff59]/90"
          >
            Retry Analysis
          </button>
        </div>
      </div>
    );
  }

  const analysis = currentSignal.analysis;
  const currentPrice = currentSignal.price;

  const getSignalColor = (signal: string) => {
    switch (signal) {
      case 'BUY': return 'text-green-500';
      case 'SELL': return 'text-red-500';
      default: return 'text-yellow-500';
    }
  };

  const getSignalBg = (signal: string) => {
    switch (signal) {
      case 'BUY': return 'bg-green-500/10 border-green-500/30';
      case 'SELL': return 'bg-red-500/10 border-red-500/30';
      default: return 'bg-yellow-500/10 border-yellow-500/30';
    }
  };

  const agentVotes = analysis.agentVotes || [];

  return (
    <div className="flex flex-col gap-6">
      {/* Coin Navigation Header */}
      <div className="bg-[#1a1a1a] border border-[#2a2a2a] rounded-xl p-4">
        <div className="flex items-center justify-between mb-3">
          <button 
            onClick={handlePrevCoin}
            className="p-2 hover:bg-white/10 rounded-lg transition-colors"
          >
            <ChevronLeft className="w-5 h-5 text-[#888888]" />
          </button>
          
          <div className="flex items-center gap-3">
            <div className="text-center">
              <h3 className="text-xl font-bold text-white">
                {currentSymbol.replace('USDT', '')}/USDT
              </h3>
              <p className="text-xs text-[#888888]">
                ${currentPrice.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </p>
            </div>
          </div>

          <button 
            onClick={handleNextCoin}
            className="p-2 hover:bg-white/10 rounded-lg transition-colors"
          >
            <ChevronRight className="w-5 h-5 text-[#888888]" />
          </button>
        </div>

        {/* Coin Selector Dots */}
        <div className="flex justify-center gap-2 mb-3">
          {TOP_10_COINS.map((coin, idx) => {
            const signal = allSignals.get(coin);
            let dotColor = "bg-[#2a2a2a]";
            
            if (idx === rotationIndex) {
              dotColor = "w-6 bg-[#d0ff59]";
            } else if (signal) {
              if (signal.analysis.signal === 'BUY') {
                dotColor = "bg-green-500/50";
              } else if (signal.analysis.signal === 'SELL') {
                dotColor = "bg-red-500/50";
              } else {
                dotColor = "bg-yellow-500/50";
              }
            }
            
            return (
              <button
                key={coin}
                onClick={() => handleCoinSelect(coin)}
                className={cn(
                  "h-2 rounded-full transition-all",
                  idx === rotationIndex ? "w-6" : "w-2",
                  dotColor
                )}
                title={`${coin.replace('USDT', '')}: ${signal?.analysis.signal || 'Loading...'}`}
              />
            );
          })}
        </div>

        {/* Auto-rotation Toggle */}
        <div className="flex items-center justify-center gap-2">
          <button
            onClick={() => setIsAutoRotating(!isAutoRotating)}
            className={cn(
              "flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors",
              isAutoRotating 
                ? "bg-[#d0ff59]/20 text-[#d0ff59]" 
                : "bg-[#2a2a2a] text-[#888888]"
            )}
          >
            {isAutoRotating ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
            {isAutoRotating ? 'Auto-Rotating' : 'Paused'}
          </button>
          <span className="text-xs text-[#888888]">
            {rotationIndex + 1} / {TOP_10_COINS.length}
          </span>
        </div>
      </div>

      {/* Main Signal Card */}
      <div className={cn(
        "rounded-xl border-2 p-6 transition-all duration-500",
        getSignalBg(analysis.signal)
      )}>
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <Brain className="w-6 h-6 text-[#d0ff59]" />
            <h3 className="text-lg font-semibold text-white">AI Trading Signal</h3>
          </div>
          <button 
            onClick={refresh}
            className="p-2 hover:bg-white/10 rounded-lg transition-colors"
          >
            <RefreshCw className="w-4 h-4 text-[#888888]" />
          </button>
        </div>

        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <div className={cn("text-4xl font-bold mb-2", getSignalColor(analysis.signal))}>
              {analysis.signal}
            </div>
            <div className="flex items-center gap-2 text-[#888888]">
              <Activity className="w-4 h-4" />
              <span>Confidence: {analysis.confidence.toFixed(1)}%</span>
            </div>
          </div>
          
          <div className="text-left sm:text-right">
            <div className="text-2xl font-bold text-white">
              ${analysis.entry.toLocaleString()}
            </div>
            <div className="text-sm text-[#888888]">Entry Price</div>
          </div>
        </div>

        {/* Confidence Bar */}
        <div className="mt-6">
          <div className="h-2 bg-black/30 rounded-full overflow-hidden">
            <div 
              className={cn(
                "h-full transition-all duration-1000",
                analysis.signal === 'BUY' ? 'bg-green-500' :
                analysis.signal === 'SELL' ? 'bg-red-500' : 'bg-yellow-500'
              )}
              style={{ width: `${Math.min(100, Math.max(0, analysis.confidence))}%` }}
            />
          </div>
        </div>
      </div>

      {/* SL / TP / RR Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-[#1a1a1a] border border-[#2a2a2a] rounded-xl p-4">
          <div className="flex items-center gap-2 text-red-400 mb-2">
            <Shield className="w-4 h-4" />
            <span className="text-xs uppercase tracking-wider">Stop Loss</span>
          </div>
          <div className="text-lg font-bold text-white">
            ${analysis.stopLoss.toLocaleString()}
          </div>
          <div className="text-xs text-red-400">
            {((analysis.stopLoss - analysis.entry) / analysis.entry * 100).toFixed(2)}%
          </div>
        </div>

        <div className="bg-[#1a1a1a] border border-[#2a2a2a] rounded-xl p-4">
          <div className="flex items-center gap-2 text-[#d0ff59] mb-2">
            <Target className="w-4 h-4" />
            <span className="text-xs uppercase tracking-wider">Take Profit</span>
          </div>
          <div className="text-lg font-bold text-white">
            ${analysis.takeProfit.toLocaleString()}
          </div>
          <div className="text-xs text-green-400">
            +{((analysis.takeProfit - analysis.entry) / analysis.entry * 100).toFixed(2)}%
          </div>
        </div>

        <div className="bg-[#1a1a1a] border border-[#2a2a2a] rounded-xl p-4">
          <div className="flex items-center gap-2 text-blue-400 mb-2">
            <BarChart3 className="w-4 h-4" />
            <span className="text-xs uppercase tracking-wider">R:R Ratio</span>
          </div>
          <div className="text-lg font-bold text-white">
            {analysis.riskReward.toFixed(2)}
          </div>
          <div className="text-xs text-[#888888]">
            Risk/Reward
          </div>
        </div>
      </div>

      {/* AI Agent Consensus */}
      {agentVotes.length > 0 && (
        <div className="bg-[#1a1a1a] border border-[#2a2a2a] rounded-xl p-6">
          <h4 className="text-sm font-semibold text-[#888888] mb-4 uppercase tracking-wider">
            AI Agent Consensus
          </h4>
          
          <div className="space-y-3">
            {agentVotes.map((agent, idx) => (
              <div key={idx} className="flex items-center justify-between p-3 bg-black/20 rounded-lg">
                <div className="flex items-center gap-3">
                  {agent.vote === 'BUY' && <TrendingUp className="w-4 h-4 text-green-500" />}
                  {agent.vote === 'SELL' && <TrendingDown className="w-4 h-4 text-red-500" />}
                  {agent.vote === 'HOLD' && <Minus className="w-4 h-4 text-yellow-500" />}
                  <div>
                    <div className="text-sm font-medium text-white">{agent.name}</div>
                    <div className="text-xs text-[#888888]">{agent.reasoning}</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className={cn(
                    "text-sm font-bold",
                    agent.vote === 'BUY' ? 'text-green-500' :
                    agent.vote === 'SELL' ? 'text-red-500' : 'text-yellow-500'
                  )}>
                    {agent.vote}
                  </div>
                  <div className="text-xs text-[#888888]">{(agent.weight * 100).toFixed(0)}% weight</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Market Regime & Accuracy */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-[#1a1a1a] border border-[#2a2a2a] rounded-xl p-4">
          <div className="text-xs text-[#888888] uppercase mb-2 tracking-wider">Market Regime</div>
          <div className="flex items-center gap-2">
            <Activity className="w-4 h-4 text-[#d0ff59]" />
            <span className="text-white font-medium">{analysis.marketRegime}</span>
          </div>
        </div>

        <div className="bg-[#1a1a1a] border border-[#2a2a2a] rounded-xl p-4">
          <div className="text-xs text-[#888888] uppercase mb-2 tracking-wider">Historical Accuracy</div>
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-[#d0ff59]" />
            <span className="text-white font-medium">{historicalAccuracy.toFixed(1)}%</span>
          </div>
        </div>
      </div>

      {/* Signal Strength & Auto Trading */}
      <div className="grid grid-cols-2 gap-4">
        <div className={cn(
          "p-4 rounded-xl border",
          analysis.confidence >= 80 ? 'bg-green-500/10 border-green-500/30' : 'bg-red-500/10 border-red-500/30'
        )}>
          <div className="flex items-center gap-2 mb-2">
            {analysis.confidence >= 80 ? 
              <CheckCircle2 className="w-5 h-5 text-green-500" /> : 
              <XCircle className="w-5 h-5 text-red-500" />
            }
            <span className="text-sm font-medium text-white">Signal Strength</span>
          </div>
          <div className={analysis.confidence >= 80 ? 'text-green-400' : 'text-red-400'}>
            {analysis.confidence >= 80 ? 'Strong Signal' : 'Weak Signal'}
          </div>
        </div>

        <div className={cn(
          "p-4 rounded-xl border",
          tradingState?.aiEnabled ? 'bg-green-500/10 border-green-500/30' : 'bg-red-500/10 border-red-500/30'
        )}>
          <div className="flex items-center gap-2 mb-2">
            {tradingState?.aiEnabled ? 
              <CheckCircle2 className="w-5 h-5 text-green-500" /> : 
              <XCircle className="w-5 h-5 text-red-500" />
            }
            <span className="text-sm font-medium text-white">Auto Trading</span>
          </div>
          <div className={tradingState?.aiEnabled ? 'text-green-400' : 'text-red-400'}>
            {tradingState?.aiEnabled ? 'Enabled' : 'Disabled'}
          </div>
        </div>
      </div>

      <div className="text-center text-xs text-[#888888]">
        Last updated: {lastUpdated.toLocaleTimeString()}
      </div>
    </div>
  );
};

export default AISignals;
