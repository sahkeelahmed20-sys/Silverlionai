import React, { useState, useEffect } from 'react';
import { Shield, AlertTriangle, TrendingDown, Percent, Save } from 'lucide-react';

const RiskManagement: React.FC = () => {
  const [maxDailyLoss, setMaxDailyLoss] = useState(5);
  const [maxPositionSize, setMaxPositionSize] = useState(10);
  const [stopLossPercent, setStopLossPercent] = useState(2);
  const [takeProfitPercent, setTakeProfitPercent] = useState(6);
  const [maxLeverage, setMaxLeverage] = useState(5);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Load saved risk settings
    const saved = localStorage.getItem('trading_settings');
    if (saved) {
      const settings = JSON.parse(saved);
      setMaxDailyLoss(settings.maxDailyLoss || 5);
      setMaxPositionSize(settings.maxPositionSize || 10);
      setStopLossPercent(settings.stopLossPercent || 2);
      setTakeProfitPercent(settings.takeProfitPercent || 6);
      setMaxLeverage(settings.maxLeverage || 5);
    }
    setIsLoading(false);
  }, []);

  const saveRiskSettings = () => {
    const saved = localStorage.getItem('trading_settings') || '{}';
    const settings = JSON.parse(saved);
    settings.maxDailyLoss = maxDailyLoss;
    settings.maxPositionSize = maxPositionSize;
    settings.stopLossPercent = stopLossPercent;
    settings.takeProfitPercent = takeProfitPercent;
    settings.maxLeverage = maxLeverage;
    localStorage.setItem('trading_settings', JSON.stringify(settings));
    alert('Risk settings saved!');
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#e8ff47]"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6 p-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-3">
            <Shield className="w-8 h-8 text-[#e8ff47]" />
            Risk Management
          </h1>
          <p className="text-[#888888] mt-1">Configure your trading risk parameters</p>
        </div>
        <button
          onClick={saveRiskSettings}
          className="flex items-center gap-2 px-4 py-2 bg-[#e8ff47] text-black rounded-lg font-medium hover:bg-[#d4eb3f]"
        >
          <Save className="w-4 h-4" />
          Save Settings
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-[#1a1a1a] border border-[#333333] rounded-xl p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2 bg-red-500/20 rounded-lg">
              <AlertTriangle className="w-5 h-5 text-red-500" />
            </div>
            <div>
              <h3 className="text-white font-semibold">Daily Loss Limit</h3>
              <p className="text-sm text-[#888888]">Maximum daily loss before trading stops</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <input
              type="range"
              min="1"
              max="20"
              value={maxDailyLoss}
              onChange={(e) => setMaxDailyLoss(Number(e.target.value))}
              className="flex-1 h-2 bg-[#333333] rounded-lg appearance-none cursor-pointer"
            />
            <span className="text-2xl font-bold text-white w-16 text-right">{maxDailyLoss}%</span>
          </div>
        </div>

        <div className="bg-[#1a1a1a] border border-[#333333] rounded-xl p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2 bg-[#e8ff47]/20 rounded-lg">
              <Percent className="w-5 h-5 text-[#e8ff47]" />
            </div>
            <div>
              <h3 className="text-white font-semibold">Max Position Size</h3>
              <p className="text-sm text-[#888888]">Maximum capital per position</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <input
              type="range"
              min="1"
              max="50"
              value={maxPositionSize}
              onChange={(e) => setMaxPositionSize(Number(e.target.value))}
              className="flex-1 h-2 bg-[#333333] rounded-lg appearance-none cursor-pointer"
            />
            <span className="text-2xl font-bold text-white w-16 text-right">{maxPositionSize}%</span>
          </div>
        </div>

        <div className="bg-[#1a1a1a] border border-[#333333] rounded-xl p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2 bg-orange-500/20 rounded-lg">
              <TrendingDown className="w-5 h-5 text-orange-500" />
            </div>
            <div>
              <h3 className="text-white font-semibold">Default Stop Loss</h3>
              <p className="text-sm text-[#888888]">Automatic stop loss percentage</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <input
              type="range"
              min="0.5"
              max="10"
              step="0.5"
              value={stopLossPercent}
              onChange={(e) => setStopLossPercent(Number(e.target.value))}
              className="flex-1 h-2 bg-[#333333] rounded-lg appearance-none cursor-pointer"
            />
            <span className="text-2xl font-bold text-white w-16 text-right">{stopLossPercent}%</span>
          </div>
        </div>

        <div className="bg-[#1a1a1a] border border-[#333333] rounded-xl p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2 bg-green-500/20 rounded-lg">
              <TrendingDown className="w-5 h-5 text-green-500 rotate-180" />
            </div>
            <div>
              <h3 className="text-white font-semibold">Default Take Profit</h3>
              <p className="text-sm text-[#888888]">Automatic take profit percentage</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <input
              type="range"
              min="1"
              max="20"
              value={takeProfitPercent}
              onChange={(e) => setTakeProfitPercent(Number(e.target.value))}
              className="flex-1 h-2 bg-[#333333] rounded-lg appearance-none cursor-pointer"
            />
            <span className="text-2xl font-bold text-white w-16 text-right">{takeProfitPercent}%</span>
          </div>
        </div>

        <div className="bg-[#1a1a1a] border border-[#333333] rounded-xl p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2 bg-blue-500/20 rounded-lg">
              <Percent className="w-5 h-5 text-blue-500" />
            </div>
            <div>
              <h3 className="text-white font-semibold">Max Leverage</h3>
              <p className="text-sm text-[#888888]">Maximum leverage for positions</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <input
              type="range"
              min="1"
              max="20"
              value={maxLeverage}
              onChange={(e) => setMaxLeverage(Number(e.target.value))}
              className="flex-1 h-2 bg-[#333333] rounded-lg appearance-none cursor-pointer"
            />
            <span className="text-2xl font-bold text-white w-16 text-right">{maxLeverage}x</span>
          </div>
        </div>
      </div>

      <div className="bg-[#1a1a1a] border border-[#333333] rounded-xl p-6">
        <h3 className="text-lg font-semibold text-white mb-4">Risk Summary</h3>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          <div className="p-4 bg-[#0f0f0f] rounded-lg border border-[#333333]">
            <p className="text-sm text-[#888888]">Risk per Trade</p>
            <p className="text-xl font-bold text-white">{stopLossPercent}%</p>
          </div>
          <div className="p-4 bg-[#0f0f0f] rounded-lg border border-[#333333]">
            <p className="text-sm text-[#888888]">Risk/Reward</p>
            <p className="text-xl font-bold text-white">1:{(takeProfitPercent / stopLossPercent).toFixed(1)}</p>
          </div>
          <div className="p-4 bg-[#0f0f0f] rounded-lg border border-[#333333]">
            <p className="text-sm text-[#888888]">Max Positions</p>
            <p className="text-xl font-bold text-white">{Math.floor(100 / maxPositionSize)}</p>
          </div>
          <div className="p-4 bg-[#0f0f0f] rounded-lg border border-[#333333]">
            <p className="text-sm text-[#888888]">Daily Risk</p>
            <p className="text-xl font-bold text-white">{maxDailyLoss}%</p>
          </div>
          <div className="p-4 bg-[#0f0f0f] rounded-lg border border-[#333333]">
            <p className="text-sm text-[#888888]">Max Leverage</p>
            <p className="text-xl font-bold text-white">{maxLeverage}x</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RiskManagement;
