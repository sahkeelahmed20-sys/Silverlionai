import React, { useState, useEffect } from 'react';
import { ArrowUpRight, ArrowDownRight, FishSymbol, Wallet } from 'lucide-react';
import { binanceWS } from '../services/binanceWebSocket';

interface WhaleTransaction {
  id: string;
  symbol: string;
  amount: number;
  value: number;
  type: 'in' | 'out';
  exchange: string;
  wallet: string;
  timestamp: string;
}

const WhaleTracking: React.FC = () => {
  const [transactions, setTransactions] = useState<WhaleTransaction[]>([]);
  const [btcPrice, setBtcPrice] = useState<number>(0);
  const [ethPrice, setEthPrice] = useState<number>(0);
  const [totalInflow, setTotalInflow] = useState(0);
  const [totalOutflow, setTotalOutflow] = useState(0);

  // Connect to WebSocket for live prices
  useEffect(() => {
    const unsubscribe = binanceWS.subscribe((symbol: string, price: number) => {
      if (symbol === 'BTC/USDT') {
        setBtcPrice(price);
      } else if (symbol === 'ETH/USDT') {
        setEthPrice(price);
      }
    });

    binanceWS.connect();

    return () => {
      unsubscribe();
      binanceWS.disconnect();
    };
  }, []);

  // Generate whale transactions with live prices
  useEffect(() => {
    const generateTransaction = (): WhaleTransaction => {
      const symbols = ['BTC', 'ETH', 'USDT', 'USDC'];
      const exchanges = ['Binance', 'Coinbase', 'Kraken', 'OKX'];
      const type = Math.random() > 0.5 ? 'in' : 'out';
      const symbol = symbols[Math.floor(Math.random() * symbols.length)];
      const amount = Math.random() * 1000 + 100;
      
      // Use live prices if available, otherwise fallback
      const liveBtcPrice = btcPrice > 0 ? btcPrice : 68000;
      const liveEthPrice = ethPrice > 0 ? ethPrice : 3500;
      
      const price = symbol === 'BTC' ? liveBtcPrice : 
                    symbol === 'ETH' ? liveEthPrice : 1;
      
      return {
        id: Math.random().toString(36).substr(2, 9),
        symbol,
        amount,
        value: amount * price,
        type,
        exchange: exchanges[Math.floor(Math.random() * exchanges.length)],
        wallet: '0x' + Math.random().toString(16).substr(2, 40),
        timestamp: new Date().toISOString()
      };
    };

    // Only generate initial data when we have prices
    if (btcPrice === 0) return;

    // Initial data
    const initialData = Array.from({ length: 5 }, generateTransaction);
    setTransactions(initialData);
    
    // Calculate totals
    const inflow = initialData.filter(t => t.type === 'in').reduce((a, b) => a + b.value, 0);
    const outflow = initialData.filter(t => t.type === 'out').reduce((a, b) => a + b.value, 0);
    setTotalInflow(inflow);
    setTotalOutflow(outflow);

    // Simulate live updates
    const interval = setInterval(() => {
      const newTx = generateTransaction();
      setTransactions(prev => [newTx, ...prev].slice(0, 10));
      
      if (newTx.type === 'in') {
        setTotalInflow(prev => prev + newTx.value);
      } else {
        setTotalOutflow(prev => prev + newTx.value);
      }
    }, 10000);

    return () => clearInterval(interval);
  }, [btcPrice, ethPrice]);

  return (
    <div className="bg-[#0a0a0a] border border-[#333333] rounded-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <FishSymbol className="w-5 h-5 text-[#d4ff00]" />
            Whale Tracking
          </h2>
          <p className="text-sm text-[#888888] mt-1">Monitor large cryptocurrency transactions</p>
        </div>
        <div className="text-right">
          <div className="text-xs text-[#888888]">BTC Price</div>
          <div className="text-lg font-bold text-white">
            {btcPrice > 0 ? `$${btcPrice.toLocaleString()}` : 'Loading...'}
          </div>
          {btcPrice > 0 && (
            <div className="text-xs text-[#d4ff00]">Live</div>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div className="bg-[#141414] rounded-lg p-4 border border-[#222222]">
          <div className="text-xs text-[#888888] mb-1">Total Inflow</div>
          <div className="text-xl font-bold text-green-500 flex items-center gap-2">
            <ArrowUpRight className="w-5 h-5" />
            ${(totalInflow / 1e6).toFixed(2)}M
          </div>
        </div>
        <div className="bg-[#141414] rounded-lg p-4 border border-[#222222]">
          <div className="text-xs text-[#888888] mb-1">Total Outflow</div>
          <div className="text-xl font-bold text-red-500 flex items-center gap-2">
            <ArrowDownRight className="w-5 h-5" />
            ${(totalOutflow / 1e6).toFixed(2)}M
          </div>
        </div>
        <div className="bg-[#141414] rounded-lg p-4 border border-[#222222]">
          <div className="text-xs text-[#888888] mb-1">Net Flow</div>
          <div className={`text-xl font-bold flex items-center gap-2 ${
            totalInflow - totalOutflow >= 0 ? 'text-green-500' : 'text-red-500'
          }`}>
            {totalInflow - totalOutflow >= 0 ? <ArrowUpRight className="w-5 h-5" /> : <ArrowDownRight className="w-5 h-5" />}
            ${((totalInflow - totalOutflow) / 1e6).toFixed(2)}M
          </div>
        </div>
      </div>

      <div className="bg-[#141414] rounded-lg border border-[#222222] overflow-hidden">
        <div className="px-4 py-3 border-b border-[#222222] flex items-center justify-between">
          <h3 className="font-semibold text-white">Recent Whale Moves</h3>
          <span className="text-xs text-[#d4ff00] animate-pulse">Live updates</span>
        </div>
        <div className="divide-y divide-[#222222]">
          {transactions.length === 0 ? (
            <div className="p-8 text-center text-[#888888]">
              <div className="animate-pulse">Loading whale data...</div>
            </div>
          ) : (
            transactions.map((tx) => (
              <div key={tx.id} className="p-4 hover:bg-[#1a1a1a] transition-colors">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                      tx.type === 'in' ? 'bg-green-500/20 text-green-500' : 'bg-red-500/20 text-red-500'
                    }`}>
                      {tx.type === 'in' ? <ArrowUpRight className="w-5 h-5" /> : <ArrowDownRight className="w-5 h-5" />}
                    </div>
                    <div>
                      <div className="font-medium text-white">
                        {tx.amount.toFixed(2)} {tx.symbol}
                      </div>
                      <div className="text-xs text-[#666666]">
                        ${(tx.value / 1e6).toFixed(2)}M • {tx.exchange}
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className={`text-sm font-medium ${
                      tx.type === 'in' ? 'text-green-500' : 'text-red-500'
                    }`}>
                      {tx.type === 'in' ? 'Inflow' : 'Outflow'}
                    </div>
                    <div className="text-xs text-[#666666]">
                      {new Date(tx.timestamp).toLocaleTimeString()}
                    </div>
                  </div>
                </div>
                <div className="mt-2 flex items-center gap-2 text-xs text-[#666666]">
                  <Wallet className="w-3 h-3" />
                  <span>{tx.wallet.slice(0, 6)}...{tx.wallet.slice(-4)}</span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

export default WhaleTracking;
 