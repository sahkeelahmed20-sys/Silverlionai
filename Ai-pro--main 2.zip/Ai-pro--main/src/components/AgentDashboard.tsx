import React, { useEffect, useState } from 'react';
import { agentAdapter } from '../agents/integration/PlatformAdapter';
import { Brain, Shield, Activity, GitBranch, AlertTriangle, CheckCircle } from 'lucide-react';

export const AgentControlPanel: React.FC = () => {
  const [agentStatus, setAgentStatus] = useState<any>(null);
  const [pendingApprovals, setPendingApprovals] = useState<any[]>([]);
  const [systemLogs, setSystemLogs] = useState<any[]>([]);

  useEffect(() => {
    // Initialize agent system
    agentAdapter.initialize();

    // Status polling
    const interval = setInterval(() => {
      setAgentStatus(agentAdapter.getAgentStatus());
    }, 2000);

    // Event listeners
    const handleApproval = (e: any) => setPendingApprovals(prev => [...prev, e.detail]);
    const handleNotification = (e: any) => {
      setSystemLogs(prev => [...prev.slice(-49), { type: 'info', message: e.detail.message, time: Date.now() }]);
    };
    const handleEmergency = (e: any) => {
      setSystemLogs(prev => [...prev.slice(-49), { type: 'error', message: 'EMERGENCY: ' + e.detail.reason, time: Date.now() }]);
    };

    window.addEventListener('agent:approval_required', handleApproval);
    window.addEventListener('agent:system_notification', handleNotification);
    window.addEventListener('agent:risk_emergency', handleEmergency);

    return () => {
      clearInterval(interval);
      window.removeEventListener('agent:approval_required', handleApproval);
      window.removeEventListener('agent:system_notification', handleNotification);
      window.removeEventListener('agent:risk_emergency', handleEmergency);
    };
  }, []);

  const approveAction = (approvalId: string) => {
    // Send approval to orchestrator
    setPendingApprovals(prev => prev.filter(a => a.agentId !== approvalId));
  };

  const rejectAction = (approvalId: string) => {
    setPendingApprovals(prev => prev.filter(a => a.agentId !== approvalId));
  };

  if (!agentStatus) return <div className="p-4 text-gray-400">Initializing Agent Framework...</div>;

  return (
    <div className="bg-[#0b0b0b] border border-[#1a1a1a] rounded-lg p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Brain className="w-8 h-8 text-[#d4a373]" />
          <div>
            <h2 className="text-xl font-bold text-white">Self-Organizing AI Agents</h2>
            <p className="text-sm text-gray-400">Autonomous Multi-Agent Trading System</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <div className={`w-3 h-3 rounded-full ${agentStatus.active ? 'bg-green-500 animate-pulse' : 'bg-red-500'}`} />
          <span className="text-sm text-gray-300">{agentStatus.active ? 'COGNITIVE CYCLE ACTIVE' : 'STANDBY'}</span>
        </div>
      </div>

      {/* Agent Status Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {agentStatus.agents?.map((agent: any) => (
          <div key={agent.id} className="bg-[#151515] border border-[#2a2a2a] rounded-lg p-4 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                {agent.role === 'RISK_MANAGER' && <Shield className="w-5 h-5 text-red-400" />}
                {agent.role === 'STRATEGIST' && <GitBranch className="w-5 h-5 text-blue-400" />}
                {agent.role === 'LEARNER' && <Activity className="w-5 h-5 text-purple-400" />}
                <span className="font-semibold text-white">{agent.name}</span>
              </div>
              <span className={`text-xs px-2 py-1 rounded ${
                agent.status === 'THINKING' ? 'bg-yellow-500/20 text-yellow-400' :
                agent.status === 'ACTING' ? 'bg-blue-500/20 text-blue-400' :
                agent.status === 'LEARNING' ? 'bg-purple-500/20 text-purple-400' :
                'bg-gray-500/20 text-gray-400'
              }`}>
                {agent.status}
              </span>
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Performance</span>
                <span className={`font-mono ${
                  agent.performance > 0.7 ? 'text-green-400' :
                  agent.performance > 0.4 ? 'text-yellow-400' : 'text-red-400'
                }`}>
                  {(agent.performance * 100).toFixed(1)}%
                </span>
              </div>
              <div className="w-full bg-gray-800 rounded-full h-2">
                <div 
                  className={`h-2 rounded-full transition-all ${
                    agent.performance > 0.7 ? 'bg-green-500' :
                    agent.performance > 0.4 ? 'bg-yellow-500' : 'bg-red-500'
                  }`}
                  style={{ width: `${agent.performance * 100}%` }}
                />
              </div>
              
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Autonomy</span>
                <span className="text-white font-mono">{(agent.autonomy * 100).toFixed(0)}%</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Pending Approvals */}
      {pendingApprovals.length > 0 && (
        <div className="bg-yellow-500/5 border border-yellow-500/20 rounded-lg p-4">
          <h3 className="text-yellow-400 font-semibold mb-3 flex items-center gap-2">
            <AlertTriangle className="w-5 h-5" />
            Agent Approval Required
          </h3>
          <div className="space-y-3">
            {pendingApprovals.map((approval, idx) => (
              <div key={idx} className="bg-[#1a1a1a] rounded p-3 flex items-center justify-between">
                <div>
                  <p className="text-white font-medium">{approval.action}</p>
                  <p className="text-sm text-gray-400">{approval.reasoning}</p>
                  <p className="text-xs text-gray-500 mt-1">Confidence: {(approval.confidence * 100).toFixed(1)}%</p>
                </div>
                <div className="flex gap-2">
                  <button 
                    onClick={() => rejectAction(approval.agentId)}
                    className="px-3 py-1 bg-red-500/20 text-red-400 rounded hover:bg-red-500/30"
                  >
                    Reject
                  </button>
                  <button 
                    onClick={() => approveAction(approval.agentId)}
                    className="px-3 py-1 bg-green-500/20 text-green-400 rounded hover:bg-green-500/30"
                  >
                    Approve
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* System Logs */}
      <div className="bg-[#151515] border border-[#2a2a2a] rounded-lg p-4">
        <h3 className="text-white font-semibold mb-3 flex items-center gap-2">
          <Activity className="w-5 h-5 text-[#d4a373]" />
          Cognitive Stream
        </h3>
        <div className="space-y-1 max-h-40 overflow-y-auto font-mono text-sm">
          {systemLogs.map((log, idx) => (
            <div key={idx} className={`flex items-center gap-2 ${
              log.type === 'error' ? 'text-red-400' : 'text-gray-400'
            }`}>
              <span className="text-xs text-gray-600">
                {new Date(log.time).toLocaleTimeString()}
              </span>
              {log.type === 'error' ? <AlertTriangle className="w-3 h-3" /> : <CheckCircle className="w-3 h-3" />}
              <span>{log.message}</span>
            </div>
          ))}
          {systemLogs.length === 0 && <span className="text-gray-600 italic">No recent activity...</span>}
        </div>
      </div>

      {/* Quick Actions */}
      <div className="flex gap-3">
        <button 
          onClick={() => agentAdapter.initialize()}
          className="px-4 py-2 bg-[#d4a373] text-black font-medium rounded hover:bg-[#e0b080] transition-colors"
        >
          Restart Agents
        </button>
        <button 
          onClick={() => agentAdapter.shutdown()}
          className="px-4 py-2 bg-red-500/20 text-red-400 border border-red-500/30 rounded hover:bg-red-500/30"
        >
          Emergency Stop
        </button>
      </div>
    </div>
  );
};
