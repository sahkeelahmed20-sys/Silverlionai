import { 
  LayoutDashboard, 
  Wallet, 
  History, 
  BarChart3, 
  Newspaper, 
  Network,
  Settings,
  Zap,
  ChevronDown,
  Shield,
  Brain,
  Fish,
  Activity,
  X,
  LogOut,
  User
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useState } from 'react';
import type { User as UserType } from '@/types';

interface SidebarProps {
  activeSection: string;
  onSectionChange: (section: string) => void;
  isOpen: boolean;
  onClose: () => void;
  user?: UserType | null;
  onLogout?: () => void;
}

const mainMenuItems = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'demo-trading', label: 'Demo Trading', icon: Wallet },
  { id: 'backtesting', label: 'Backtesting', icon: History },
  { id: 'strategies', label: 'Strategies', icon: BarChart3 },
  { id: 'news', label: 'News Analysis', icon: Newspaper },
  { id: 'bitnodes', label: 'Bitnodes', icon: Network },
];

const advancedMenuItems = [
  { id: 'risk-management', label: 'Risk Management', icon: Shield },
  { id: 'ai-performance', label: 'AI Performance', icon: Brain },
  { id: 'whale-tracking', label: 'Whale Tracking', icon: Fish },
  { id: 'market-data', label: 'Market Data', icon: Activity },
];

export function Sidebar({ activeSection, onSectionChange, isOpen, onClose, user, onLogout }: SidebarProps) {
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);

  const handleLogout = () => {
    if (onLogout) {
      onLogout();
    }
  };

  return (
    <aside className={cn(
      'fixed left-0 top-0 h-full w-64 bg-[#0b0b0b] border-r border-[#222222] z-50 transition-transform duration-300 ease-in-out flex flex-col',
      'lg:translate-x-0',
      isOpen ? 'translate-x-0' : '-translate-x-full'
    )}>
      <div className="p-6 flex-1 overflow-y-auto">
        {/* Close button for mobile */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 lg:hidden w-8 h-8 flex items-center justify-center rounded-lg bg-[#1a1a1a] text-[#888888] hover:text-[#f6f6f6] transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-10 mt-2 lg:mt-0">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#d0ff59] to-[#a8cc47] flex items-center justify-center">
            <Zap className="w-6 h-6 text-black" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-[#f6f6f6]">CryptoAI Pro</h1>
            <p className="text-xs text-[#888888]">Intelligent Trading</p>
          </div>
        </div>

        {/* Main Menu */}
        <div className="mb-6">
          <p className="text-xs font-medium text-[#888888] uppercase tracking-wider mb-3 px-4">Main</p>
          <nav className="space-y-1">
            {mainMenuItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeSection === item.id;

              return (
                <button
                  key={item.id}
                  onClick={() => onSectionChange(item.id)}
                  className={cn(
                    'w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200',
                    'hover:bg-[#1a1a1a] group',
                    isActive 
                      ? 'bg-[#1a1a1a] border border-[#d0ff59]/30' 
                      : 'border border-transparent'
                  )}
                >
                  <Icon className={cn(
                    'w-5 h-5 transition-colors',
                    isActive ? 'text-[#d0ff59]' : 'text-[#888888] group-hover:text-[#cccccc]'
                  )} />
                  <span className={cn(
                    'text-sm font-medium transition-colors',
                    isActive ? 'text-[#f6f6f6]' : 'text-[#888888] group-hover:text-[#cccccc]'
                  )}>
                    {item.label}
                  </span>
                  {isActive && (
                    <div className="ml-auto w-1.5 h-1.5 rounded-full bg-[#d0ff59] animate-pulse" />
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Advanced Menu */}
        <div>
          <button
            onClick={() => setShowAdvanced(!showAdvanced)}
            className="w-full flex items-center justify-between px-4 py-3 mb-2 text-xs font-medium text-[#888888] uppercase tracking-wider hover:text-[#cccccc] transition-colors"
          >
            <span>Advanced</span>
            <ChevronDown className={cn(
              'w-4 h-4 transition-transform duration-200',
              showAdvanced && 'rotate-180'
            )} />
          </button>
          
          {showAdvanced && (
            <nav className="space-y-1">
              {advancedMenuItems.map((item) => {
                const Icon = item.icon;
                const isActive = activeSection === item.id;

                return (
                  <button
                    key={item.id}
                    onClick={() => onSectionChange(item.id)}
                    className={cn(
                      'w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200',
                      'hover:bg-[#1a1a1a] group',
                      isActive 
                        ? 'bg-[#1a1a1a] border border-[#d0ff59]/30' 
                        : 'border border-transparent'
                    )}
                  >
                    <Icon className={cn(
                      'w-5 h-5 transition-colors',
                      isActive ? 'text-[#d0ff59]' : 'text-[#888888] group-hover:text-[#cccccc]'
                    )} />
                    <span className={cn(
                      'text-sm font-medium transition-colors',
                      isActive ? 'text-[#f6f6f6]' : 'text-[#888888] group-hover:text-[#cccccc]'
                    )}>
                      {item.label}
                    </span>
                    {isActive && (
                      <div className="ml-auto w-1.5 h-1.5 rounded-full bg-[#d0ff59] animate-pulse" />
                    )}
                  </button>
                );
              })}
            </nav>
          )}
        </div>
      </div>

      {/* Bottom Section - User Profile & Settings */}
      <div className="border-t border-[#222222] p-4 space-y-2">
        {/* User Profile */}
        {user && (
          <div className="relative">
            <button
              onClick={() => setShowUserMenu(!showUserMenu)}
              className="w-full flex items-center gap-3 px-3 py-3 rounded-xl hover:bg-[#1a1a1a] transition-all group"
            >
              <div className="w-9 h-9 rounded-full bg-gradient-to-br from-[#00ff88] to-[#00cc6a] flex items-center justify-center flex-shrink-0">
                <User className="w-5 h-5 text-black" />
              </div>
              <div className="flex-1 min-w-0 text-left">
                <p className="text-sm font-medium text-[#f6f6f6] truncate">{user.username}</p>
                <p className="text-xs text-[#888888] truncate">{user.email}</p>
              </div>
              <ChevronDown className={cn(
                'w-4 h-4 text-[#888888] transition-transform duration-200',
                showUserMenu && 'rotate-180'
              )} />
            </button>

            {/* User Dropdown Menu */}
            {showUserMenu && (
              <div className="absolute bottom-full left-0 right-0 mb-2 bg-[#1a1a1a] border border-[#2a2a2a] rounded-xl p-2 shadow-xl">
                <button
                  onClick={() => {
                    onSectionChange('settings');
                    setShowUserMenu(false);
                  }}
                  className="w-full flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-[#2a2a2a] transition-colors text-left"
                >
                  <Settings className="w-4 h-4 text-[#888888]" />
                  <span className="text-sm text-[#f6f6f6]">Profile Settings</span>
                </button>
                <div className="h-px bg-[#2a2a2a] my-2" />
                <button
                  onClick={handleLogout}
                  className="w-full flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-red-500/10 transition-colors text-left group"
                >
                  <LogOut className="w-4 h-4 text-red-400 group-hover:text-red-300" />
                  <span className="text-sm text-red-400 group-hover:text-red-300">Logout</span>
                </button>
              </div>
            )}
          </div>
        )}

        {/* Settings Button */}
        <button
          onClick={() => onSectionChange('settings')}
          className={cn(
            'w-full flex items-center gap-3 px-3 py-3 rounded-xl transition-all duration-200',
            'hover:bg-[#1a1a1a] group',
            activeSection === 'settings'
              ? 'bg-[#1a1a1a] border border-[#d0ff59]/30'
              : 'border border-transparent'
          )}
        >
          <Settings className={cn(
            'w-5 h-5 transition-colors',
            activeSection === 'settings' ? 'text-[#d0ff59]' : 'text-[#888888] group-hover:text-[#cccccc]'
          )} />
          <span className={cn(
            'text-sm font-medium transition-colors',
            activeSection === 'settings' ? 'text-[#f6f6f6]' : 'text-[#888888] group-hover:text-[#cccccc]'
          )}>
            Settings
          </span>
          {activeSection === 'settings' && (
            <div className="ml-auto w-1.5 h-1.5 rounded-full bg-[#d0ff59] animate-pulse" />
          )}
        </button>
      </div>
    </aside>
  );
}
