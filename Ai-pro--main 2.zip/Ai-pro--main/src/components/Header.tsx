import { useState } from 'react';
import { 
  Bell, 
  Search, 
  User, 
  Brain, 
  TrendingUp, 
  TrendingDown, 
  Menu,
  ChevronDown,
  Bitcoin,
  Coins,
  LogOut,
  Settings
} from 'lucide-react';
import { cn } from '../lib/utils';
import type { User as UserType } from '@/types';

interface HeaderProps {
  tradingState: {
    aiEnabled: boolean;
    marketRegime: string;
    confidence: number;
  };
  onMenuClick: () => void;
  selectedSymbol: string;
  onSymbolChange: (symbol: string) => void;
  user?: UserType | null;
  onLogout?: () => void;
  onSettingsClick?: () => void;
}

const AVAILABLE_SYMBOLS = [
  { symbol: 'BTCUSDT', name: 'Bitcoin', icon: Bitcoin },
  { symbol: 'ETHUSDT', name: 'Ethereum', icon: Coins },
  { symbol: 'SOLUSDT', name: 'Solana', icon: Coins },
  { symbol: 'BNBUSDT', name: 'BNB', icon: Coins },
  { symbol: 'ADAUSDT', name: 'Cardano', icon: Coins },
  { symbol: 'DOTUSDT', name: 'Polkadot', icon: Coins },
  { symbol: 'LINKUSDT', name: 'Chainlink', icon: Coins },
  { symbol: 'MATICUSDT', name: 'Polygon', icon: Coins },
];

export function Header({ 
  tradingState, 
  onMenuClick, 
  selectedSymbol,
  onSymbolChange,
  user,
  onLogout,
  onSettingsClick
}: HeaderProps) {
  const [showSymbolDropdown, setShowSymbolDropdown] = useState(false);
  const [showUserDropdown, setShowUserDropdown] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const filteredSymbols = AVAILABLE_SYMBOLS.filter(s => 
    s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    s.symbol.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const currentSymbol = AVAILABLE_SYMBOLS.find(s => s.symbol === selectedSymbol);

  const handleLogout = () => {
    if (onLogout) {
      onLogout();
    }
    setShowUserDropdown(false);
  };

  const handleSettingsClick = () => {
    if (onSettingsClick) {
      onSettingsClick();
    }
    setShowUserDropdown(false);
  };

  return (
    <header className="h-16 bg-[#0a0a0a] border-b border-[#2a2a2a] flex items-center justify-between px-4 lg:px-6">
      <div className="flex items-center gap-4">
        <button
          onClick={onMenuClick}
          className="lg:hidden p-2 hover:bg-white/10 rounded-lg transition-colors"
        >
          <Menu className="w-6 h-6 text-[#888888]" />
        </button>

        <div className="relative">
          <button
            onClick={() => setShowSymbolDropdown(!showSymbolDropdown)}
            className="flex items-center gap-2 px-4 py-2 bg-[#1a1a1a] border border-[#2a2a2a] rounded-lg hover:border-[#d0ff59]/50 transition-colors"
          >
            {currentSymbol && (
              <>
                <currentSymbol.icon className="w-5 h-5 text-[#d0ff59]" />
                <span className="font-semibold text-white">{currentSymbol.name}</span>
                <span className="text-[#888888]">({currentSymbol.symbol.replace('USDT', '')})</span>
              </>
            )}
            <ChevronDown className={cn(
              "w-4 h-4 text-[#888888] transition-transform",
              showSymbolDropdown && "rotate-180"
            )} />
          </button>

          {showSymbolDropdown && (
            <div className="absolute top-full left-0 mt-2 w-72 bg-[#1a1a1a] border border-[#2a2a2a] rounded-xl shadow-2xl z-50">
              <div className="p-3 border-b border-[#2a2a2a]">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#888888]" />
                  <input
                    type="text"
                    placeholder="Search coins..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pl-9 pr-4 py-2 bg-[#0a0a0a] border border-[#2a2a2a] rounded-lg text-white text-sm focus:outline-none focus:border-[#d0ff59]"
                  />
                </div>
              </div>
              <div className="max-h-64 overflow-y-auto">
                {filteredSymbols.map((symbol) => (
                  <button
                    key={symbol.symbol}
                    onClick={() => {
                      onSymbolChange(symbol.symbol);
                      setShowSymbolDropdown(false);
                      setSearchQuery('');
                    }}
                    className={cn(
                      "w-full flex items-center gap-3 px-4 py-3 hover:bg-white/5 transition-colors",
                      selectedSymbol === symbol.symbol && "bg-[#d0ff59]/10"
                    )}
                  >
                    <symbol.icon className={cn(
                      "w-5 h-5",
                      selectedSymbol === symbol.symbol ? "text-[#d0ff59]" : "text-[#888888]"
                    )} />
                    <div className="text-left">
                      <div className={cn(
                        "font-medium",
                        selectedSymbol === symbol.symbol ? "text-white" : "text-[#f6f6f6]"
                      )}>
                        {symbol.name}
                      </div>
                      <div className="text-xs text-[#888888]">{symbol.symbol}</div>
                    </div>
                    {selectedSymbol === symbol.symbol && (
                      <div className="ml-auto w-2 h-2 rounded-full bg-[#d0ff59]" />
                    )}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="hidden md:flex items-center gap-6">
        <div className="flex items-center gap-3">
          <div className={cn(
            "w-2 h-2 rounded-full",
            tradingState.aiEnabled ? "bg-[#d0ff59] animate-pulse" : "bg-red-500"
          )} />
          <span className="text-sm text-[#888888]">
            AI Trading {tradingState.aiEnabled ? 'Active' : 'Paused'}
          </span>
        </div>

        <div className="flex items-center gap-2 px-3 py-1.5 bg-[#1a1a1a] rounded-lg border border-[#2a2a2a]">
          <Brain className="w-4 h-4 text-[#d0ff59]" />
          <span className="text-sm text-white">{tradingState.confidence}%</span>
          <span className="text-xs text-[#888888]">Confidence</span>
        </div>

        <div className={cn(
          "flex items-center gap-2 px-3 py-1.5 rounded-lg border",
          tradingState.marketRegime === 'TREND' ? "bg-green-500/10 border-green-500/30 text-green-400" :
          tradingState.marketRegime === 'CHOP' ? "bg-yellow-500/10 border-yellow-500/30 text-yellow-400" :
          tradingState.marketRegime === 'PANIC' ? "bg-red-500/10 border-red-500/30 text-red-400" :
          "bg-[#1a1a1a] border-[#2a2a2a] text-[#888888]"
        )}>
          {tradingState.marketRegime === 'TREND' && <TrendingUp className="w-4 h-4" />}
          {tradingState.marketRegime === 'CHOP' && <TrendingDown className="w-4 h-4" />}
          {tradingState.marketRegime === 'PANIC' && <TrendingDown className="w-4 h-4" />}
          <span className="text-sm font-medium">{tradingState.marketRegime}</span>
        </div>
      </div>

      <div className="flex items-center gap-3">
        <button className="relative p-2 hover:bg-white/10 rounded-lg transition-colors">
          <Bell className="w-5 h-5 text-[#888888]" />
          <span className="absolute top-1 right-1 w-2 h-2 bg-[#d0ff59] rounded-full" />
        </button>
        
        {/* User Profile Dropdown */}
        <div className="relative">
          <button 
            onClick={() => setShowUserDropdown(!showUserDropdown)}
            className="flex items-center gap-2 p-2 hover:bg-white/10 rounded-lg transition-colors"
          >
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#00ff88] to-[#00cc6a] flex items-center justify-center">
              <User className="w-4 h-4 text-black" />
            </div>
            {user && (
              <div className="hidden sm:block text-left">
                <p className="text-sm font-medium text-white leading-tight">{user.username}</p>
                <p className="text-xs text-[#888888] leading-tight">{user.email}</p>
              </div>
            )}
            <ChevronDown className={cn(
              "w-4 h-4 text-[#888888] transition-transform",
              showUserDropdown && "rotate-180"
            )} />
          </button>

          {showUserDropdown && (
            <div className="absolute top-full right-0 mt-2 w-64 bg-[#1a1a1a] border border-[#2a2a2a] rounded-xl shadow-2xl z-50 py-2">
              {user && (
                <div className="px-4 py-3 border-b border-[#2a2a2a]">
                  <p className="text-sm font-medium text-white">{user.username}</p>
                  <p className="text-xs text-[#888888]">{user.email}</p>
                  <p className="text-xs text-[#00ff88] mt-1">
                    Member since {new Date(user.createdAt).toLocaleDateString()}
                  </p>
                </div>
              )}
              
              <button
                onClick={handleSettingsClick}
                className="w-full flex items-center gap-3 px-4 py-3 hover:bg-white/5 transition-colors text-left"
              >
                <Settings className="w-4 h-4 text-[#888888]" />
                <span className="text-sm text-[#f6f6f6]">Settings</span>
              </button>
              
              <div className="h-px bg-[#2a2a2a] my-2" />
              
              <button
                onClick={handleLogout}
                className="w-full flex items-center gap-3 px-4 py-3 hover:bg-red-500/10 transition-colors text-left group"
              >
                <LogOut className="w-4 h-4 text-red-400 group-hover:text-red-300" />
                <span className="text-sm text-red-400 group-hover:text-red-300">Logout</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}

export default Header;
