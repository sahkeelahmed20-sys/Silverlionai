import { useState } from 'react';
import { 
  Brain, 
  Power, 
  TrendingUp, 
  AlertTriangle,
  Shield,
  Bot,
  Activity,
  Settings,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { cn } from '../lib/utils';

interface AIControlPanelProps {
  tradingState: {
    aiEnabled: boolean;
    marketRegime: string;
    confidence: number;
  };
  onAIToggle: (enabled: boolean) => void;
}

export function AIControlPanel({ tradingState, onAIToggle }: AIControlPanelProps) {
  const [showDetails, setShowDetails] = useState(false);
  const [isConfirming, setIsConfirming] = useState(false);

  const handleToggle = () => {
    if (tradingState.aiEnabled) {
      setIsConfirming(true);
    } else {
      onAIToggle(true);
    }
  };

  const confirmDisable = () => {
    onAIToggle(false);
    setIsConfirming(false);
  };

  return (
    <div className="bg-[#1a1a1a] border border-[#2a2a2a] rounded-xl overflow-hidden">
      <div className="p-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className={cn(
            "w-10 h-10 rounded-xl flex items-center justify-center transition-colors",
            tradingState.aiEnabled ? "bg-[#d0ff59]/20" : "bg-red-500/20"
          )}>
            <Brain className={cn(
              "w-5 h-5",
              tradingState.aiEnabled ? "text-[#d0ff59]" : "text-red-500"
            )} />
          </div>
          <div>
            <h3 className="font-semibold text-white">AI Trading Engine</h3>
            <div className="flex items-center gap-2 text-sm">
              <span className={cn(
                "w-2 h-2 rounded-full",
                tradingState.aiEnabled ? "bg-[#d0ff59] animate-pulse" : "bg-red-500"
              )} />
              <span className={tradingState.aiEnabled ? "text-[#d0ff59]" : "text-red-400"}>
                {tradingState.aiEnabled ? 'Active & Trading' : 'Paused'}
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {tradingState.aiEnabled && (
            <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 bg-[#0a0a0a] rounded-lg border border-[#2a2a2a]">
              <Activity className="w-4 h-4 text-[#d0ff59]" />
              <span className="text-sm text-white">{tradingState.confidence}%</span>
              <span className="text-xs text-[#888888]">Confidence</span>
            </div>
          )}

          <button
            onClick={handleToggle}
            className={cn(
              "relative w-14 h-8 rounded-full transition-colors duration-300",
              tradingState.aiEnabled ? "bg-[#d0ff59]" : "bg-[#2a2a2a]"
            )}
          >
            <div className={cn(
              "absolute top-1 w-6 h-6 rounded-full bg-white shadow-lg transition-transform duration-300",
              tradingState.aiEnabled ? "left-7" : "left-1"
            )}>
              <Power className={cn(
                "w-4 h-4 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2",
                tradingState.aiEnabled ? "text-[#d0ff59]" : "text-[#888888]"
              )} />
            </div>
          </button>

          <button
            onClick={() => setShowDetails(!showDetails)}
            className="p-2 hover:bg-white/10 rounded-lg transition-colors"
          >
            {showDetails ? (
              <ChevronUp className="w-5 h-5 text-[#888888]" />
            ) : (
              <ChevronDown className="w-5 h-5 text-[#888888]" />
            )}
          </button>
        </div>
      </div>

      {isConfirming && (
        <div className="mx-4 mb-4 p-4 bg-red-500/10 border border-red-500/30 rounded-lg">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-red-500 mt-0.5" />
            <div className="flex-1">
              <p className="text-sm text-red-400 font-medium">Disable AI Trading?</p>
              <p className="text-xs text-red-300/70 mt-1">
                This will stop all automated trades. Open positions will remain active.
              </p>
              <div className="flex gap-2 mt-3">
                <button
                  onClick={confirmDisable}
                  className="px-3 py-1.5 bg-red-500 text-white text-sm rounded-lg hover:bg-red-600 transition-colors"
                >
                  Disable
                </button>
                <button
                  onClick={() => setIsConfirming(false)}
                  className="px-3 py-1.5 bg-[#2a2a2a] text-white text-sm rounded-lg hover:bg-[#3a3a3a] transition-colors"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {showDetails && (
        <div className="border-t border-[#2a2a2a] p-4 space-y-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <AgentStatus 
              name="Technical Analyst"
              icon={TrendingUp}
              status={tradingState.aiEnabled ? 'active' : 'paused'}
              description="RSI, MACD, Patterns"
            />
            <AgentStatus 
              name="Sentiment Analyzer"
              icon={Bot}
              status={tradingState.aiEnabled ? 'active' : 'paused'}
              description="News & Social Media"
            />
            <AgentStatus 
              name="Whale Tracker"
              icon={Shield}
              status={tradingState.aiEnabled ? 'active' : 'paused'}
              description="On-chain Analysis"
            />
            <AgentStatus 
              name="ML Predictor"
              icon={Brain}
              status={tradingState.aiEnabled ? 'active' : 'paused'}
              description="LSTM Neural Network"
            />
          </div>

          <div className="flex items-start gap-3 p-3 bg-[#0a0a0a] rounded-lg">
            <Shield className="w-5 h-5 text-[#d0ff59] mt-0.5" />
            <div>
              <p className="text-sm text-white font-medium">Safety Mechanisms Active</p>
              <ul className="text-xs text-[#888888] mt-1 space-y-1">
                <li>• Max daily loss limit: 5% of portfolio</li>
                <li>• Auto stop-loss on all positions</li>
                <li>• Kill switch on extreme volatility</li>
                <li>• Position sizing based on confidence</li>
              </ul>
            </div>
          </div>

          <button className="w-full flex items-center justify-center gap-2 p-3 bg-[#2a2a2a] hover:bg-[#3a3a3a] rounded-lg transition-colors text-sm text-[#888888]">
            <Settings className="w-4 h-4" />
            Configure AI Parameters
          </button>
        </div>
      )}
    </div>
  );
}

interface AgentStatusProps {
  name: string;
  icon: React.ElementType;
  status: 'active' | 'paused' | 'error';
  description: string;
}

function AgentStatus({ name, icon: Icon, status, description }: AgentStatusProps) {
  return (
    <div className={cn(
      "p-3 rounded-lg border transition-colors",
      status === 'active' ? "bg-[#d0ff59]/5 border-[#d0ff59]/20" : 
      status === 'error' ? "bg-red-500/5 border-red-500/20" :
      "bg-[#2a2a2a]/50 border-[#2a2a2a]"
    )}>
      <div className="flex items-center gap-2 mb-1">
        <Icon className={cn(
          "w-4 h-4",
          status === 'active' ? "text-[#d0ff59]" : 
          status === 'error' ? "text-red-500" :
          "text-[#888888]"
        )} />
        <span className={cn(
          "text-sm font-medium",
          status === 'active' ? "text-white" : 
          status === 'error' ? "text-red-400" :
          "text-[#888888]"
        )}>{name}</span>
      </div>
      <p className="text-xs text-[#666666]">{description}</p>
      <div className="mt-2 flex items-center gap-1">
        <span className={cn(
          "w-1.5 h-1.5 rounded-full",
          status === 'active' ? "bg-[#d0ff59]" : 
          status === 'error' ? "bg-red-500" :
          "bg-[#555555]"
        )} />
        <span className={cn(
          "text-xs capitalize",
          status === 'active' ? "text-[#d0ff59]" : 
          status === 'error' ? "text-red-400" :
          "text-[#666666]"
        )}>{status}</span>
      </div>
    </div>
  );
}
