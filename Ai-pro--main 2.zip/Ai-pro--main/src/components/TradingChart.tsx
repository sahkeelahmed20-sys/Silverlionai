import React, { useEffect, useRef, useState, useCallback } from 'react';
import { createChart, type IChartApi, type ISeriesApi, type CandlestickData, type Time } from 'lightweight-charts';
import { Loader2 } from 'lucide-react';

interface TradingChartProps {
  symbol: string;
  interval?: string;
  height?: number;
  data?: any[];
  onCandleUpdate?: (candle: any) => void;
}

const TradingChart: React.FC<TradingChartProps> = ({ 
  symbol, 
  interval = '1m', 
  height = 400,
  data = [],
  onCandleUpdate 
}) => {
  const chartContainerRef = useRef<HTMLDivElement>(null);
  const chartRef = useRef<IChartApi | null>(null);
  const candlestickSeriesRef = useRef<ISeriesApi<"Candlestick"> | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [hoverData, setHoverData] = useState<any>(null);

  // Initialize chart
  useEffect(() => {
    if (!chartContainerRef.current) return;

    // Create chart with Binance-like dark theme
    const chart = createChart(chartContainerRef.current, {
      layout: {
        background: { color: '#0b0b0b' },
        textColor: '#888888',
        fontSize: 12,
        fontFamily: "'Inter', sans-serif",
      },
      grid: {
        vertLines: { color: '#1a1a1a' },
        horzLines: { color: '#1a1a1a' },
      },
      crosshair: {
        mode: 1,
        vertLine: {
          color: '#555555',
          width: 1,
          style: 2,
          labelBackgroundColor: '#1a1a1a',
        },
        horzLine: {
          color: '#555555',
          width: 1,
          style: 2,
          labelBackgroundColor: '#1a1a1a',
        },
      },
      rightPriceScale: {
        borderColor: '#222222',
        scaleMargins: {
          top: 0.1,
          bottom: 0.1,
        },
      },
      timeScale: {
        borderColor: '#222222',
        timeVisible: true,
        secondsVisible: false,
      },
      handleScroll: {
        vertTouchDrag: false,
      },
    });

    // Create candlestick series with Binance colors - v3 API
    const candlestickSeries = chart.addCandlestickSeries({
      upColor: '#26a69a',
      downColor: '#ef5350',
      borderVisible: false,
      wickUpColor: '#26a69a',
      wickDownColor: '#ef5350',
      priceFormat: {
        type: 'price',
        precision: 2,
        minMove: 0.01,
      },
    });

    chartRef.current = chart;
    candlestickSeriesRef.current = candlestickSeries;

    // Handle crosshair move for hover data
    chart.subscribeCrosshairMove((param) => {
      if (param.time && param.point) {
        const seriesData = param.seriesData.get(candlestickSeries) as CandlestickData | undefined;
        if (seriesData) {
          setHoverData({
            time: String(typeof seriesData.time === 'number' ? seriesData.time * 1000 : Date.now()),
            open: seriesData.open,
            high: seriesData.high,
            low: seriesData.low,
            close: seriesData.close,
          });
        }
      }
    });

    // Handle resize
    const handleResize = () => {
      if (chartContainerRef.current && chartRef.current) {
        chartRef.current.applyOptions({
          width: chartContainerRef.current.clientWidth,
          height: height
        });
      }
    };

    window.addEventListener('resize', handleResize);
    handleResize();

    setIsLoading(false);

    return () => {
      window.removeEventListener('resize', handleResize);
      chart.remove();
    };
  }, [height]);

  // Update data when it changes
  useEffect(() => {
    if (candlestickSeriesRef.current && data.length > 0) {
      const formattedData: CandlestickData[] = data.map(candle => ({
        time: (new Date(candle.time).getTime() / 1000) as Time,
        open: candle.open,
        high: candle.high,
        low: candle.low,
        close: candle.close,
      }));

      candlestickSeriesRef.current.setData(formattedData);
      chartRef.current?.timeScale().fitContent();
    }
  }, [data]);

  // Subscribe to real-time updates
  useEffect(() => {
    if (!symbol || !candlestickSeriesRef.current) return;

    const cleanup = subscribeToKlines(symbol, interval, (candle) => {
      if (candlestickSeriesRef.current) {
        const candlestickData: CandlestickData = {
          time: (candle.time / 1000) as Time,
          open: candle.open,
          high: candle.high,
          low: candle.low,
          close: candle.close,
        };

        candlestickSeriesRef.current.update(candlestickData);

        if (onCandleUpdate) {
          onCandleUpdate(candle);
        }
      }
    });

    return () => cleanup();
  }, [symbol, interval, onCandleUpdate]);

  // Helper function to subscribe to klines
  const subscribeToKlines = useCallback((sym: string, int: string, callback: (candle: any) => void) => {
    const formattedSymbol = sym.toUpperCase().endsWith('USDT')
      ? sym.toUpperCase()
      : `${sym.toUpperCase()}USDT`;

    const url = `wss://stream.binance.com:9443/ws/${formattedSymbol.toLowerCase()}@kline_${int}`;
    const ws = new WebSocket(url);

    ws.onopen = () => {
      console.log(`Chart WebSocket connected for ${formattedSymbol} ${int}`);
    };

    ws.onmessage = (event) => {
      const data = JSON.parse(event.data);
      if (data.k) {
        callback({
          time: data.k.t,
          open: parseFloat(data.k.o),
          high: parseFloat(data.k.h),
          low: parseFloat(data.k.l),
          close: parseFloat(data.k.c),
          volume: parseFloat(data.k.v),
          isClosed: data.k.x,
        });
      }
    };

    ws.onerror = (error) => {
      console.error('Chart WebSocket error:', error);
    };

    return () => {
      ws.close();
    };
  }, []);

  return (
    <div className="relative w-full bg-[#0b0b0b] rounded-lg overflow-hidden border border-[#1a1a1a]">
      {/* Header with symbol info */}
      <div className="flex items-center justify-between px-4 py-2 border-b border-[#1a1a1a]">
        <div className="flex items-center gap-2">
          <h3 className="text-white font-semibold">
            {symbol.replace('/USDT', '')}/USDT
          </h3>
          <span className="text-xs text-[#888888] bg-[#1a1a1a] px-2 py-0.5 rounded">
            Perpetual
          </span>
        </div>
        
        {hoverData && (
          <div className="flex items-center gap-4 text-xs">
            <span className="text-[#888888]">
              O <span className={hoverData.close >= hoverData.open ? 'text-[#0ecb81]' : 'text-[#f6465d]'}>
                {hoverData.open.toFixed(2)}
              </span>
            </span>
            <span className="text-[#888888]">
              H <span className="text-white">{hoverData.high.toFixed(2)}</span>
            </span>
            <span className="text-[#888888]">
              L <span className="text-white">{hoverData.low.toFixed(2)}</span>
            </span>
            <span className="text-[#888888]">
              C <span className={hoverData.close >= hoverData.open ? 'text-[#0ecb81]' : 'text-[#f6465d]'}>
                {hoverData.close.toFixed(2)}
              </span>
            </span>
          </div>
        )}
      </div>

      {/* Loading state */}
      {isLoading && (
        <div className="absolute inset-0 flex items-center justify-center bg-[#0b0b0b] z-10">
          <Loader2 className="w-8 h-8 text-[#d0ff59] animate-spin" />
        </div>
      )}

      {/* Chart container */}
      <div ref={chartContainerRef} className="w-full" style={{ height }} />
    </div>
  );
};

export default TradingChart;
