import { useState, useEffect, useCallback, useRef } from 'react';
import { binanceWS } from '../services/binanceWebSocket';
import type { Position, Trade } from '../types';

// Re-export Position type
export type { Position };

interface TradingConfig {
  minHoldTimeMs: number;
  cooldownMs: number;
  maxSlPercent: number;
  maxTpPercent: number;
  minSlPercent: number;
  minTpPercent: number;
}

const DEFAULT_CONFIG: TradingConfig = {
  minHoldTimeMs: 5 * 60 * 1000,
  cooldownMs: 10 * 60 * 1000,
  maxSlPercent: 10,
  maxTpPercent: 20,
  minSlPercent: 0.5,
  minTpPercent: 1,
};

export function useDemoTrading(config: Partial<TradingConfig> = {}) {
  const tradingConfig = { ...DEFAULT_CONFIG, ...config };
  
  const [positions, setPositions] = useState<Position[]>([]);
  const [prices, setPrices] = useState<Record<string, number>>({});
  const [changes, setChanges] = useState<Record<string, number>>({});
  const [trades, setTrades] = useState<Trade[]>([]);
  const [balance, setBalance] = useState(100000);
  const [equity, setEquity] = useState(100000);
  
  const lastTradeTimeRef = useRef<Record<string, number>>({});
  const positionOpenTimeRef = useRef<Record<number, number>>({});

  useEffect(() => {
    const unsubscribe = binanceWS.subscribe((symbol: string, price: number, change24h: number) => {
      setPrices(prev => ({ ...prev, [symbol]: price }));
      setChanges(prev => ({ ...prev, [symbol]: change24h }));
    });

    binanceWS.connect();

    return () => {
      unsubscribe();
      binanceWS.disconnect();
    };
  }, []);

  useEffect(() => {
    setPositions(prev => prev.map(pos => {
      const currentPrice = prices[pos.symbol] || pos.currentPrice;
      const priceDiff = currentPrice - pos.entryPrice;
      const multiplier = pos.side === 'LONG' ? 1 : -1;
      const pnl = priceDiff * pos.size * multiplier;
      const pnlPercent = (priceDiff / pos.entryPrice) * 100 * multiplier;

      return {
        ...pos,
        currentPrice,
        pnl,
        pnlPercent
      };
    }));
  }, [prices]);

  const closePosition = useCallback((positionId: number, reason?: string) => {
    setPositions(prev => {
      const pos = prev.find(p => p.id === positionId);
      if (!pos) return prev;

      const priceDiff = pos.currentPrice - pos.entryPrice;
      const multiplier = pos.side === 'LONG' ? 1 : -1;
      const finalPnl = priceDiff * pos.size * multiplier;
      const finalPnlPercent = (priceDiff / pos.entryPrice) * 100 * multiplier;

      const margin = pos.entryPrice * pos.size / (pos.leverage || 1);
      setBalance(b => b + margin + finalPnl);

      const newTrade: Trade = {
        id: Date.now(),
        symbol: pos.symbol,
        side: pos.side === 'LONG' ? 'SELL' : 'BUY',
        type: 'CLOSE',
        price: pos.currentPrice,
        size: pos.size,
        pnl: finalPnl,
        pnlPercent: finalPnlPercent,
        leverage: pos.leverage,
        timestamp: new Date().toISOString()
      };
      setTrades(t => [newTrade, ...t]);

      delete positionOpenTimeRef.current[positionId];
      
      const closeReason = reason || (finalPnl > 0 ? 'Take Profit' : finalPnl < 0 ? 'Stop Loss' : 'Manual');
      console.log(`[Trade] Closed ${pos.side} ${pos.symbol} @ $${pos.currentPrice} Reason: ${closeReason} PnL: $${finalPnl.toFixed(2)} (${finalPnlPercent.toFixed(2)}%)`);

      return prev.filter(p => p.id !== positionId);
    });
  }, []);

  // Auto close positions on SL/TP with minimum hold time check
  useEffect(() => {
    positions.forEach(pos => {
      const now = Date.now();
      const openTime = positionOpenTimeRef.current[pos.id] || 0;
      const holdTime = now - openTime;
      
      if (holdTime < tradingConfig.minHoldTimeMs) {
        return;
      }

      const currentPrice = prices[pos.symbol];
      if (!currentPrice) return;

      let shouldClose = false;
      let closeReason = '';

      if (pos.side === 'LONG') {
        if (pos.stopLoss && currentPrice <= pos.stopLoss) {
          shouldClose = true;
          closeReason = 'Stop Loss';
        } else if (pos.takeProfit && currentPrice >= pos.takeProfit) {
          shouldClose = true;
          closeReason = 'Take Profit';
        }
      } else {
        if (pos.stopLoss && currentPrice >= pos.stopLoss) {
          shouldClose = true;
          closeReason = 'Stop Loss';
        } else if (pos.takeProfit && currentPrice <= pos.takeProfit) {
          shouldClose = true;
          closeReason = 'Take Profit';
        }
      }

      if (shouldClose) {
        console.log(`[AutoClose] ${pos.symbol} ${pos.side} hit ${closeReason} @ $${currentPrice} after ${(holdTime/1000).toFixed(0)}s`);
        closePosition(pos.id, closeReason);
      }
    });
  }, [positions, prices, tradingConfig.minHoldTimeMs, closePosition]);

  useEffect(() => {
    const totalPnl = positions.reduce((sum, pos) => sum + (pos.pnl || 0), 0);
    setEquity(balance + totalPnl);
  }, [positions, balance]);

  const canOpenPosition = useCallback((symbol: string): boolean => {
    const lastTrade = lastTradeTimeRef.current[symbol] || 0;
    const timeSinceLastTrade = Date.now() - lastTrade;
    const hasOpenPosition = positions.some(p => p.symbol === symbol);
    
    if (hasOpenPosition) {
      console.log(`[Cooldown] ${symbol}: Already has open position`);
      return false;
    }
    
    if (timeSinceLastTrade < tradingConfig.cooldownMs) {
      const remaining = Math.ceil((tradingConfig.cooldownMs - timeSinceLastTrade) / 1000);
      console.log(`[Cooldown] ${symbol}: ${remaining}s remaining`);
      return false;
    }
    
    return true;
  }, [positions, tradingConfig.cooldownMs]);

  const validateSlTp = useCallback((
    entryPrice: number,
    side: 'LONG' | 'SHORT',
    stopLoss: number | undefined,
    takeProfit: number | undefined
  ): { stopLoss: number; takeProfit: number } | null => {
    
    if (stopLoss) {
      const slPercent = (Math.abs(entryPrice - stopLoss) / entryPrice) * 100;
      
      if (slPercent > tradingConfig.maxSlPercent) {
        console.warn(`[Validate] SL too far: ${slPercent.toFixed(2)}% > max ${tradingConfig.maxSlPercent}%`);
        return null;
      }
      if (slPercent < tradingConfig.minSlPercent) {
        console.warn(`[Validate] SL too tight: ${slPercent.toFixed(2)}% < min ${tradingConfig.minSlPercent}%`);
        return null;
      }

      if (side === 'LONG' && stopLoss >= entryPrice) {
        console.warn(`[Validate] LONG SL must be below entry`);
        return null;
      }
      if (side === 'SHORT' && stopLoss <= entryPrice) {
        console.warn(`[Validate] SHORT SL must be above entry`);
        return null;
      }
    }

    if (takeProfit) {
      const tpPercent = (Math.abs(takeProfit - entryPrice) / entryPrice) * 100;
      
      if (tpPercent > tradingConfig.maxTpPercent) {
        console.warn(`[Validate] TP too far: ${tpPercent.toFixed(2)}% > max ${tradingConfig.maxTpPercent}%`);
        return null;
      }
      if (tpPercent < tradingConfig.minTpPercent) {
        console.warn(`[Validate] TP too close: ${tpPercent.toFixed(2)}% < min ${tradingConfig.minTpPercent}%`);
        return null;
      }

      if (side === 'LONG' && takeProfit <= entryPrice) {
        console.warn(`[Validate] LONG TP must be above entry`);
        return null;
      }
      if (side === 'SHORT' && takeProfit >= entryPrice) {
        console.warn(`[Validate] SHORT TP must be below entry`);
        return null;
      }
    }

    const finalStopLoss = stopLoss || (side === 'LONG' 
      ? entryPrice * (1 - tradingConfig.minSlPercent / 100)
      : entryPrice * (1 + tradingConfig.minSlPercent / 100));
      
    const finalTakeProfit = takeProfit || (side === 'LONG'
      ? entryPrice * (1 + tradingConfig.minTpPercent / 100)
      : entryPrice * (1 - tradingConfig.minTpPercent / 100));

    return { stopLoss: finalStopLoss, takeProfit: finalTakeProfit };
  }, [tradingConfig]);

  const openPosition = useCallback((
    symbol: string, 
    side: 'LONG' | 'SHORT', 
    size: number, 
    leverage: number = 1,
    stopLoss?: number, 
    takeProfit?: number
  ): boolean => {
    if (!canOpenPosition(symbol)) {
      return false;
    }

    const currentPrice = prices[symbol];
    if (!currentPrice) {
      console.warn(`[Trade] Price not available for ${symbol}`);
      return false;
    }

    const validatedSlTp = validateSlTp(currentPrice, side, stopLoss, takeProfit);
    if (!validatedSlTp) {
      console.warn(`[Trade] Invalid SL/TP provided for ${symbol}, using defaults`);
      const fallbackSl = side === 'LONG' 
        ? currentPrice * 0.995 
        : currentPrice * 1.005;
      const fallbackTp = side === 'LONG'
        ? currentPrice * 1.01
        : currentPrice * 0.99;
      
      return openPosition(symbol, side, size, leverage, fallbackSl, fallbackTp);
    }

    const { stopLoss: finalStopLoss, takeProfit: finalTakeProfit } = validatedSlTp;

    const notional = currentPrice * size;
    const margin = notional / leverage;
    
    if (margin > balance) {
      console.warn(`[Trade] Insufficient balance: need $${margin.toFixed(2)}, have $${balance.toFixed(2)}`);
      return false;
    }

    const newPosition: Position = {
      id: Date.now(),
      symbol,
      side,
      size,
      entryPrice: currentPrice,
      currentPrice,
      pnl: 0,
      pnlPercent: 0,
      stopLoss: finalStopLoss,
      takeProfit: finalTakeProfit,
      leverage,
      margin,
      timestamp: new Date().toISOString()
    };

    positionOpenTimeRef.current[newPosition.id] = Date.now();
    lastTradeTimeRef.current[symbol] = Date.now();

    setPositions(prev => [...prev, newPosition]);
    setBalance(prev => prev - margin);

    const newTrade: Trade = {
      id: Date.now(),
      symbol,
      side: side === 'LONG' ? 'BUY' : 'SELL',
      type: 'OPEN',
      price: currentPrice,
      size,
      leverage,
      timestamp: new Date().toISOString()
    };
    setTrades(prev => [newTrade, ...prev]);
    
    const slPercent = ((Math.abs(currentPrice - finalStopLoss) / currentPrice) * 100).toFixed(2);
    const tpPercent = ((Math.abs(finalTakeProfit - currentPrice) / currentPrice) * 100).toFixed(2);
    
    console.log(`[Trade] Opened ${side} ${symbol} @ $${currentPrice} SL: $${finalStopLoss.toFixed(2)} (${slPercent}%) TP: $${finalTakeProfit.toFixed(2)} (${tpPercent}%)`);
    return true;
  }, [prices, balance, canOpenPosition, validateSlTp]);

  const closeAllPositions = useCallback(() => {
    const positionIds = positions.map(p => p.id);
    positionIds.forEach(id => closePosition(id, 'Manual Close All'));
  }, [positions, closePosition]);

  const getPositionStats = useCallback(() => {
    const closedTrades = trades.filter(t => t.type === 'CLOSE');
    const totalTrades = closedTrades.length;
    const winningTrades = closedTrades.filter(t => (t.pnl || 0) > 0).length;
    const totalPnl = closedTrades.reduce((sum, t) => sum + (t.pnl || 0), 0);
    
    return {
      totalTrades,
      winRate: totalTrades > 0 ? (winningTrades / totalTrades) * 100 : 0,
      totalPnl,
      avgTrade: totalTrades > 0 ? totalPnl / totalTrades : 0,
      openPositions: positions.length
    };
  }, [trades, positions]);

  return {
    positions,
    prices,
    changes,
    trades,
    balance,
    equity,
    openPosition,
    closePosition,
    closeAllPositions,
    canOpenPosition,
    getPositionStats,
    isConnected: binanceWS.getStatus()
  };
}
