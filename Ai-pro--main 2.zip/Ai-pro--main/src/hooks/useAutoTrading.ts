import { useEffect, useRef, useCallback } from 'react';
import { aiEngine, type AIAnalysis } from '../services/aiEngine';
import { useDemoTrading } from './useDemoTrading';
import type { CandleData } from '../types';

const TOP_10_COINS = ['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'BNBUSDT', 'ADAUSDT', 'XRPUSDT', 'DOTUSDT', 'DOGEUSDT', 'AVAXUSDT', 'LINKUSDT'];

interface AutoTradingConfig {
  enabled: boolean;
  confidenceThreshold: number;
  maxPositions: number;
  positionSize: number;
  leverage: number;
  scanIntervalMs: number;
}

export function useAutoTrading(config: AutoTradingConfig) {
  const { 
    positions, 
    openPosition, 
    canOpenPosition, 
    trades,
    balance 
  } = useDemoTrading();
  
  const scanningRef = useRef(false);
  const lastScanRef = useRef<Record<string, number>>({});
  const analysisCacheRef = useRef<Record<string, AIAnalysis>>({});

  // Execute a single AI signal
  const executeSignal = useCallback((analysis: AIAnalysis, symbol: string): boolean => {
    // Skip if confidence too low
    if (analysis.confidence < config.confidenceThreshold) {
      console.log(`[AutoTrade] ${symbol} confidence ${analysis.confidence.toFixed(1)}% below threshold ${config.confidenceThreshold}%`);
      return false;
    }

    // Skip HOLD signals
    if (analysis.signal === 'HOLD') {
      console.log(`[AutoTrade] ${symbol} signal is HOLD, skipping`);
      return false;
    }

    // Check if we can open position (cooldown, no existing position)
    if (!canOpenPosition(symbol)) {
      return false;
    }

    // Check max positions
    if (positions.length >= config.maxPositions) {
      console.log(`[AutoTrade] Max positions (${config.maxPositions}) reached`);
      return false;
    }

    // Determine side
    const side = analysis.signal === 'BUY' ? 'LONG' : 'SHORT';

    // Calculate position size based on available balance
    const availableBalance = balance;
    const riskPerTrade = 0.02; // Risk 2% per trade
    const riskAmount = availableBalance * riskPerTrade;
    
    // Calculate size based on stop loss distance
    const slDistance = Math.abs(analysis.entry - analysis.stopLoss);
    const slPercent = slDistance / analysis.entry;
    
    if (slPercent === 0) {
      console.warn(`[AutoTrade] ${symbol} invalid SL distance`);
      return false;
    }

    // Position size = Risk Amount / (SL Distance * Leverage)
    const notional = riskAmount / slPercent;
    const size = notional / analysis.entry;
    
    // Round size to appropriate decimals
    const roundedSize = Math.max(0.001, Math.floor(size * 1000) / 1000);

    console.log(`[AutoTrade] Executing ${side} ${symbol}:
      Entry: $${analysis.entry.toFixed(2)}
      Size: ${roundedSize}
      Leverage: ${config.leverage}x
      SL: $${analysis.stopLoss.toFixed(2)} (${(slPercent * 100).toFixed(2)}%)
      TP: $${analysis.takeProfit.toFixed(2)} (${(Math.abs(analysis.takeProfit - analysis.entry) / analysis.entry * 100).toFixed(2)}%)
      Confidence: ${analysis.confidence.toFixed(1)}%
      R:R: ${analysis.riskReward.toFixed(2)}`);

    // Open position with AI-calculated SL/TP
    const success = openPosition(
      symbol,
      side,
      roundedSize,
      config.leverage,
      analysis.stopLoss,
      analysis.takeProfit
    );

    if (success) {
      console.log(`[AutoTrade] ✅ ${side} ${symbol} executed successfully`);
    } else {
      console.log(`[AutoTrade] ❌ ${side} ${symbol} failed to execute`);
    }

    return success;
  }, [config, positions.length, balance, canOpenPosition, openPosition]);

  // Scan all coins for signals
  const scanCoins = useCallback(async () => {
    if (scanningRef.current) return;
    if (!config.enabled) return;
    
    scanningRef.current = true;
    console.log('[AutoTrade] 🔍 Scanning 10 coins for 80%+ signals...');

    let executed = 0;
    let skipped = 0;
    let inCooldown = 0;

    for (const symbol of TOP_10_COINS) {
      // Check cooldown between scans for same coin
      const lastScan = lastScanRef.current[symbol] || 0;
      const timeSinceScan = Date.now() - lastScan;
      const minScanInterval = 60000; // 1 minute between scans per coin
      
      if (timeSinceScan < minScanInterval) {
        inCooldown++;
        continue;
      }

      try {
        // Fetch candles
        const response = await fetch(
          `https://api.binance.com/api/v3/klines?symbol=${symbol}&interval=1h&limit=100`
        );
        
        if (!response.ok) continue;
        
        const klines = await response.json();
        const candles: CandleData[] = klines.map((k: any[]) => ({
          time: k[0] / 1000,
          open: parseFloat(k[1]),
          high: parseFloat(k[2]),
          low: parseFloat(k[3]),
          close: parseFloat(k[4]),
          volume: parseFloat(k[5]),
        }));

        // Update AI engine
        aiEngine.updateCandles(symbol, candles);
        
        // Get analysis
        const currentPrice = candles[candles.length - 1].close;
        const analysis = await aiEngine.analyze(symbol, currentPrice);
        
        analysisCacheRef.current[symbol] = analysis;
        lastScanRef.current[symbol] = Date.now();

        // Execute if signal is strong
        if (analysis.signal !== 'HOLD' && analysis.confidence >= config.confidenceThreshold) {
          const executed_this = executeSignal(analysis, symbol);
          if (executed_this) {
            executed++;
          } else {
            skipped++;
          }
        } else {
          skipped++;
        }
      } catch (error) {
        console.error(`[AutoTrade] Error scanning ${symbol}:`, error);
        skipped++;
      }
    }

    console.log(`[AutoTrade] ✅ Scan complete: ${executed} executed, ${skipped} skipped, ${inCooldown} in cooldown`);
    scanningRef.current = false;
  }, [config.enabled, config.confidenceThreshold, executeSignal]);

  // Auto-scan interval
  useEffect(() => {
    if (!config.enabled) return;

    // Initial scan
    scanCoins();

    // Set up interval
    const interval = setInterval(scanCoins, config.scanIntervalMs);

    return () => clearInterval(interval);
  }, [config.enabled, config.scanIntervalMs, scanCoins]);

  return {
    scanning: scanningRef.current,
    positions,
    trades,
    scanCoins,
    analysisCache: analysisCacheRef.current,
  };
}
