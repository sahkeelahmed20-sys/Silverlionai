import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import type { Position, Trade, TradingState, PersistedTradingState } from '@/types';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

const STORAGE_KEYS = {
  TRADING_STATE: 'silverlion_trading_state',
  POSITIONS: 'silverlion_positions',
  TRADE_HISTORY: 'silverlion_trade_history',
  SETTINGS: 'silverlion_settings',
  LAST_UPDATE: 'silverlion_last_update'
} as const;

export function saveTradingState(state: {
  tradingState: TradingState;
  positions: Position[];
  tradeHistory: Trade[];
  portfolioValue: number;
}): void {
  try {
    const data: PersistedTradingState = {
      tradingState: state.tradingState,
      positions: state.positions,
      tradeHistory: state.tradeHistory,
      portfolioValue: state.portfolioValue,
      lastUpdated: new Date().toISOString(),
      settings: {
        initialCapital: state.tradingState.demoBalance,
        currentBalance: state.portfolioValue,
        totalPnL: state.tradeHistory.reduce((acc, t) => acc + (t.pnl || 0), 0)
      }
    };
    localStorage.setItem(STORAGE_KEYS.TRADING_STATE, JSON.stringify(data));
    localStorage.setItem(STORAGE_KEYS.LAST_UPDATE, new Date().toISOString());
  } catch (error) {
    console.error('Failed to save trading state:', error);
  }
}

export function loadTradingState(): PersistedTradingState | null {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.TRADING_STATE);
    if (data) {
      return JSON.parse(data) as PersistedTradingState;
    }
  } catch (error) {
    console.error('Failed to load trading state:', error);
  }
  return null;
}

export function savePositions(positions: Position[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.POSITIONS, JSON.stringify(positions));
  } catch (error) {
    console.error('Failed to save positions:', error);
  }
}

export function loadPositions(): Position[] {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.POSITIONS);
    return data ? JSON.parse(data) : [];
  } catch (error) {
    console.error('Failed to load positions:', error);
    return [];
  }
}

export function saveTradeHistory(trades: Trade[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.TRADE_HISTORY, JSON.stringify(trades));
  } catch (error) {
    console.error('Failed to save trade history:', error);
  }
}

export function loadTradeHistory(): Trade[] {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.TRADE_HISTORY);
    return data ? JSON.parse(data) : [];
  } catch (error) {
    console.error('Failed to load trade history:', error);
    return [];
  }
}

export function clearTradingData(): void {
  try {
    Object.values(STORAGE_KEYS).forEach(key => {
      localStorage.removeItem(key);
    });
  } catch (error) {
    console.error('Failed to clear trading data:', error);
  }
}

export function hasPersistedData(): boolean {
  return !!localStorage.getItem(STORAGE_KEYS.TRADING_STATE);
}

export function calculatePnL(
  entryPrice: number,
  currentPrice: number,
  size: number,
  side: 'LONG' | 'SHORT'
): { pnl: number; pnlPercent: number } {
  const priceDiff = side === 'LONG'
    ? currentPrice - entryPrice
    : entryPrice - currentPrice;

  const pnl = priceDiff * size;
  const pnlPercent = (priceDiff / entryPrice) * 100;

  return { pnl, pnlPercent };
}

export function formatCurrency(value: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  }).format(value);
}

export function formatPercent(value: number): string {
  const sign = value >= 0 ? '+' : '';
  return `${sign}${value.toFixed(2)}%`;
}

export function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}

export function formatTime(timestamp: string | number): string {
  const date = new Date(timestamp);
  return date.toLocaleTimeString('en-US', {
    hour12: false,
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit'
  });
}

export function getCurrentTimestamp(): string {
  return new Date().toISOString();
}

export function timeAgo(timestamp: string): string {
  const seconds = Math.floor((new Date().getTime() - new Date(timestamp).getTime()) / 1000);

  if (seconds < 60) return `${seconds}s ago`;
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  return `${days}d ago`;
}
 