import { useState, useEffect, useCallback, useRef } from 'react';
import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { MarketOverview } from './sections/MarketOverview';
import AISignals from './sections/AISignals';
import { DemoTrading } from './sections/DemoTrading';
import Backtesting from './sections/Backtesting';
import { StrategyComparison } from './sections/StrategyComparison';
import { NewsAnalysis } from './sections/NewsAnalysis';
import { BitnodesAnalysis } from './sections/BitnodesAnalysis';
import { AIControlPanel } from './components/AIControlPanel';
import RiskManagement from './sections/RiskManagement';
import AIPerformance from './sections/AIPerformance';
import WhaleTracking from './sections/WhaleTracking';
import MarketData from './sections/MarketData';
import Settings from './sections/Settings';
import Login from './pages/Login';
import Register from './pages/Register';
import { Toaster } from './components/ui/toaster';
import { AuthProvider, useAuth } from './context/AuthContext';
import { ProtectedRoute } from './components/ProtectedRoute';
import type { CandleData, MarketRegime } from './types';

// Lazy load heavy services to prevent mobile crash
const loadServices = async () => {
  const [{ aiEngine }, { whaleTracker }, { agentAdapter }] = await Promise.all([
    import('./services/aiEngine'),
    import('./services/whaleTracker'),
    import('./agents/integration/PlatformAdapter')
  ]);
  return { aiEngine, whaleTracker, agentAdapter };
};

export interface TradingState {
  aiEnabled: boolean;
  marketRegime: MarketRegime;
  confidence: number;
  ensembleScore: number;
  selectedSymbol: string;
  selectedTimeframe: string;
}

export interface ActiveSignal {
  symbol: string;
  type: 'BUY' | 'SELL' | 'HOLD';
  confidence: number;
  entry: number;
  stopLoss: number;
  takeProfit: number;
  riskReward: number;
  timestamp: string;
  executed: boolean;
}

// Main App Content Component
function AppContent() {
  const [activeSection, setActiveSection] = useState('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [agentSystemActive, setAgentSystemActive] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const location = useLocation();
  
  // Refs to prevent memory leaks
  const abortControllerRef = useRef<AbortController | null>(null);
  const servicesRef = useRef<any>(null);
  
  // Load balance from localStorage or default to 100000
  const [balance, setBalance] = useState(() => {
    try {
      const saved = localStorage.getItem('demoStartingBalance');
      return saved ? parseFloat(saved) : 100000;
    } catch {
      return 100000;
    }
  });
  
  const [selectedSymbol, setSelectedSymbol] = useState('BTCUSDT');
  
  const [tradingState, setTradingState] = useState<TradingState>({
    aiEnabled: true,
    marketRegime: 'TREND',
    confidence: 87,
    ensembleScore: 0.72,
    selectedSymbol: 'BTCUSDT',
    selectedTimeframe: '1h',
  });

  const { logout, user } = useAuth();

  // Initialize services with error handling
  useEffect(() => {
    let isMounted = true;
    
    const initServices = async () => {
      try {
        // Mobile detection - skip heavy features on mobile if needed
        const isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
        
        const services = await loadServices();
        if (!isMounted) return;
        
        servicesRef.current = services;

        // Initialize AI Engine
        try {
          await services.aiEngine.initialize();
        } catch (e) {
          console.warn('AI Engine init failed:', e);
        }

        // Start whale tracking with limited pairs on mobile
        const trackingPairs = isMobile 
          ? ['BTCUSDT', 'ETHUSDT'] 
          : ['BTCUSDT', 'ETHUSDT', 'SOLUSDT'];
        
        try {
          services.whaleTracker.startTracking(trackingPairs);
        } catch (e) {
          console.warn('Whale tracker init failed:', e);
        }

        // Initialize Agent Framework (skip on mobile if problematic)
        if (!isMobile) {
          try {
            await services.agentAdapter.initialize();
            if (isMounted) {
              setAgentSystemActive(true);
              console.log('🧠 Self-Organizing AI Agent Framework activated');
            }
          } catch (e) {
            console.warn('Agent framework init failed:', e);
          }
        }

        if (isMounted) {
          setIsLoading(false);
        }
      } catch (error) {
        console.error('Error initializing services:', error);
        if (isMounted) setIsLoading(false);
      }
    };

    // Delay initialization to let UI render first
    const timer = setTimeout(initServices, 100);

    return () => {
      isMounted = false;
      clearTimeout(timer);
      if (servicesRef.current?.agentAdapter) {
        servicesRef.current.agentAdapter.shutdown();
      }
      if (servicesRef.current?.whaleTracker) {
        servicesRef.current.whaleTracker.stopTracking?.();
      }
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
      }
    };
  }, []);

  // Save balance to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('demoStartingBalance', balance.toString());
    } catch (e) {
      console.warn('Failed to save balance:', e);
    }
  }, [balance]);

  // Fetch candles with cleanup
  useEffect(() => {
    let isMounted = true;
    
    const fetchCandles = async () => {
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
      }
      abortControllerRef.current = new AbortController();
      
      try {
        const response = await fetch(
          `https://api.binance.com/api/v3/klines?symbol=${selectedSymbol}&interval=1h&limit=100`,
          { signal: abortControllerRef.current.signal }
        );
        
        if (!response.ok || !isMounted) return;
        
        const data = await response.json();
        const candles: CandleData[] = data.map((candle: any[]) => ({
          time: new Date(candle[0]).toISOString(),
          timestamp: candle[0],
          open: parseFloat(candle[1]),
          high: parseFloat(candle[2]),
          low: parseFloat(candle[3]),
          close: parseFloat(candle[4]),
          volume: parseFloat(candle[5]),
        }));

        if (servicesRef.current?.aiEngine && isMounted) {
          servicesRef.current.aiEngine.updateCandles(selectedSymbol, candles);
          
          if (candles.length > 200) {
            servicesRef.current.aiEngine.autoTrain(selectedSymbol);
          }
        }
      } catch (error) {
        if ((error as Error).name !== 'AbortError') {
          console.error('Error fetching candles:', error);
        }
      }
    };

    fetchCandles();
    
    // Longer interval on mobile to save battery
    const isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
    const interval = setInterval(fetchCandles, isMobile ? 600000 : 300000);
    
    return () => {
      isMounted = false;
      clearInterval(interval);
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
      }
    };
  }, [selectedSymbol]);

  const handleSignalGenerated = useCallback((signal: ActiveSignal) => {
    console.log('Signal generated:', signal);
    
    if (agentSystemActive && servicesRef.current?.agentAdapter) {
      servicesRef.current.agentAdapter.validateSignal(signal).then((validation: any) => {
        if (!validation.approved) {
          console.log('Signal rejected by agent:', validation.reason);
        }
      }).catch((e: any) => console.warn('Signal validation error:', e));
    }
  }, [agentSystemActive]);

  const handleSymbolChange = useCallback((symbol: string) => {
    setSelectedSymbol(symbol);
    setTradingState(prev => ({ ...prev, selectedSymbol: symbol }));
  }, []);

  const handleAISymbolChange = useCallback((symbol: string) => {
    console.log('AI Signals rotated to:', symbol);
    setSelectedSymbol(symbol);
    setTradingState(prev => ({ ...prev, selectedSymbol: symbol }));
  }, []);

  // Slower regime changes on mobile
  useEffect(() => {
    const isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
    const interval = setInterval(() => {
      const regimes: MarketRegime[] = ['TREND', 'CHOP', 'RANGE', 'BREAKOUT', 'PANIC'];
      const randomRegime = regimes[Math.floor(Math.random() * regimes.length)];
      setTradingState(prev => ({ ...prev, marketRegime: randomRegime }));
    }, isMobile ? 30000 : 15000);
    
    return () => clearInterval(interval);
  }, []);

  const handleAIToggle = (enabled: boolean) => {
    setTradingState(prev => ({ ...prev, aiEnabled: enabled }));
    
    if (agentSystemActive && servicesRef.current?.agentAdapter) {
      servicesRef.current.agentAdapter.updateAIState(enabled);
    }
  };

  const handleSectionChange = (section: string) => {
    setActiveSection(section);
    setSidebarOpen(false);
  };

  const handleBalanceChange = useCallback((newBalance: number) => {
    setBalance(newBalance);
    try {
      localStorage.setItem('demoStartingBalance', newBalance.toString());
    } catch (e) {
      console.warn('Failed to save balance:', e);
    }
    
    if (agentSystemActive && servicesRef.current?.agentAdapter) {
      servicesRef.current.agentAdapter.updateBalance(newBalance);
    }
  }, [agentSystemActive]);

  const renderSection = () => {
    switch (activeSection) {
      case 'dashboard':
        return (
          <div className="flex flex-col gap-6 pb-6">
            {/* Agent Control Panel - Only show if active */}
            {agentSystemActive && (
              <AgentControlPanel />
            )}
            
            <AIControlPanel 
              tradingState={tradingState} 
              onAIToggle={handleAIToggle}
            />
            <MarketOverview 
              tradingState={tradingState}
              onSymbolChange={handleSymbolChange}
              selectedSymbol={selectedSymbol}
            />
            <AISignals 
              tradingState={{
                aiEnabled: tradingState.aiEnabled,
                marketRegime: tradingState.marketRegime
              }}
              onSymbolChange={handleAISymbolChange}
            />
          </div>
        );
      case 'demo-trading':
        return (
          <DemoTrading 
            tradingState={tradingState} 
            initialBalance={balance}
            onSignalGenerated={handleSignalGenerated}
          />
        );
      case 'backtesting':
        return <Backtesting />;
      case 'strategies':
        return <StrategyComparison />;
      case 'news':
        return <NewsAnalysis />;
      case 'bitnodes':
        return <BitnodesAnalysis />;
      case 'risk-management':
        return <RiskManagement />;
      case 'ai-performance':
        return <AIPerformance />;
      case 'whale-tracking':
        return <WhaleTracking />;
      case 'market-data':
        return <MarketData />;
      case 'settings':
        return <Settings currentBalance={balance} onBalanceChange={handleBalanceChange} />;
      default:
        return (
          <div className="flex flex-col gap-6 pb-6">
            {agentSystemActive && <AgentControlPanel />}
            <AIControlPanel 
              tradingState={tradingState}
              onAIToggle={handleAIToggle}
            />
            <MarketOverview 
              tradingState={tradingState}
              onSymbolChange={handleSymbolChange}
              selectedSymbol={selectedSymbol}
            />
            <AISignals 
              tradingState={{
                aiEnabled: tradingState.aiEnabled,
                marketRegime: tradingState.marketRegime
              }}
              onSymbolChange={handleAISymbolChange}
            />
          </div>
        );
    }
  };

  // Check if we're on auth pages
  const isAuthPage = location.pathname === '/login' || location.pathname === '/register';

  if (isAuthPage) {
    return (
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
      </Routes>
    );
  }

  // Show loading state
  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#050505] flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-[#d4af37] border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-[#f6f6f6]">Loading AI Trading Platform...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#050505] flex overflow-hidden">
      <Sidebar 
        activeSection={activeSection} 
        onSectionChange={handleSectionChange}
        isOpen={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
        user={user}
        onLogout={logout}
      />
      
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}
      
      <div className="flex-1 flex flex-col min-w-0 h-screen overflow-hidden">
        <Header 
          tradingState={tradingState} 
          onMenuClick={() => setSidebarOpen(true)}
          selectedSymbol={selectedSymbol}
          onSymbolChange={handleSymbolChange}
          user={user}
          onLogout={logout}
          onSettingsClick={() => setActiveSection('settings')}
        />
        <main className="flex-1 overflow-y-auto overflow-x-hidden p-4 lg:p-6 relative">
          {renderSection()}
        </main>
      </div>
      <Toaster />
    </div>
  );
}

// AgentControlPanel component (inline to avoid import issues)
function AgentControlPanel() {
  return (
    <div className="bg-[#0b0b0b] border border-[#1a1a1a] rounded-lg p-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
          <h3 className="text-[#f6f6f6] font-medium">Self-Organizing AI Agents</h3>
        </div>
        <span className="text-xs text-[#888888] bg-[#1a1a1a] px-2 py-1 rounded">Active</span>
      </div>
      <p className="text-sm text-[#888888] mt-2">Multi-agent orchestration system running</p>
    </div>
  );
}

// Main App Component with Router and Auth
function App() {
  return (
    <Router>
      <AuthProvider>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route 
            path="/*" 
            element={
              <ProtectedRoute>
                <AppContent />
              </ProtectedRoute>
            } 
          />
        </Routes>
      </AuthProvider>
    </Router>
  );
}

export default App;
