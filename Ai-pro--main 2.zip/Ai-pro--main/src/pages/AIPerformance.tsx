import React, { useState, useEffect, useCallback } from 'react';
import { 
  Brain, 
  TrendingUp, 
  Target, 
  BarChart3,
  Activity,
  Award,
  AlertTriangle,
  ChevronDown,
  Loader2,
  X,
  ChevronLeft,
  ChevronRight,
  // Removed: Clock,
  // Removed: DollarSign,
  // Removed: TrendingUp as TrendUpIcon,
  // Removed: TrendingDown as TrendDownIcon,
  Filter
} from 'lucide-react';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart as RePieChart,
  Pie,
  Cell
} from 'recharts';

import { cn, formatCurrency } from '@/lib/utils';

// Types
interface PerformanceData {
  date: string;
  profit: number;
  trades: number;
  accuracy: number;
}

interface ModelPerformance {
  name: string;
  accuracy: number;
  profit: number;
  trades: number;
  winRate: number;
  avgTrade: number;
  maxDrawdown: number;
  description: string;
}

interface ModelTrade {
  id: string;
  date: string;
  symbol: string;
  side: 'BUY' | 'SELL';
  entryPrice: number;
  exitPrice: number;
  size: number;
  pnl: number;
  pnlPercent: number;
  confidence: number;
  result: 'WIN' | 'LOSS';
  duration: string;
  strategy: string;
}

interface TradeDistribution {
  name: string;
  value: number;
  color: string;
}

const TIMEFRAMES = ['1h', '4h', '1d', '1w', '1M', '3M', 'ALL'];
const COINS = ['BTC', 'ETH', 'SOL', 'BNB', 'ADA', 'XRP', 'DOT', 'AVAX', 'LINK', 'MATIC'];

// Generate performance data
const generatePerformanceData = (coin: string, timeframe: string): PerformanceData[] => {
  const dataPoints = timeframe === '1h' ? 24 : timeframe === '4h' ? 30 : timeframe === '1d' ? 30 : 12;
  const data: PerformanceData[] = [];
  let cumulativeProfit = 0;
  const basePerformance = coin.charCodeAt(0) % 10 - 3;
  
  for (let i = 0; i < dataPoints; i++) {
    const date = new Date();
    if (timeframe === '1h') date.setHours(date.getHours() - (dataPoints - i));
    else if (timeframe === '4h') date.setHours(date.getHours() - (dataPoints - i) * 4);
    else if (timeframe === '1d') date.setDate(date.getDate() - (dataPoints - i));
    else date.setMonth(date.getMonth() - (dataPoints - i));
    
    const dailyProfit = (Math.random() - 0.3) * 2 + basePerformance * 0.1;
    cumulativeProfit += dailyProfit;
    
    data.push({
      date: timeframe === '1h' || timeframe === '4h' 
        ? date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })
        : date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
      profit: parseFloat(cumulativeProfit.toFixed(2)),
      trades: Math.floor(Math.random() * 20) + 5,
      accuracy: Math.floor(Math.random() * 20) + 60,
    });
  }
  
  return data;
};

// Generate model performance
const generateModelPerformance = (coin: string): ModelPerformance[] => {
  const baseAccuracy = coin.charCodeAt(0) % 20 + 60;
  
  return [
    { 
      name: 'Trend Follower', 
      accuracy: baseAccuracy + 5, 
      profit: parseFloat((Math.random() * 15 + 15).toFixed(1)), 
      trades: Math.floor(Math.random() * 100) + 150,
      winRate: baseAccuracy + 3,
      avgTrade: 125,
      maxDrawdown: 8.5,
      description: 'Moving average crossover with momentum confirmation'
    },
    { 
      name: 'Momentum AI', 
      accuracy: baseAccuracy + 2, 
      profit: parseFloat((Math.random() * 12 + 10).toFixed(1)), 
      trades: Math.floor(Math.random() * 80) + 120,
      winRate: baseAccuracy,
      avgTrade: 98,
      maxDrawdown: 12.3,
      description: 'RSI and MACD divergence detection'
    },
    { 
      name: 'Volatility Scout', 
      accuracy: baseAccuracy - 3, 
      profit: parseFloat((Math.random() * 10 + 8).toFixed(1)), 
      trades: Math.floor(Math.random() * 60) + 100,
      winRate: baseAccuracy - 5,
      avgTrade: 87,
      maxDrawdown: 15.2,
      description: 'Bollinger Bands squeeze and expansion'
    },
    { 
      name: 'Sentiment Analyzer', 
      accuracy: baseAccuracy + 8, 
      profit: parseFloat((Math.random() * 18 + 20).toFixed(1)), 
      trades: Math.floor(Math.random() * 90) + 140,
      winRate: baseAccuracy + 5,
      avgTrade: 142,
      maxDrawdown: 6.8,
      description: 'Social media sentiment and news analysis'
    },
    { 
      name: 'Pattern Recognition', 
      accuracy: baseAccuracy - 5, 
      profit: parseFloat((Math.random() * 8 + 5).toFixed(1)), 
      trades: Math.floor(Math.random() * 50) + 80,
      winRate: baseAccuracy - 8,
      avgTrade: 76,
      maxDrawdown: 18.4,
      description: 'Harmonic patterns and chart formations'
    },
  ];
};

// Generate individual trades for a model
const generateModelTrades = (modelName: string, count: number, coin: string): ModelTrade[] => {
  const trades: ModelTrade[] = [];
  const basePrice = coin === 'BTC' ? 45000 : coin === 'ETH' ? 2500 : coin === 'SOL' ? 80 : 100;
  
  for (let i = 0; i < count; i++) {
    const date = new Date();
    date.setDate(date.getDate() - Math.floor(Math.random() * 30));
    date.setHours(Math.floor(Math.random() * 24), Math.floor(Math.random() * 60));
    
    const isWin = Math.random() > 0.35; // 65% win rate
    const side: 'BUY' | 'SELL' = Math.random() > 0.5 ? 'BUY' : 'SELL';
    const entryPrice = basePrice * (0.9 + Math.random() * 0.2);
    const volatility = 0.02 + Math.random() * 0.03;
    const exitPrice = isWin
      ? side === 'BUY' ? entryPrice * (1 + volatility) : entryPrice * (1 - volatility)
      : side === 'BUY' ? entryPrice * (1 - volatility * 0.6) : entryPrice * (1 + volatility * 0.6);
    
    const size = 0.01 + Math.random() * 0.5;
    const pnl = side === 'BUY' 
      ? (exitPrice - entryPrice) * size 
      : (entryPrice - exitPrice) * size;
    const pnlPercent = (pnl / (entryPrice * size)) * 100;
    
    trades.push({
      id: `trade_${modelName.replace(/\s+/g, '_')}_${i}`,
      date: date.toISOString(),
      symbol: `${coin}/USDT`,
      side,
      entryPrice: parseFloat(entryPrice.toFixed(2)),
      exitPrice: parseFloat(exitPrice.toFixed(2)),
      size: parseFloat(size.toFixed(4)),
      pnl: parseFloat(pnl.toFixed(2)),
      pnlPercent: parseFloat(pnlPercent.toFixed(2)),
      confidence: Math.floor(60 + Math.random() * 35),
      result: isWin ? 'WIN' : 'LOSS',
      duration: `${Math.floor(Math.random() * 24 + 1)}h ${Math.floor(Math.random() * 60)}m`,
      strategy: modelName
    });
  }
  
  return trades.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
};

const generateTradeDistribution = (): TradeDistribution[] => [
  { name: 'Winning Trades', value: Math.floor(Math.random() * 20) + 60, color: '#d0ff59' },
  { name: 'Losing Trades', value: Math.floor(Math.random() * 15) + 20, color: '#ef4444' },
  { name: 'Break-even', value: Math.floor(Math.random() * 10) + 5, color: '#888888' },
];

const generateAlerts = (coin: string) => [
  { time: '2 min ago', message: `Sentiment Analyzer detected bullish divergence on ${coin}`, type: 'success' as const },
  { time: '15 min ago', message: `Pattern Recognition identified support level on ${coin}`, type: 'info' as const },
  { time: '1 hour ago', message: `Momentum AI signaled entry opportunity on ${coin}`, type: 'success' as const },
  { time: '3 hours ago', message: `Trend Follower confirmed uptrend on ${coin}`, type: 'success' as const },
];

export function AIPerformance() {
  const [selectedTimeframe, setSelectedTimeframe] = useState('1d');
  const [selectedCoin, setSelectedCoin] = useState('BTC');
  const [performanceData, setPerformanceData] = useState<PerformanceData[]>([]);
  const [modelPerformance, setModelPerformance] = useState<ModelPerformance[]>([]);
  const [tradeDistribution, setTradeDistribution] = useState<TradeDistribution[]>([]);
  const [alerts, setAlerts] = useState<{ time: string; message: string; type: 'success' | 'warning' | 'info' }[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  
  // Modal state for individual trades
  const [selectedModel, setSelectedModel] = useState<ModelPerformance | null>(null);
  const [modelTrades, setModelTrades] = useState<ModelTrade[]>([]);
  const [tradesPage, setTradesPage] = useState(1);
  const [tradesFilter, setTradesFilter] = useState<'ALL' | 'WIN' | 'LOSS'>('ALL');
  
  const [metrics, setMetrics] = useState({
    totalReturn: '+15.6%',
    totalProfit: 15600,
    winRate: '68%',
    winningTrades: 764,
    profitFactor: '2.34',
    avgTrade: '+1.2%',
    sharpeRatio: '1.92',
  });

  const fetchPerformanceData = useCallback(async () => {
    setIsLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 600));
      
      const newPerformanceData = generatePerformanceData(selectedCoin, selectedTimeframe);
      const newModelPerformance = generateModelPerformance(selectedCoin);
      const newTradeDistribution = generateTradeDistribution();
      const newAlerts = generateAlerts(selectedCoin);
      
      const finalProfit = newPerformanceData[newPerformanceData.length - 1]?.profit || 0;
      const totalTrades = newPerformanceData.reduce((sum, d) => sum + d.trades, 0);
      const avgAccuracy = newPerformanceData.reduce((sum, d) => sum + d.accuracy, 0) / newPerformanceData.length;
      
      setPerformanceData(newPerformanceData);
      setModelPerformance(newModelPerformance);
      setTradeDistribution(newTradeDistribution);
      setAlerts(newAlerts);
      
      setMetrics({
        totalReturn: `${finalProfit >= 0 ? '+' : ''}${finalProfit.toFixed(1)}%`,
        totalProfit: Math.abs(finalProfit * 1000),
        winRate: `${Math.floor(avgAccuracy)}%`,
        winningTrades: Math.floor(totalTrades * (avgAccuracy / 100)),
        profitFactor: (Math.random() * 1.5 + 1.5).toFixed(2),
        avgTrade: `${(finalProfit / totalTrades * 100).toFixed(2)}%`,
        sharpeRatio: (Math.random() * 1 + 1.2).toFixed(2),
      });
    } catch (error) {
      console.error('Error fetching performance data:', error);
    } finally {
      setIsLoading(false);
    }
  }, [selectedCoin, selectedTimeframe]);

  useEffect(() => {
    fetchPerformanceData();
  }, [fetchPerformanceData]);

  // Handle model click - open modal with trades
  const handleModelClick = (model: ModelPerformance) => {
    setSelectedModel(model);
    const trades = generateModelTrades(model.name, Math.min(model.trades, 50), selectedCoin); // Show up to 50 trades
    setModelTrades(trades);
    setTradesPage(1);
    setTradesFilter('ALL');
  };

  const closeModal = () => {
    setSelectedModel(null);
    setModelTrades([]);
  };

  const filteredTrades = modelTrades.filter(trade => 
    tradesFilter === 'ALL' ? true : tradesFilter === 'WIN' ? trade.result === 'WIN' : trade.result === 'LOSS'
  );

  const tradesPerPage = 10;
  const totalPages = Math.ceil(filteredTrades.length / tradesPerPage);
  const paginatedTrades = filteredTrades.slice((tradesPage - 1) * tradesPerPage, tradesPage * tradesPerPage);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-4">
        <h2 className="text-xl font-bold text-[#f6f6f6] flex items-center gap-2">
          <Brain className="w-5 h-5 text-[#d0ff59]" />
          AI Performance Metrics
          {isLoading && <Loader2 className="w-5 h-5 text-[#d0ff59] animate-spin" />}
        </h2>
        
        <div className="flex items-center gap-3">
          <div className="relative">
            <select
              value={selectedCoin}
              onChange={(e) => setSelectedCoin(e.target.value)}
              className="appearance-none bg-[#1a1a1a] border border-[#333333] rounded-xl px-4 py-2 pr-10 text-[#f6f6f6] text-sm focus:border-[#d0ff59] focus:outline-none cursor-pointer"
            >
              {COINS.map(coin => <option key={coin} value={coin}>{coin}</option>)}
            </select>
            <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#888888] pointer-events-none" />
          </div>
          
          <div className="flex items-center gap-1 bg-[#0a0a0a] rounded-lg p-1">
            {TIMEFRAMES.map(tf => (
              <button
                key={tf}
                onClick={() => setSelectedTimeframe(tf)}
                className={`px-3 py-1.5 rounded-md text-sm font-medium transition-all ${
                  selectedTimeframe === tf ? 'bg-[#d0ff59] text-black' : 'text-gray-400 hover:text-white'
                }`}
              >
                {tf}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-5 gap-4">
        <MetricCard title="Total Return" value={metrics.totalReturn} subValue={`+$${metrics.totalProfit.toLocaleString()} profit`} icon={TrendingUp} color="text-[#d0ff59]" />
        <MetricCard title="Win Rate" value={metrics.winRate} subValue={`${metrics.winningTrades} winning trades`} icon={Target} color="text-[#d0ff59]" />
        <MetricCard title="Profit Factor" value={metrics.profitFactor} subValue="Risk-adjusted return" icon={BarChart3} color="text-[#d0ff59]" />
        <MetricCard title="Avg Trade" value={metrics.avgTrade} subValue="Expected value" icon={Activity} color="text-[#d0ff59]" />
        <MetricCard title="Sharpe Ratio" value={metrics.sharpeRatio} subValue="Excellent risk-adjusted" icon={Award} color="text-[#d0ff59]" />
      </div>

      {/* Performance Chart */}
      <div className="bg-[#0b0b0b] border border-[#222222] rounded-2xl p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-medium text-[#888888]">
            Cumulative Performance • {selectedCoin} • {selectedTimeframe}
          </h3>
          <span className="text-xs text-[#888888]">
            Last updated: {new Date().toLocaleTimeString()}
          </span>
        </div>
        <div className="h-[300px]">
          {performanceData.length > 0 ? (
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={performanceData}>
                <defs>
                  <linearGradient id="profitGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#d0ff59" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#d0ff59" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#222222" />
                <XAxis dataKey="date" stroke="#444444" tick={{ fill: '#888888', fontSize: 10 }} />
                <YAxis stroke="#444444" tick={{ fill: '#888888', fontSize: 10 }} tickFormatter={(v) => `${v}%`} />
                <Tooltip contentStyle={{ backgroundColor: '#0b0b0b', border: '1px solid #222222', borderRadius: '12px' }} />
                <Area type="monotone" dataKey="profit" stroke="#d0ff59" strokeWidth={2} fill="url(#profitGradient)" />
              </AreaChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-full flex items-center justify-center text-[#888888]">
              Loading performance data...
            </div>
          )}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-6">
        {/* Model Performance - CLICKABLE */}
        <div className="bg-[#0b0b0b] border border-[#222222] rounded-2xl p-6">
          <h3 className="text-sm font-medium text-[#888888] mb-2">
            Individual Model Performance • {selectedCoin}
          </h3>
          <p className="text-xs text-[#666666] mb-4">
            Click on any model to view individual trade history
          </p>
          <div className="space-y-3">
            {modelPerformance.map((model) => (
              <button
                key={model.name}
                onClick={() => handleModelClick(model)}
                className="w-full text-left p-4 bg-[#1a1a1a] rounded-xl hover:bg-[#222222] hover:border-[#d0ff59]/30 border border-transparent transition-all group cursor-pointer"
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="font-medium text-[#f6f6f6] group-hover:text-[#d0ff59] transition-colors">
                    {model.name}
                  </span>
                  <span className={cn(
                    'font-bold',
                    model.accuracy >= 75 ? 'text-[#d0ff59]' : 
                    model.accuracy >= 60 ? 'text-yellow-500' : 'text-red-500'
                  )}>
                    {model.accuracy}% accuracy
                  </span>
                </div>
                <div className="flex items-center gap-4 text-sm text-[#888888]">
                  <span className="text-[#d0ff59]">+{model.profit}% profit</span>
                  <span className="font-medium text-[#f6f6f6]">{model.trades} trades</span>
                  <div className="flex-1 h-2 bg-[#222222] rounded-full overflow-hidden">
                    <div 
                      className={cn(
                        'h-full rounded-full transition-all duration-500',
                        model.accuracy >= 75 ? 'bg-[#d0ff59]' : 
                        model.accuracy >= 60 ? 'bg-yellow-500' : 'bg-red-500'
                      )} 
                      style={{ width: `${model.accuracy}%` }} 
                    />
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Trade Distribution */}
        <div className="bg-[#0b0b0b] border border-[#222222] rounded-2xl p-6">
          <h3 className="text-sm font-medium text-[#888888] mb-4">
            Trade Distribution • {selectedCoin}
          </h3>
          <div className="h-[250px]">
            <ResponsiveContainer width="100%" height="100%">
              <RePieChart>
                <Pie data={tradeDistribution} cx="50%" cy="50%" innerRadius={60} outerRadius={100} paddingAngle={5} dataKey="value">
                  {tradeDistribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ backgroundColor: '#0b0b0b', border: '1px solid #222222', borderRadius: '12px' }} />
              </RePieChart>
            </ResponsiveContainer>
          </div>
          <div className="flex justify-center gap-6 mt-4 flex-wrap">
            {tradeDistribution.map((item) => (
              <div key={item.name} className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                <span className="text-sm text-[#888888]">{item.name}: {item.value}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Recent Alerts */}
      <div className="bg-[#0b0b0b] border border-[#222222] rounded-2xl p-6">
        <h3 className="text-sm font-medium text-[#888888] mb-4">
          Recent AI Alerts • {selectedCoin}
        </h3>
        <div className="space-y-3">
          {alerts.map((alert, idx) => (
            <div key={idx} className="flex items-center gap-3 p-3 bg-[#1a1a1a] rounded-xl">
              <AlertTriangle className={cn(
                'w-4 h-4',
                alert.type === 'success' ? 'text-[#d0ff59]' : 
                alert.type === 'warning' ? 'text-yellow-500' : 'text-blue-500'
              )} />
              <div className="flex-1">
                <p className="text-sm text-[#f6f6f6]">{alert.message}</p>
                <p className="text-xs text-[#888888]">{alert.time}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* ===== MODAL: Individual Trades ===== */}
      {selectedModel && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-[#0b0b0b] border border-[#333333] rounded-2xl w-full max-w-5xl max-h-[90vh] overflow-hidden flex flex-col">
            {/* Modal Header */}
            <div className="flex items-center justify-between p-6 border-b border-[#222222] bg-gradient-to-r from-[#1a1a1a] to-[#0b0b0b]">
              <div>
                <h2 className="text-2xl font-bold text-[#f6f6f6] flex items-center gap-2">
                  <Brain className="w-6 h-6 text-[#d0ff59]" />
                  {selectedModel.name} Trades
                </h2>
                <p className="text-sm text-[#888888] mt-1">
                  {selectedModel.description} • {selectedModel.trades} total trades on {selectedCoin}
                </p>
              </div>
              <button 
                onClick={closeModal}
                className="p-2 hover:bg-[#1a1a1a] rounded-lg transition-colors"
              >
                <X className="w-6 h-6 text-[#888888]" />
              </button>
            </div>

            {/* Model Stats */}
            <div className="grid grid-cols-4 gap-4 p-6 border-b border-[#222222] bg-[#111111]">
              <div className="text-center">
                <p className="text-xs text-[#888888] mb-1">Accuracy</p>
                <p className="text-xl font-bold text-[#d0ff59]">{selectedModel.accuracy}%</p>
              </div>
              <div className="text-center">
                <p className="text-xs text-[#888888] mb-1">Win Rate</p>
                <p className="text-xl font-bold text-[#d0ff59]">{selectedModel.winRate}%</p>
              </div>
              <div className="text-center">
                <p className="text-xs text-[#888888] mb-1">Avg Trade</p>
                <p className="text-xl font-bold text-[#d0ff59]">+${selectedModel.avgTrade}</p>
              </div>
              <div className="text-center">
                <p className="text-xs text-[#888888] mb-1">Max DD</p>
                <p className="text-xl font-bold text-red-500">{selectedModel.maxDrawdown}%</p>
              </div>
            </div>

            {/* Filters */}
            <div className="flex items-center justify-between px-6 py-4 border-b border-[#222222]">
              <div className="flex items-center gap-2">
                <Filter className="w-4 h-4 text-[#888888]" />
                <span className="text-sm text-[#888888]">Filter:</span>
                {(['ALL', 'WIN', 'LOSS'] as const).map((filter) => (
                  <button
                    key={filter}
                    onClick={() => {
                      setTradesFilter(filter);
                      setTradesPage(1);
                    }}
                    className={cn(
                      'px-3 py-1 rounded-lg text-sm font-medium transition-all',
                      tradesFilter === filter
                        ? filter === 'WIN' ? 'bg-[#0ecb81]/20 text-[#0ecb81]' :
                          filter === 'LOSS' ? 'bg-[#f6465d]/20 text-[#f6465d]' :
                          'bg-[#d0ff59]/20 text-[#d0ff59]'
                        : 'bg-[#1a1a1a] text-[#888888] hover:text-[#f6f6f6]'
                    )}
                  >
                    {filter === 'ALL' ? 'All Trades' : filter === 'WIN' ? 'Winners' : 'Losers'}
                  </button>
                ))}
              </div>
              <span className="text-sm text-[#888888]">
                Showing {filteredTrades.length} of {modelTrades.length} trades
              </span>
            </div>

            {/* Trades Table */}
            <div className="flex-1 overflow-auto p-6">
              <table className="w-full">
                <thead className="sticky top-0 bg-[#0b0b0b]">
                  <tr className="text-left text-xs text-[#888888] border-b border-[#222222]">
                    <th className="pb-3 font-medium">Date</th>
                    <th className="pb-3 font-medium">Side</th>
                    <th className="pb-3 font-medium text-right">Entry</th>
                    <th className="pb-3 font-medium text-right">Exit</th>
                    <th className="pb-3 font-medium text-right">Size</th>
                    <th className="pb-3 font-medium text-right">PnL</th>
                    <th className="pb-3 font-medium text-right">ROI</th>
                    <th className="pb-3 font-medium">Duration</th>
                    <th className="pb-3 font-medium text-center">Conf</th>
                  </tr>
                </thead>
                <tbody className="text-sm">
                  {paginatedTrades.map((trade) => (
                    <tr key={trade.id} className="border-b border-[#222222] last:border-0 hover:bg-[#1a1a1a] transition-colors">
                      <td className="py-3 text-[#cccccc]">
                        {new Date(trade.date).toLocaleDateString()} {new Date(trade.date).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                      </td>
                      <td className="py-3">
                        <span className={cn(
                          'px-2 py-0.5 rounded text-xs font-medium',
                          trade.side === 'BUY' ? 'bg-[#0ecb81]/20 text-[#0ecb81]' : 'bg-[#f6465d]/20 text-[#f6465d]'
                        )}>
                          {trade.side}
                        </span>
                      </td>
                      <td className="py-3 text-[#cccccc] text-right tabular-nums">
                        ${trade.entryPrice.toLocaleString()}
                      </td>
                      <td className="py-3 text-[#cccccc] text-right tabular-nums">
                        ${trade.exitPrice.toLocaleString()}
                      </td>
                      <td className="py-3 text-[#cccccc] text-right tabular-nums">
                        {trade.size.toFixed(4)}
                      </td>
                      <td className={cn(
                        'py-3 text-right font-medium tabular-nums',
                        trade.pnl >= 0 ? 'text-[#0ecb81]' : 'text-[#f6465d]'
                      )}>
                        {trade.pnl >= 0 ? '+' : ''}{formatCurrency(trade.pnl)}
                      </td>
                      <td className={cn(
                        'py-3 text-right tabular-nums',
                        trade.pnlPercent >= 0 ? 'text-[#0ecb81]' : 'text-[#f6465d]'
                      )}>
                        {trade.pnlPercent >= 0 ? '+' : ''}{trade.pnlPercent.toFixed(2)}%
                      </td>
                      <td className="py-3 text-[#888888]">
                        {trade.duration}
                      </td>
                      <td className="py-3 text-center">
                        <span className={cn(
                          'text-xs font-medium',
                          trade.confidence >= 80 ? 'text-[#d0ff59]' :
                          trade.confidence >= 60 ? 'text-yellow-500' : 'text-red-500'
                        )}>
                          {trade.confidence}%
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>

              {paginatedTrades.length === 0 && (
                <div className="text-center py-12 text-[#888888]">
                  <p>No trades match the selected filter</p>
                </div>
              )}
            </div>

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="flex items-center justify-between px-6 py-4 border-t border-[#222222]">
                <button
                  onClick={() => setTradesPage(p => Math.max(1, p - 1))}
                  disabled={tradesPage === 1}
                  className="flex items-center gap-1 px-4 py-2 rounded-lg bg-[#1a1a1a] text-[#888888] hover:text-[#f6f6f6] disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                  <ChevronLeft className="w-4 h-4" />
                  Previous
                </button>
                <span className="text-sm text-[#888888]">
                  Page {tradesPage} of {totalPages}
                </span>
                <button
                  onClick={() => setTradesPage(p => Math.min(totalPages, p + 1))}
                  disabled={tradesPage === totalPages}
                  className="flex items-center gap-1 px-4 py-2 rounded-lg bg-[#1a1a1a] text-[#888888] hover:text-[#f6f6f6] disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                  Next
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

interface MetricCardProps {
  title: string;
  value: string;
  subValue: string;
  icon: React.ElementType;
  color: string;
}

function MetricCard({ title, value, subValue, icon: Icon, color }: MetricCardProps) {
  return (
    <div className="bg-[#0b0b0b] border border-[#222222] rounded-xl p-4">
      <div className="flex items-center justify-between mb-2">
        <span className="text-xs text-[#888888]">{title}</span>
        <Icon className={`w-4 h-4 ${color}`} />
      </div>
      <p className={`text-2xl font-bold tabular-nums ${color}`}>{value}</p>
      <p className="text-xs text-[#888888] mt-1">{subValue}</p>
    </div>
  );
}

export default AIPerformance;
