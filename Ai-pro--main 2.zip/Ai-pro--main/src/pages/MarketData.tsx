import { useState, useEffect, useCallback } from 'react';
import { 
  Activity, 
  BookOpen, 
  Percent, 
  BarChart3,
  TrendingUp,
  TrendingDown,
  Flame,
  ChevronDown,
  Loader2
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
} from 'recharts';
import { cn } from '@/lib/utils';
import { binanceWS } from '@/services/binanceWebSocket';

interface MarketDataProps {
  allCoins?: string[];
}

interface OrderBookEntry {
  price: string;
  quantity: string;
  total: number;
}

interface FundingRate {
  symbol: string;
  rate: number;
  nextFunding: string;
}

interface OpenInterest {
  symbol: string;
  value: number;
  change24h: number;
}

const LIQUIDATION_DATA = [
  { price: '62000', long: 450, short: 120 },
  { price: '64000', long: 380, short: 180 },
  { price: '66000', long: 290, short: 240 },
  { price: '68000', long: 210, short: 320 },
  { price: '70000', long: 150, short: 450 },
  { price: '72000', long: 90, short: 580 },
];

const CORRELATION_DATA = [
  { coin: 'BTC', BTC: 1, ETH: 0.85, SOL: 0.72, BNB: 0.68, ADA: 0.65 },
  { coin: 'ETH', BTC: 0.85, ETH: 1, SOL: 0.78, BNB: 0.71, ADA: 0.69 },
  { coin: 'SOL', BTC: 0.72, ETH: 0.78, SOL: 1, BNB: 0.64, ADA: 0.58 },
  { coin: 'BNB', BTC: 0.68, ETH: 0.71, SOL: 0.64, BNB: 1, ADA: 0.62 },
  { coin: 'ADA', BTC: 0.65, ETH: 0.69, SOL: 0.58, BNB: 0.62, ADA: 1 },
];

export function MarketData({ allCoins = ['BTC/USDT', 'ETH/USDT', 'SOL/USDT', 'BNB/USDT', 'ADA/USDT'] }: MarketDataProps) {
  const [selectedCoin, setSelectedCoin] = useState('BTC/USDT');
  const [selectedMetric, setSelectedMetric] = useState('funding');
  const [orderBook, setOrderBook] = useState<{ bids: OrderBookEntry[]; asks: OrderBookEntry[] }>({ bids: [], asks: [] });
  const [isLoading, setIsLoading] = useState(false);
  const [fundingRates, setFundingRates] = useState<FundingRate[]>([]);
  const [openInterest, setOpenInterest] = useState<OpenInterest[]>([]);
  const [livePrice, setLivePrice] = useState<number>(0);

  // Fetch market data when coin changes
  const fetchMarketData = useCallback(async () => {
    setIsLoading(true);
    try {
      const symbol = selectedCoin.replace('/', '');
      
      // Fetch funding rates
      const fundingRes = await fetch(`https://fapi.binance.com/fapi/v1/fundingRate?symbol=${symbol}&limit=1`);
      const fundingData = await fundingRes.json();
      
      if (fundingData && fundingData.length > 0) {
        const rate = parseFloat(fundingData[0].fundingRate) * 100;
        setFundingRates([{
          symbol: selectedCoin.replace('/USDT', ''),
          rate: rate,
          nextFunding: '8 hours'
        }]);
      }

      // Fetch open interest
      const oiRes = await fetch(`https://fapi.binance.com/fapi/v1/openInterest?symbol=${symbol}`);
      const oiData = await oiRes.json();
      
      if (oiData) {
        const value = parseFloat(oiData.openInterest);
        setOpenInterest([{
          symbol: selectedCoin.replace('/USDT', ''),
          value: value / 1000000000, // Convert to billions
          change24h: (Math.random() - 0.5) * 10 // Simulated 24h change
        }]);
      }

      // Get current price for order book reference
      const tickerRes = await fetch(`https://api.binance.com/api/v3/ticker/price?symbol=${symbol}`);
      const tickerData = await tickerRes.json();
      if (tickerData && tickerData.price) {
        setLivePrice(parseFloat(tickerData.price));
      }

    } catch (error) {
      console.error('Error fetching market data:', error);
      // Fallback to static data
      setFundingRates([{
        symbol: selectedCoin.replace('/USDT', ''),
        rate: (Math.random() - 0.5) * 0.1,
        nextFunding: '8 hours'
      }]);
    } finally {
      setIsLoading(false);
    }
  }, [selectedCoin]);

  // Fetch data when coin changes
  useEffect(() => {
    fetchMarketData();
  }, [fetchMarketData]);

  // Subscribe to order book WebSocket
  useEffect(() => {
    const symbol = selectedCoin.replace('/', '');
    
    binanceWS.subscribeToOrderBook(symbol, (data) => {
      const formattedBids = data.bids.slice(0, 8).map(([price, quantity], index, arr) => ({
        price,
        quantity,
        total: arr.slice(0, index + 1).reduce((sum, [, qty]) => sum + parseFloat(qty), 0)
      }));
      
      const formattedAsks = data.asks.slice(0, 8).map(([price, quantity], index, arr) => ({
        price,
        quantity,
        total: arr.slice(0, index + 1).reduce((sum, [, qty]) => sum + parseFloat(qty), 0)
      }));
      
      setOrderBook({
        bids: formattedBids,
        asks: formattedAsks.reverse() // Reverse for display
      });
    });

    return () => {
      binanceWS.unsubscribeFromOrderBook();
    };
  }, [selectedCoin]);

  // Subscribe to live price
  useEffect(() => {
    const symbol = selectedCoin.replace('/', '');
    const unsubscribe = binanceWS.subscribeToTicker(symbol, (data) => {
      setLivePrice(data.price);
    });
    return () => unsubscribe();
  }, [selectedCoin]);

  const maxBidTotal = Math.max(...orderBook.bids.map(b => b.total), 1);
  const maxAskTotal = Math.max(...orderBook.asks.map(a => a.total), 1);

  return (
    <div className="space-y-6">
      {/* Header with Coin Selector */}
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div className="flex items-center gap-4">
          <h2 className="text-xl font-bold text-[#f6f6f6] flex items-center gap-2">
            <Activity className="w-5 h-5 text-[#d0ff59]" />
            Advanced Market Data
          </h2>
          
          {/* Coin Selector */}
          <div className="relative">
            <select
              value={selectedCoin}
              onChange={(e) => setSelectedCoin(e.target.value)}
              className="appearance-none bg-[#1a1a1a] border border-[#333333] rounded-xl px-4 py-2 pr-10 text-[#f6f6f6] text-sm focus:border-[#d0ff59] focus:outline-none cursor-pointer"
            >
              {allCoins.map(coin => (
                <option key={coin} value={coin}>{coin}</option>
              ))}
            </select>
            <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#888888] pointer-events-none" />
          </div>

          {isLoading && <Loader2 className="w-5 h-5 text-[#d0ff59] animate-spin" />}
        </div>
        
        <div className="flex items-center gap-2 bg-[#0a0a0a] rounded-lg p-1">
          {[
            { id: 'funding', label: 'Funding', icon: Percent },
            { id: 'oi', label: 'Open Interest', icon: BarChart3 },
            { id: 'liquidation', label: 'Liquidations', icon: Flame },
            { id: 'correlation', label: 'Correlation', icon: Activity },
          ].map((metric) => {
            const Icon = metric.icon;
            return (
              <button
                key={metric.id}
                onClick={() => setSelectedMetric(metric.id)}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                  selectedMetric === metric.id 
                    ? 'bg-[#d0ff59] text-black' 
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                <Icon className="w-4 h-4" />
                {metric.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Funding Rates */}
      {selectedMetric === 'funding' && (
        <div className="bg-[#0b0b0b] border border-[#222222] rounded-2xl p-6">
          <h3 className="text-sm font-medium text-[#888888] mb-4">
            Funding Rates (8h) • {selectedCoin}
          </h3>
          <div className="grid grid-cols-4 gap-4">
            {fundingRates.map((item) => (
              <div key={item.symbol} className="p-4 bg-[#1a1a1a] rounded-xl">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-medium text-[#f6f6f6]">{item.symbol}</span>
                  <span className={cn(
                    'text-lg font-bold',
                    item.rate > 0 ? 'text-[#d0ff59]' : 'text-red-500'
                  )}>
                    {item.rate > 0 ? '+' : ''}{item.rate.toFixed(4)}%
                  </span>
                </div>
                <p className="text-xs text-[#888888]">Next: {item.nextFunding}</p>
                <div className="mt-2 w-full h-1 bg-[#222222] rounded-full overflow-hidden">
                  <div 
                    className={cn('h-full', item.rate > 0 ? 'bg-[#d0ff59]' : 'bg-red-500')}
                    style={{ width: `${Math.min(Math.abs(item.rate) * 100, 100)}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
          
          <div className="mt-6 p-4 bg-[#1a1a1a] rounded-xl">
            <p className="text-sm text-[#888888]">
              <span className="text-[#d0ff59]">Positive funding</span> = Longs pay shorts (bullish sentiment)
              <br />
              <span className="text-red-500">Negative funding</span> = Shorts pay longs (bearish sentiment)
            </p>
          </div>
        </div>
      )}

      {/* Open Interest */}
      {selectedMetric === 'oi' && (
        <div className="bg-[#0b0b0b] border border-[#222222] rounded-2xl p-6">
          <h3 className="text-sm font-medium text-[#888888] mb-4">
            Open Interest • {selectedCoin}
          </h3>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={openInterest}>
                <CartesianGrid strokeDasharray="3 3" stroke="#222222" />
                <XAxis dataKey="symbol" stroke="#444444" tick={{ fill: '#888888' }} />
                <YAxis stroke="#444444" tick={{ fill: '#888888' }} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0b0b0b', border: '1px solid #222222', borderRadius: '12px' }}
                  formatter={(v: number) => [`$${v.toFixed(2)}B`, 'OI']}
                />
                <Bar dataKey="value" fill="#d0ff59" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
          
          <div className="grid grid-cols-5 gap-4 mt-6">
            {openInterest.map((item) => (
              <div key={item.symbol} className="text-center p-3 bg-[#1a1a1a] rounded-xl">
                <p className="font-medium text-[#f6f6f6]">{item.symbol}</p>
                <p className="text-lg font-bold text-[#d0ff59]">${item.value.toFixed(2)}B</p>
                <p className={cn(
                  'text-xs',
                  item.change24h > 0 ? 'text-[#d0ff59]' : 'text-red-500'
                )}>
                  {item.change24h > 0 ? '+' : ''}{item.change24h.toFixed(1)}%
                </p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Liquidation Heatmap */}
      {selectedMetric === 'liquidation' && (
        <div className="bg-[#0b0b0b] border border-[#222222] rounded-2xl p-6">
          <h3 className="text-sm font-medium text-[#888888] mb-4">
            Liquidation Heatmap • {selectedCoin}
          </h3>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={LIQUIDATION_DATA}>
                <CartesianGrid strokeDasharray="3 3" stroke="#222222" />
                <XAxis dataKey="price" stroke="#444444" tick={{ fill: '#888888' }} />
                <YAxis stroke="#444444" tick={{ fill: '#888888' }} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0b0b0b', border: '1px solid #222222', borderRadius: '12px' }}
                />
                <Bar dataKey="long" stackId="a" fill="#22c55e" name="Long Liquidations" />
                <Bar dataKey="short" stackId="a" fill="#ef4444" name="Short Liquidations" />
              </BarChart>
            </ResponsiveContainer>
          </div>
          
          <div className="grid grid-cols-2 gap-4 mt-6">
            <div className="p-4 bg-green-500/10 border border-green-500/30 rounded-xl">
              <div className="flex items-center gap-2 mb-2">
                <TrendingUp className="w-5 h-5 text-green-500" />
                <span className="font-medium text-green-500">Long Liquidations</span>
              </div>
              <p className="text-2xl font-bold text-green-500">$2.4M</p>
              <p className="text-xs text-[#888888]">Below current price - support levels</p>
            </div>
            <div className="p-4 bg-red-500/10 border border-red-500/30 rounded-xl">
              <div className="flex items-center gap-2 mb-2">
                <TrendingDown className="w-5 h-5 text-red-500" />
                <span className="font-medium text-red-500">Short Liquidations</span>
              </div>
              <p className="text-2xl font-bold text-red-500">$1.8M</p>
              <p className="text-xs text-[#888888]">Above current price - resistance levels</p>
            </div>
          </div>
        </div>
      )}

      {/* Correlation Matrix */}
      {selectedMetric === 'correlation' && (
        <div className="bg-[#0b0b0b] border border-[#222222] rounded-2xl p-6">
          <h3 className="text-sm font-medium text-[#888888] mb-4">Correlation Matrix (30d)</h3>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr>
                  <th className="text-left p-3 text-[#888888] font-medium"></th>
                  {CORRELATION_DATA.map((d) => (
                    <th key={d.coin} className="p-3 text-[#888888] font-medium">{d.coin}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {CORRELATION_DATA.map((row) => (
                  <tr key={row.coin}>
                    <td className="p-3 font-medium text-[#f6f6f6]">{row.coin}</td>
                    {Object.entries(row).filter(([k]) => k !== 'coin').map(([coin, value]) => (
                      <td key={coin} className="p-3">
                        <div 
                          className="w-12 h-12 rounded-lg flex items-center justify-center text-sm font-bold"
                          style={{
                            backgroundColor: `rgba(208, 255, 89, ${value as number * 0.3})`,
                            color: (value as number) > 0.7 ? '#d0ff59' : (value as number) > 0.4 ? '#cccccc' : '#888888'
                          }}
                        >
                          {(value as number).toFixed(2)}
                        </div>
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          
          <div className="mt-4 p-4 bg-[#1a1a1a] rounded-xl">
            <p className="text-sm text-[#888888]">
              <span className="text-[#d0ff59]">High correlation (0.7+)</span>: Assets move together - diversify carefully
              <br />
              <span className="text-[#888888]">Low correlation (0.3-)</span>: Assets move independently - good for diversification
            </p>
          </div>
        </div>
      )}

      {/* Order Book Visualization */}
      <div className="bg-[#0b0b0b] border border-[#222222] rounded-2xl p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-medium text-[#888888] flex items-center gap-2">
            <BookOpen className="w-4 h-4" />
            Live Order Book • {selectedCoin}
          </h3>
          <div className="flex items-center gap-4">
            <span className="text-lg font-bold text-[#f6f6f6]">
              ${livePrice.toLocaleString(undefined, {maximumFractionDigits: 2})}
            </span>
            <span className="text-xs text-[#888888]">
              Spread: {orderBook.asks[0] && orderBook.bids[0] ? 
                ((parseFloat(orderBook.asks[0].price) - parseFloat(orderBook.bids[0].price)) / parseFloat(orderBook.bids[0].price) * 100).toFixed(3)
                : '0.00'}%
            </span>
          </div>
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          {/* Bids */}
          <div>
            <p className="text-xs text-[#888888] mb-2">Bids (Buy)</p>
            <div className="space-y-1">
              {orderBook.bids.length > 0 ? (
                orderBook.bids.map((bid, i) => {
                  const width = (bid.total / maxBidTotal) * 100;
                  return (
                    <div key={i} className="flex items-center gap-2 text-sm">
                      <span className="w-24 text-[#22c55e] tabular-nums">
                        ${parseFloat(bid.price).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}
                      </span>
                      <div className="flex-1 h-6 bg-[#1a1a1a] rounded relative overflow-hidden">
                        <div 
                          className="absolute right-0 top-0 h-full bg-green-500/20 transition-all duration-300"
                          style={{ width: `${width}%` }}
                        />
                        <span className="absolute right-2 top-1/2 -translate-y-1/2 text-[#888888] text-xs tabular-nums">
                          {parseFloat(bid.quantity).toFixed(4)}
                        </span>
                      </div>
                    </div>
                  );
                })
              ) : (
                <div className="text-center text-[#888888] py-8">Loading order book...</div>
              )}
            </div>
          </div>
          
          {/* Asks */}
          <div>
            <p className="text-xs text-[#888888] mb-2 text-right">Asks (Sell)</p>
            <div className="space-y-1">
              {orderBook.asks.length > 0 ? (
                orderBook.asks.map((ask, i) => {
                  const width = (ask.total / maxAskTotal) * 100;
                  return (
                    <div key={i} className="flex items-center gap-2 text-sm flex-row-reverse">
                      <span className="w-24 text-right text-[#ef4444] tabular-nums">
                        ${parseFloat(ask.price).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}
                      </span>
                      <div className="flex-1 h-6 bg-[#1a1a1a] rounded relative overflow-hidden">
                        <div 
                          className="absolute left-0 top-0 h-full bg-red-500/20 transition-all duration-300"
                          style={{ width: `${width}%` }}
                        />
                        <span className="absolute left-2 top-1/2 -translate-y-1/2 text-[#888888] text-xs tabular-nums">
                          {parseFloat(ask.quantity).toFixed(4)}
                        </span>
                      </div>
                    </div>
                  );
                })
              ) : (
                <div className="text-center text-[#888888] py-8">Loading order book...</div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
