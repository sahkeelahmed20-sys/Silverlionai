import React from 'react';
import { useState, useEffect, useCallback } from 'react';
import { 
  Fish,
  ArrowUpRight, 
  ArrowDownRight, 
  Wallet, 
  Activity,
  ChevronDown,
  Loader2
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { binanceWS } from '@/services/binanceWebSocket';

interface WhaleTrackingProps {
  allCoins: string[];
}

interface WhaleTransaction {
  id: string;
  symbol: string;
  amount: number;
  value: number;
  type: 'in' | 'out';
  timestamp: string;
  wallet: string;
  exchange: string;
}

interface WhaleStats {
  inflow24h: number;
  outflow24h: number;
  netFlow: number;
  largeTransactions: number;
  whaleWallets: number;
}

const EXCHANGES = ['Binance', 'Coinbase', 'Kraken', 'OKX', 'Bybit', 'Bitfinex'];

export function WhaleTracking({ allCoins }: WhaleTrackingProps) {
  const [selectedCoin, setSelectedCoin] = useState('BTC/USDT');
  const [, setTransactions] = useState<WhaleTransaction[]>([]);
  const [filteredTransactions, setFilteredTransactions] = useState<WhaleTransaction[]>([]);
  const [whaleStats, setWhaleStats] = useState<WhaleStats>({
    inflow24h: 125000000,
    outflow24h: 98000000,
    netFlow: 27000000,
    largeTransactions: 47,
    whaleWallets: 1247,
  });
  const [isLoading, setIsLoading] = useState(false);
  const [livePrice, setLivePrice] = useState<number>(0);

  // Subscribe to live price for selected coin
  useEffect(() => {
    const symbol = selectedCoin.replace('/', '');
    const unsubscribe = binanceWS.subscribeToTicker(symbol, (data) => {
      setLivePrice(data.price);
    });
    return () => unsubscribe();
  }, [selectedCoin]);

  // Generate transaction for specific coin
  const generateTransaction = useCallback((coin: string, price: number): WhaleTransaction => {
    const symbol = coin.replace('/USDT', '');
    const amount = Math.random() * 1000 + 100;
    
    return {
      id: Math.random().toString(36).substr(2, 9),
      symbol,
      amount,
      value: amount * price,
      type: Math.random() > 0.5 ? 'in' : 'out',
      timestamp: new Date().toISOString(),
      wallet: `0x${Math.random().toString(16).substr(2, 40)}`,
      exchange: EXCHANGES[Math.floor(Math.random() * EXCHANGES.length)],
    };
  }, []);

  // Fetch whale data for selected coin
  const fetchWhaleData = useCallback(async () => {
    setIsLoading(true);
    try {
      const price = livePrice || getStaticPrice(selectedCoin);
      
      // Simulate API call - replace with your actual whale tracking API
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // Generate transactions for selected coin only
      const newTransactions: WhaleTransaction[] = Array.from({ length: 15 }, () => 
        generateTransaction(selectedCoin, price)
      );
      
      // Calculate stats based on transactions
      const inflow = newTransactions
        .filter(tx => tx.type === 'in')
        .reduce((sum, tx) => sum + tx.value, 0);
      const outflow = newTransactions
        .filter(tx => tx.type === 'out')
        .reduce((sum, tx) => sum + tx.value, 0);
      
      setWhaleStats({
        inflow24h: inflow * 100, // Simulate 24h by multiplying
        outflow24h: outflow * 100,
        netFlow: (inflow - outflow) * 100,
        largeTransactions: newTransactions.filter(tx => tx.value > 1000000).length * 10,
        whaleWallets: Math.floor(Math.random() * 500) + 1000,
      });
      
      setTransactions(newTransactions);
      setFilteredTransactions(newTransactions);
    } catch (error) {
      console.error('Error fetching whale data:', error);
    } finally {
      setIsLoading(false);
    }
  }, [selectedCoin, livePrice, generateTransaction]);

  // Fetch data when coin changes
  useEffect(() => {
    fetchWhaleData();
  }, [fetchWhaleData]);

  // Auto-refresh every 15 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      const price = livePrice || getStaticPrice(selectedCoin);
      const newTx = generateTransaction(selectedCoin, price);
      
      setTransactions(prev => {
        const updated = [newTx, ...prev].slice(0, 20);
        setFilteredTransactions(updated);
        return updated;
      });
      
      // Update stats
      setWhaleStats(prev => ({
        ...prev,
        largeTransactions: prev.largeTransactions + (newTx.value > 1000000 ? 1 : 0),
      }));
    }, 15000);
    
    return () => clearInterval(interval);
  }, [selectedCoin, livePrice, generateTransaction]);

  const handleCoinChange = (coin: string) => {
    setSelectedCoin(coin);
    // Data will auto-fetch via useEffect
  };

  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp);
    return date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  };

  const shortenWallet = (wallet: string) => {
    return `${wallet.slice(0, 6)}...${wallet.slice(-4)}`;
  };

  const formatValue = (value: number) => {
    if (value >= 1000000000) return `$${(value / 1000000000).toFixed(2)}B`;
    if (value >= 1000000) return `$${(value / 1000000).toFixed(1)}M`;
    return `$${(value / 1000).toFixed(1)}K`;
  };

  return (
    <div className="space-y-6">
      {/* Header with Coin Selector */}
      <div className="flex items-center justify-between flex-wrap gap-4">
        <h2 className="text-xl font-bold text-[#f6f6f6] flex items-center gap-2">
          <Fish className="w-5 h-5 text-[#d0ff59]" />
          Whale Wallet Tracking
        </h2>
        
        <div className="flex items-center gap-3">
          {isLoading && <Loader2 className="w-5 h-5 text-[#d0ff59] animate-spin" />}
          
          <div className="relative">
            <select
              value={selectedCoin}
              onChange={(e) => handleCoinChange(e.target.value)}
              className="appearance-none bg-[#1a1a1a] border border-[#333333] rounded-xl px-4 py-2 pr-10 text-[#f6f6f6] text-sm focus:border-[#d0ff59] focus:outline-none cursor-pointer"
            >
              {allCoins.map(coin => (
                <option key={coin} value={coin}>{coin}</option>
              ))}
            </select>
            <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#888888] pointer-events-none" />
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-4">
        <StatCard
          title="24h Inflow"
          value={formatValue(whaleStats.inflow24h)}
          subValue="Exchange deposits"
          icon={ArrowDownRight}
          positive
        />
        <StatCard
          title="24h Outflow"
          value={formatValue(whaleStats.outflow24h)}
          subValue="Exchange withdrawals"
          icon={ArrowUpRight}
          negative
        />
        <StatCard
          title="Net Flow"
          value={formatValue(Math.abs(whaleStats.netFlow))}
          subValue={whaleStats.netFlow > 0 ? 'Net inflow' : 'Net outflow'}
          icon={Activity}
          positive={whaleStats.netFlow > 0}
          negative={whaleStats.netFlow < 0}
        />
        <StatCard
          title="Large Transactions"
          value={whaleStats.largeTransactions.toString()}
          subValue=">$1M in last 24h"
          icon={Wallet}
        />
      </div>

      {/* Live Whale Transactions */}
      <div className="bg-[#0b0b0b] border border-[#222222] rounded-2xl p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-[#f6f6f6] flex items-center gap-2">
            <Activity className="w-5 h-5 text-[#d0ff59]" />
            Live Whale Transactions • {selectedCoin.replace('/USDT', '')}
          </h3>
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 bg-[#d0ff59] rounded-full animate-pulse" />
            <span className="text-sm text-[#888888]">Live</span>
          </div>
        </div>

        <div className="space-y-3 max-h-[500px] overflow-y-auto">
          {filteredTransactions.length > 0 ? (
            filteredTransactions.map((tx) => (
              <div 
                key={tx.id}
                className="flex items-center justify-between p-4 bg-[#1a1a1a] rounded-xl hover:bg-[#222222] transition-colors"
              >
                <div className="flex items-center gap-4">
                  <div className={cn(
                    'w-10 h-10 rounded-lg flex items-center justify-center',
                    tx.type === 'in' ? 'bg-[#d0ff59]/20' : 'bg-red-500/20'
                  )}>
                    {tx.type === 'in' ? (
                      <ArrowDownRight className="w-5 h-5 text-[#d0ff59]" />
                    ) : (
                      <ArrowUpRight className="w-5 h-5 text-red-500" />
                    )}
                  </div>
                  
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-[#f6f6f6]">{tx.symbol}</span>
                      <span className={cn(
                        'text-xs px-2 py-0.5 rounded',
                        tx.type === 'in' ? 'bg-[#d0ff59]/20 text-[#d0ff59]' : 'bg-red-500/20 text-red-500'
                      )}>
                        {tx.type === 'in' ? 'Exchange Inflow' : 'Exchange Outflow'}
                      </span>
                    </div>
                    <p className="text-xs text-[#888888] font-mono">{shortenWallet(tx.wallet)}</p>
                  </div>
                </div>

                <div className="text-right">
                  <p className="font-bold text-[#f6f6f6] tabular-nums">
                    ${tx.value.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                  </p>
                  <p className="text-sm text-[#888888] tabular-nums">
                    {tx.amount.toFixed(4)} {tx.symbol}
                  </p>
                  <p className="text-xs text-[#666666]">{tx.exchange} • {formatTime(tx.timestamp)}</p>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-8 text-[#888888]">
              No whale transactions found for {selectedCoin}
            </div>
          )}
        </div>
      </div>

      {/* Whale Concentration & Exchange Reserves */}
      <div className="grid grid-cols-2 gap-6">
        <div className="bg-[#0b0b0b] border border-[#222222] rounded-2xl p-6">
          <h3 className="text-sm font-medium text-[#888888] mb-4">
            Supply Distribution • {selectedCoin.replace('/USDT', '')}
          </h3>
          <div className="space-y-4">
            {[
              { label: 'Whales (>10K)', value: 42, color: '#d0ff59' },
              { label: 'Sharks (1K-10K)', value: 28, color: '#22c55e' },
              { label: 'Fish (100-1K)', value: 18, color: '#3b82f6' },
              { label: 'Shrimp (<100)', value: 12, color: '#888888' },
            ].map((item) => (
              <div key={item.label}>
                <div className="flex justify-between mb-1">
                  <span className="text-sm text-[#888888]">{item.label}</span>
                  <span className="text-sm text-[#f6f6f6]">{item.value}%</span>
                </div>
                <div className="w-full h-2 bg-[#1a1a1a] rounded-full overflow-hidden">
                  <div 
                    className="h-full rounded-full transition-all duration-500" 
                    style={{ width: `${item.value}%`, backgroundColor: item.color }} 
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-[#0b0b0b] border border-[#222222] rounded-2xl p-6">
          <h3 className="text-sm font-medium text-[#888888] mb-4">
            Exchange Reserves • {selectedCoin.replace('/USDT', '')}
          </h3>
          <div className="space-y-4">
            {[
              { exchange: 'Binance', amount: 485000, change: -2.3 },
              { exchange: 'Coinbase', amount: 412000, change: -1.8 },
              { exchange: 'Kraken', amount: 198000, change: +0.5 },
              { exchange: 'OKX', amount: 156000, change: -3.2 },
            ].map((item) => (
              <div key={item.exchange} className="flex items-center justify-between p-3 bg-[#1a1a1a] rounded-xl">
                <div>
                  <p className="font-medium text-[#f6f6f6]">{item.exchange}</p>
                  <p className="text-xs text-[#888888]">{item.amount.toLocaleString()} {selectedCoin.replace('/USDT', '')}</p>
                </div>
                <span className={cn(
                  'text-sm font-medium',
                  item.change > 0 ? 'text-[#d0ff59]' : 'text-red-500'
                )}>
                  {item.change > 0 ? '+' : ''}{item.change}%
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// Helper function
function getStaticPrice(coin: string): number {
  const prices: Record<string, number> = {
    'BTC/USDT': 68500,
    'ETH/USDT': 3500,
    'SOL/USDT': 150,
    'BNB/USDT': 600,
    'ADA/USDT': 0.5,
    'XRP/USDT': 0.6,
    'DOGE/USDT': 0.08,
    'DOT/USDT': 7,
    'AVAX/USDT': 35,
    'LINK/USDT': 18,
  };
  return prices[coin] || 100;
}

interface StatCardProps {
  title: string;
  value: string;
  subValue: string;
  icon: React.ElementType;
  positive?: boolean;
  negative?: boolean;
}

function StatCard({ title, value, subValue, icon: Icon, positive, negative }: StatCardProps) {
  return (
    <div className="bg-[#0b0b0b] border border-[#222222] rounded-xl p-4">
      <div className="flex items-center justify-between mb-2">
        <span className="text-xs text-[#888888]">{title}</span>
        <Icon className={cn(
          'w-4 h-4',
          positive ? 'text-[#d0ff59]' : negative ? 'text-red-500' : 'text-[#888888]'
        )} />
      </div>
      <p className={cn(
        'text-2xl font-bold tabular-nums',
        positive ? 'text-[#d0ff59]' : negative ? 'text-red-500' : 'text-[#f6f6f6]'
      )}>
        {value}
      </p>
      <p className="text-xs text-[#888888] mt-1">{subValue}</p>
    </div>
  );
}
