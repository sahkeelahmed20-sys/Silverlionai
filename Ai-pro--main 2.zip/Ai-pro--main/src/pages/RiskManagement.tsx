import { useState } from 'react';
import { 
  Shield, 
  Target, 
  Percent, 
  DollarSign, 
  TrendingUp,
  AlertTriangle,
  Calculator,
  Settings2
} from 'lucide-react';
import type { TradingState } from '@/types';
import { cn } from '@/lib/utils';

interface RiskManagementProps {
  tradingState: TradingState;
  onSettingsChange: (settings: Partial<TradingState>) => void;
}

export function RiskManagement({ tradingState, onSettingsChange }: RiskManagementProps) {
  const [positionSize, setPositionSize] = useState({
    accountBalance: tradingState.demoBalance,
    riskPercent: 2,
    entryPrice: 68500,
    stopLoss: 66500,
  });

  const calculatedPosition = {
    riskAmount: (positionSize.accountBalance * positionSize.riskPercent) / 100,
    stopLossPercent: ((positionSize.entryPrice - positionSize.stopLoss) / positionSize.entryPrice) * 100,
    positionSize: ((positionSize.accountBalance * positionSize.riskPercent) / 100) / 
                  Math.abs((positionSize.entryPrice - positionSize.stopLoss) / positionSize.entryPrice),
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-[#f6f6f6] flex items-center gap-2">
          <Shield className="w-5 h-5 text-[#d0ff59]" />
          Risk Management
        </h2>
      </div>

      {/* Risk Settings */}
      <div className="grid grid-cols-2 gap-6">
        {/* Max Daily Loss */}
        <div className="bg-[#0b0b0b] border border-[#222222] rounded-2xl p-6">
          <div className="flex items-center gap-2 mb-4">
            <AlertTriangle className="w-5 h-5 text-[#d0ff59]" />
            <h3 className="text-lg font-semibold text-[#f6f6f6]">Max Daily Loss</h3>
          </div>
          
          <div className="space-y-4">
            <div>
              <label className="text-sm text-[#888888] mb-2 block">Daily Loss Limit (%)</label>
              <input
                type="number"
                value={tradingState.maxDailyLoss}
                onChange={(e) => onSettingsChange({ maxDailyLoss: parseFloat(e.target.value) })}
                className="w-full bg-[#1a1a1a] border border-[#222222] rounded-xl px-4 py-3 text-[#f6f6f6] focus:border-[#d0ff59] focus:outline-none"
              />
            </div>
            <div className="p-4 bg-[#1a1a1a] rounded-xl">
              <p className="text-sm text-[#888888]">Maximum Loss Amount</p>
              <p className="text-2xl font-bold text-red-500">
                -${((tradingState.demoBalance * tradingState.maxDailyLoss) / 100).toLocaleString()}
              </p>
            </div>
          </div>
        </div>

        {/* Max Position Size */}
        <div className="bg-[#0b0b0b] border border-[#222222] rounded-2xl p-6">
          <div className="flex items-center gap-2 mb-4">
            <Target className="w-5 h-5 text-[#d0ff59]" />
            <h3 className="text-lg font-semibold text-[#f6f6f6]">Max Position Size</h3>
          </div>
          
          <div className="space-y-4">
            <div>
              <label className="text-sm text-[#888888] mb-2 block">Max Position (% of Balance)</label>
              <input
                type="number"
                value={tradingState.maxPositionSize}
                onChange={(e) => onSettingsChange({ maxPositionSize: parseFloat(e.target.value) })}
                className="w-full bg-[#1a1a1a] border border-[#222222] rounded-xl px-4 py-3 text-[#f6f6f6] focus:border-[#d0ff59] focus:outline-none"
              />
            </div>
            <div className="p-4 bg-[#1a1a1a] rounded-xl">
              <p className="text-sm text-[#888888]">Maximum Position Value</p>
              <p className="text-2xl font-bold text-[#d0ff59]">
                ${((tradingState.demoBalance * tradingState.maxPositionSize) / 100).toLocaleString()}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Trailing Stop Settings */}
      <div className="bg-[#0b0b0b] border border-[#222222] rounded-2xl p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-[#d0ff59]" />
            <h3 className="text-lg font-semibold text-[#f6f6f6]">Trailing Stop Loss</h3>
          </div>
          <button
            onClick={() => onSettingsChange({ trailingStopEnabled: !tradingState.trailingStopEnabled })}
            className={cn(
              'w-14 h-7 rounded-full relative transition-all duration-300',
              tradingState.trailingStopEnabled ? 'bg-[#d0ff59]' : 'bg-[#333333]'
            )}
          >
            <div className={cn(
              'absolute top-0.5 w-6 h-6 rounded-full bg-white transition-all duration-300',
              tradingState.trailingStopEnabled ? 'left-7' : 'left-0.5'
            )} />
          </button>
        </div>

        {tradingState.trailingStopEnabled && (
          <div className="grid grid-cols-2 gap-6">
            <div>
              <label className="text-sm text-[#888888] mb-2 block">Trailing Stop (%)</label>
              <input
                type="number"
                step="0.1"
                value={tradingState.trailingStopPercent}
                onChange={(e) => onSettingsChange({ trailingStopPercent: parseFloat(e.target.value) })}
                className="w-full bg-[#1a1a1a] border border-[#222222] rounded-xl px-4 py-3 text-[#f6f6f6] focus:border-[#d0ff59] focus:outline-none"
              />
              <p className="text-xs text-[#888888] mt-2">
                Stop loss will trail price by {tradingState.trailingStopPercent}% after reaching 1:1 risk/reward
              </p>
            </div>
            <div className="p-4 bg-[#1a1a1a] rounded-xl">
              <p className="text-sm text-[#888888]">Example for $100,000 position</p>
              <p className="text-lg font-bold text-[#f6f6f6] mt-1">
                Stop moves up every ${(100000 * tradingState.trailingStopPercent / 100).toFixed(0)} gain
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Auto Position Sizing */}
      <div className="bg-[#0b0b0b] border border-[#222222] rounded-2xl p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Settings2 className="w-5 h-5 text-[#d0ff59]" />
            <h3 className="text-lg font-semibold text-[#f6f6f6]">Auto Position Sizing</h3>
          </div>
          <button
            onClick={() => onSettingsChange({ autoPositionSizing: !tradingState.autoPositionSizing })}
            className={cn(
              'w-14 h-7 rounded-full relative transition-all duration-300',
              tradingState.autoPositionSizing ? 'bg-[#d0ff59]' : 'bg-[#333333]'
            )}
          >
            <div className={cn(
              'absolute top-0.5 w-6 h-6 rounded-full bg-white transition-all duration-300',
              tradingState.autoPositionSizing ? 'left-7' : 'left-0.5'
            )} />
          </button>
        </div>
        <p className="text-sm text-[#888888]">
          AI will automatically adjust position sizes based on account balance, volatility, and confidence score
        </p>
      </div>

      {/* Position Size Calculator */}
      <div className="bg-[#0b0b0b] border border-[#222222] rounded-2xl p-6">
        <div className="flex items-center gap-2 mb-6">
          <Calculator className="w-5 h-5 text-[#d0ff59]" />
          <h3 className="text-lg font-semibold text-[#f6f6f6]">Position Size Calculator</h3>
        </div>

        <div className="grid grid-cols-4 gap-4 mb-6">
          <div>
            <label className="text-sm text-[#888888] mb-2 block">Account Balance</label>
            <div className="relative">
              <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#888888]" />
              <input
                type="number"
                value={positionSize.accountBalance}
                onChange={(e) => setPositionSize({...positionSize, accountBalance: parseFloat(e.target.value)})}
                className="w-full bg-[#1a1a1a] border border-[#222222] rounded-xl pl-10 pr-4 py-3 text-[#f6f6f6] focus:border-[#d0ff59] focus:outline-none"
              />
            </div>
          </div>
          <div>
            <label className="text-sm text-[#888888] mb-2 block">Risk %</label>
            <div className="relative">
              <Percent className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#888888]" />
              <input
                type="number"
                value={positionSize.riskPercent}
                onChange={(e) => setPositionSize({...positionSize, riskPercent: parseFloat(e.target.value)})}
                className="w-full bg-[#1a1a1a] border border-[#222222] rounded-xl pl-10 pr-4 py-3 text-[#f6f6f6] focus:border-[#d0ff59] focus:outline-none"
              />
            </div>
          </div>
          <div>
            <label className="text-sm text-[#888888] mb-2 block">Entry Price</label>
            <input
              type="number"
              value={positionSize.entryPrice}
              onChange={(e) => setPositionSize({...positionSize, entryPrice: parseFloat(e.target.value)})}
              className="w-full bg-[#1a1a1a] border border-[#222222] rounded-xl px-4 py-3 text-[#f6f6f6] focus:border-[#d0ff59] focus:outline-none"
            />
          </div>
          <div>
            <label className="text-sm text-[#888888] mb-2 block">Stop Loss</label>
            <input
              type="number"
              value={positionSize.stopLoss}
              onChange={(e) => setPositionSize({...positionSize, stopLoss: parseFloat(e.target.value)})}
              className="w-full bg-[#1a1a1a] border border-[#222222] rounded-xl px-4 py-3 text-[#f6f6f6] focus:border-[#d0ff59] focus:outline-none"
            />
          </div>
        </div>

        {/* Calculation Results */}
        <div className="grid grid-cols-3 gap-4">
          <div className="p-4 bg-[#1a1a1a] rounded-xl border border-[#d0ff59]/30">
            <p className="text-sm text-[#888888]">Risk Amount</p>
            <p className="text-2xl font-bold text-[#d0ff59]">${calculatedPosition.riskAmount.toFixed(2)}</p>
          </div>
          <div className="p-4 bg-[#1a1a1a] rounded-xl">
            <p className="text-sm text-[#888888]">Stop Loss %</p>
            <p className="text-2xl font-bold text-[#f6f6f6]">{calculatedPosition.stopLossPercent.toFixed(2)}%</p>
          </div>
          <div className="p-4 bg-[#1a1a1a] rounded-xl border border-[#d0ff59]/30">
            <p className="text-sm text-[#888888]">Position Size</p>
            <p className="text-2xl font-bold text-[#d0ff59]">{calculatedPosition.positionSize.toFixed(4)} BTC</p>
          </div>
        </div>
      </div>
    </div>
  );
}
