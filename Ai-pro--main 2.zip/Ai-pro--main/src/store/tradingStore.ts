import { create } from 'zustand';

interface Position {
  id: string;
  symbol: string;
  side: 'LONG' | 'SHORT';
  size: number;
  entryPrice: number;
  leverage: number;
  timestamp: number;
}

interface Trade {
  id: string;
  symbol: string;
  side: 'LONG' | 'SHORT';
  size: number;
  entryPrice: number;
  exitPrice?: number;
  pnl: number;
  timestamp: number;
}

interface TradingState {
  balance: number;
  equity: number;
  positions: Position[];
  trades: Trade[];
  selectedCoin: string;
  selectedTimeframe: string;
  isAIEnabled: boolean;
  setBalance: (balance: number) => void;
  setEquity: (equity: number) => void;
  setSelectedCoin: (coin: string) => void;
  setSelectedTimeframe: (timeframe: string) => void;
  setAIEnabled: (enabled: boolean) => void;
  addPosition: (position: Omit<Position, 'id' | 'timestamp'>) => void;
  closePosition: (positionId: string, currentPrice: number) => void;
  addTrade: (trade: Omit<Trade, 'id' | 'timestamp'>) => void;
  updatePositionPnL: (positionId: string, currentPrice: number) => void;
  reset: () => void;
}

export const useTradingStore = create<TradingState>((set, get) => ({
  balance: 10000,
  equity: 10000,
  positions: [],
  trades: [],
  selectedCoin: 'BTC',
  selectedTimeframe: '1h',
  isAIEnabled: false,

  setBalance: (balance: number) => set({ balance }),
  setEquity: (equity: number) => set({ equity }),
  setSelectedCoin: (coin: string) => set({ selectedCoin: coin }),
  setSelectedTimeframe: (timeframe: string) => set({ selectedTimeframe: timeframe }),
  setAIEnabled: (enabled: boolean) => set({ isAIEnabled: enabled }),

  addPosition: (position: Omit<Position, 'id' | 'timestamp'>) => {
    const newPosition: Position = {
      ...position,
      id: Math.random().toString(36).substr(2, 9),
      timestamp: Date.now()
    };
    set((state: TradingState) => ({ // EXPLICIT TYPE ADDED
      positions: [...state.positions, newPosition]
    }));
  },

  closePosition: (positionId: string, currentPrice: number) => {
    const state = get();
    const position = state.positions.find((p: Position) => p.id === positionId);
    if (!position) return;

    const pnl = position.side === 'LONG' 
      ? (currentPrice - position.entryPrice) * position.size * position.leverage
      : (position.entryPrice - currentPrice) * position.size * position.leverage;

    const trade: Trade = {
      id: Math.random().toString(36).substr(2, 9),
      symbol: position.symbol,
      side: position.side,
      size: position.size,
      entryPrice: position.entryPrice,
      exitPrice: currentPrice,
      pnl,
      timestamp: Date.now()
    };

    set((state: TradingState) => ({ // EXPLICIT TYPE ADDED
      positions: state.positions.filter((p: Position) => p.id !== positionId),
      trades: [trade, ...state.trades],
      balance: state.balance + pnl,
      equity: state.equity + pnl
    }));
  },

  addTrade: (trade: Omit<Trade, 'id' | 'timestamp'>) => {
    const newTrade: Trade = {
      ...trade,
      id: Math.random().toString(36).substr(2, 9),
      timestamp: Date.now()
    };
    set((state: TradingState) => ({ // EXPLICIT TYPE ADDED
      trades: [newTrade, ...state.trades]
    }));
  },

  updatePositionPnL: (positionId: string, currentPrice: number) => {
    set((state: TradingState) => ({ // EXPLICIT TYPE ADDED
      positions: state.positions.map((pos: Position) => {
        if (pos.id !== positionId) return pos;
        const pnl = pos.side === 'LONG'
          ? (currentPrice - pos.entryPrice) * pos.size * pos.leverage
          : (pos.entryPrice - currentPrice) * pos.size * pos.leverage;
        return { ...pos, pnl };
      })
    }));
  },

  reset: () => set({
    balance: 10000,
    equity: 10000,
    positions: [],
    trades: []
  })
}));
